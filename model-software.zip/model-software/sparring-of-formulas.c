#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_randist.h>

//#define OUT 
int cnk = 0;

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void genColex(int n,int r,int k,int a, int b,int *c,int *minimum){
	if (n==0){
#ifdef OUT
		for( int ii=1; ii <= k; ii++)
			fprintf(stdout,"%d ",a+c[ii]);
		fprintf(stdout," - ");
#endif
		cnk++;
	}
	else{
		if (c[r]==b)
    			r = r-1;
  		int l = minimum[n];
  		for (int i=l; i <= r; i++){
			int e;
   			if (i==l)
				e = n-(l-1)*b;
    			else
				e = 1;
    			c[i] = c[i]+e;
    			genColex(n-e,i,k,a,b,c,minimum);
    			c[i] = c[i]-e;
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int find(int n,int k,int b){
	int t=-1;
	for (int s=1; s <= k; s++)
		if (s*b >= n){
			t = s;
			break;
		}
	return t;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generateMin(int *impossible, int n, int k, int b, int *m){
	*impossible = 0;
	for (int i=1; i <= n; i++){
   		int q = find(i,k,b);
   		if (q==-1){
			*impossible=1;
			break;
   		}
   	m[i] = q;
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generate_allocations(int n_coded_fragments,int path_length,int min_c,int max_c){

	if (!(path_length*min_c>n_coded_fragments || path_length*max_c<n_coded_fragments || n_coded_fragments<0 || path_length<0)){
		int im;
		int minimum[n_coded_fragments-path_length*min_c+1];
		generateMin(&im,n_coded_fragments-path_length*min_c,path_length,max_c-min_c,minimum);

		int *c = (int *)calloc(path_length+1,sizeof(int));
		if (im==0)
			genColex(n_coded_fragments-path_length*min_c,path_length,path_length,min_c,max_c-min_c,c,minimum);
		free(c);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 4){
		fprintf(stdout,"usage : %s n k m\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	int n = atoi(argv[1]);
	int k = atoi(argv[2]);
	int m = atoi(argv[3]);

	cnk = 0;
	generate_allocations(n,k,0,m);
	fprintf(stdout,"C(%d,%d,%d) = %d\n",n,k,m,cnk);

	return EXIT_SUCCESS;
}
