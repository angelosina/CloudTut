#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include "defines.h"
#include "extern-functions.h"

int extra_brothers = 0;
int extra_uncles = 0;
int extra_grandpas = 0;

int L = 0;
int r = 0;
int ncode_at_0 = 0;
int kcode_at_0 = 0;
int *ncode = NULL;
int *kcode = NULL;
int F = 0;
int N = 0;
int Nactive = 0;
int n_replicas = 0;
int Fmax = 0;
double z = 0.00;
double y = 3.0;
int topF = 0;
int ncode_at_0_topF = 0;
int kcode_at_0_topF = 0;

double MAXF = 0;
double *p = NULL;
char *active_FN = NULL;

unsigned int *FN_capacity = NULL;
double *average_occupancy = NULL;

double *file_popularity = NULL;
double **file_allocation = NULL;
int **rp = NULL;

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_unfeasibility_for_each_FN(double *p_unfeasible_poisson){
	double p_feasible = 1;
	p_unfeasible_poisson[ROOT_FN] = 0;
	for(int FN_id = 2; FN_id <= N; FN_id++){
		double sum_of_lambda = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_lambda += ncode[file_id] * (file_allocation[file_id][FN_id]/file_allocation[file_id][0]);
		average_occupancy[FN_id] = sum_of_lambda;
		if(sum_of_lambda > 0)
			p_unfeasible_poisson[FN_id]  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);
		else
			p_unfeasible_poisson[FN_id]  = 0;
		p_feasible *= (1 - p_unfeasible_poisson[FN_id]);
	}
	return 1 - p_feasible;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double phit(int FN_id, int file_id, char model_type){
	double ph = 0;

	char root_is_in_rp = FALSE;
	for(int rp_id = 1; rp_id <= rp[FN_id][0] && !root_is_in_rp; rp_id++)
		 root_is_in_rp = (rp[FN_id][rp_id] == ROOT_FN);

	double multinomial_phit;
	double poissonized_phit;
	if(root_is_in_rp){
		ph = 1;
	}
	else{
		double psum = 0;
		for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
			psum += file_allocation[file_id][rp[FN_id][rp_id]]/file_allocation[file_id][0];
		}

		if(psum > 0){
			if(model_type == POISSON)
				ph = gsl_cdf_poisson_Q(kcode[file_id] - 1, ncode[file_id] * psum);
			else
				ph = gsl_cdf_binomial_Q(kcode[file_id] - 1, psum, ncode[file_id]);
		}
#ifdef DEBUG_ALL
		fprintf(stdout,"FN_id %d rp %d file_id %d model %c psum %lf ph %lf\n",FN_id,rp[FN_id][0],file_id,(model_type==POISSON)?'P':'M',psum,ph);
#endif
	}
	return ph;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_averaged_phit( double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double *PIE_mult, double *PIE_pois){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		hn_mult[FN_id] = hn_pois[FN_id] = 0;
	for(int file_id = 0; file_id < F; file_id++)
		hf_mult[file_id] = hf_pois[file_id] = 0;
	for(int file_id = 0; file_id < F; file_id++){
		for(int FN_id = 1; FN_id <= N ; FN_id++){
			if(active_FN[FN_id]){
				double multinomial_phit = phit(FN_id, file_id, MULTINOMIAL);
				double poisson_phit = phit(FN_id, file_id, POISSON);

				hn_mult[FN_id] += file_popularity[file_id] * multinomial_phit;
				hn_pois[FN_id] += file_popularity[file_id] * poisson_phit;
				hf_mult[file_id] += multinomial_phit;
				hf_pois[file_id] += poisson_phit;

			}
		}
		hf_mult[file_id] /= Nactive;
		hf_pois[file_id] /= Nactive;
	}

	*PIE_mult = 0;
	*PIE_pois = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id]){
			*PIE_mult += hn_mult[FN_id];
			*PIE_pois += hn_pois[FN_id];
		}
	*PIE_mult /= Nactive;
	*PIE_pois /= Nactive;

}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc < 8){
		fprintf(stdout,"usage : %s L r n k F Fmax n_replicas z_allocation extrab extrau extragp topF y\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode_at_0 = atoi(argv[3]);
	kcode_at_0 = atoi(argv[4]);
	F = atoi(argv[5]);

	Fmax = atoi(argv[6]);
	n_replicas = atoi(argv[7]);

	if(argc > 8)
		z = atof(argv[8]);

	extra_brothers = atoi(argv[9]);
	extra_uncles = atoi(argv[10]);
	extra_grandpas = atoi(argv[11]);

	topF = atoi(argv[12]);
	y = atof(argv[13]);

	allocate_structures(); 	// HERE THE VALUE OF N IS COMPUTED
				// HERE THE VALUE OF ncode_at0_topF IS COMPUTED

	double p_unfeasible_poisson[N + 1];
	double average_unfeasibility[L + 1];
	char at_least_one_unfeasible[L + 1];
	double unfeasibility = 0;

	double hn_mult[N + 1];
	double hn_pois[N + 1];
	double hf_mult[F];
	double hf_pois[F];
	double PIE_mult = 0;
	double PIE_pois = 0;

	double average_utilization = 0;
	double average_storage_utilization[L+1];


	int n_FN_per_level[L+1];

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
	init_model_parameters();
	// phit computation
	compute_averaged_phit(hn_mult, hn_pois, hf_mult, hf_pois, &PIE_mult, &PIE_pois);
	// feasibility computation
	unfeasibility = compute_unfeasibility_for_each_FN(p_unfeasible_poisson);

	for(int l = 1; l <= L; l++)
		average_unfeasibility[l] = average_storage_utilization[l] = at_least_one_unfeasible[l] = n_FN_per_level[l] = 0;
	for(int FN_id = 2; FN_id <= N ; FN_id++){
		int FN_level = get_FN_level(FN_id);
		average_unfeasibility[FN_level] += p_unfeasible_poisson[FN_id];
		average_storage_utilization[FN_level] += average_occupancy[FN_id] / FN_capacity[FN_id];
		at_least_one_unfeasible[FN_level] |= (p_unfeasible_poisson[FN_id] > UNFEASIBILITY_THRESHOLD);
		n_FN_per_level[FN_level]++;
		average_utilization += average_occupancy[FN_id] / FN_capacity[FN_id];
	}
	average_utilization /= (N - 1);
	for(int l = 1; l <= L; l++){
		average_unfeasibility[l] /= n_FN_per_level[l];
		average_storage_utilization[l] /= n_FN_per_level[l];
	}

	fprintf(stdout,"z %.2lf y %.2lf TOPF %d B %d U %d G %d %c n %d F %d FMAX %.1lf ( %lf ) : U %lf PIE (m) %lf PIE (p) %lf 1-PHI %lf overall %lf\n",z,y,topF,extra_brothers, extra_uncles, extra_grandpas,(unfeasibility > UNFEASIBILITY_THRESHOLD)?'O':'U',ncode_at_0,F,MAXF,F/MAXF,average_utilization,PIE_mult,PIE_pois,unfeasibility,average_utilization*PIE_pois);
	for(int l = 1; l <= L; l++) {
		fprintf(stdout,"z %.2lf y %.2lf TOPF %d B %d U %d G %d %c n %d F %d FMAX %.1lf ( %lf ) : ",z,y,topF,extra_brothers, extra_uncles, extra_grandpas,(unfeasibility > UNFEASIBILITY_THRESHOLD)?'O':'U',ncode_at_0,F,MAXF,F/MAXF);
		fprintf(stdout,"Level %d : U %lf 1-PHI %lf at least one unfeasible %s\n",l,average_storage_utilization[l],average_unfeasibility[l],at_least_one_unfeasible[l]?"YES":"NO");
	}

//     	print_fog_nodes_state(p_unfeasible_poisson,hn_mult,hn_pois);
//	print_file_state(hf_mult, hf_pois, file_popularity);
#ifdef DEBUG_ALL
     	print_fog_nodes_state(p_unfeasible_poisson,hn_mult,hn_pois);
	print_file_state(hf_mult, hf_pois, file_popularity);
#endif

	free_structures();
	return (unfeasibility > UNFEASIBILITY_THRESHOLD)?EXIT_FAILURE:EXIT_SUCCESS;
}
