#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_randist.h>

//#define OUT 
#define UNKNOWN -1

int L = 0;
int r = 0;
int ncode = 0;
int kcode = 0;
int M = 0;
int F = 0;
int c = 0;
int N = 0;

int **path_id = NULL;

double phit = 0;
double partial_phit = 0;
double *p = NULL;
double *p_multinomial = NULL;
int *n_multinomial = NULL;

double **file_allocation = NULL;
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void genColex(int n,int r,int k,int a, int b,int *c,int *minimum, int FN, int **path_id){
	if (n==0){
#ifdef OUT
		for( int ii=1; ii <= k; ii++)
			fprintf(stdout,"%d ",a+c[ii]);
		fprintf(stdout," - ");
#endif
		int path_length = 0;
		int sum_n = 0;
		for(; path_length <= M ; path_length++){
			if(path_id[FN][path_length] != UNKNOWN){
				n_multinomial[path_length] = a + c[path_length + 1];
				sum_n += n_multinomial[path_length];
			}
			else
				break;
		}
		n_multinomial[path_length] = ncode - sum_n;
#ifdef OUT
		for(int ii = 0; ii <= path_length ; ii++){
			fprintf(stdout,"fn %d ncf %d pmult %lf : ",path_id[FN][ii],n_multinomial[ii],p_multinomial[ii]);
		}
		fprintf(stdout," +++ path length %d +++ ",path_length);
#endif

		double p_allocation = gsl_ran_multinomial_pdf (path_length + 1, p_multinomial, n_multinomial);
		partial_phit += p_allocation;
#ifdef OUT
		fprintf(stdout," %lf\n",p_allocation);
#endif
	}
	else{
		if (c[r]==b)
    			r = r-1;
  		int l = minimum[n];
  		for (int i=l; i <= r; i++){
			int e;
   			if (i==l)
				e = n-(l-1)*b;
    			else
				e = 1;
    			c[i] = c[i]+e;
    			genColex(n-e,i,k,a,b,c,minimum,FN,path_id);
    			c[i] = c[i]-e;
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int find(int n,int k,int b){
	int t=-1;
	for (int s=1; s <= k; s++)
		if (s*b >= n){
			t = s;
			break;
		}
	return t;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generateMin(int *impossible, int n, int k, int b, int *m){
	*impossible = 0;
	for (int i=1; i <= n; i++){
   		int q = find(i,k,b);
   		if (q==-1){
			*impossible=1;
			break;
   		}
   	m[i] = q;
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generate_allocations(int n_coded_fragments,int path_length,int min_c,int max_c, int FN, int **path_id){

	if (!(path_length*min_c>n_coded_fragments || path_length*max_c<n_coded_fragments || n_coded_fragments<0 || path_length<0)){
		int im;
		int minimum[n_coded_fragments-path_length*min_c+1];
		generateMin(&im,n_coded_fragments-path_length*min_c,path_length,max_c-min_c,minimum);

		int *c = (int *)calloc(path_length+1,sizeof(int));
		if (im==0)
			genColex(n_coded_fragments-path_length*min_c,path_length,path_length,min_c,max_c-min_c,c,minimum,FN,path_id);
		free(c);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN > base && FN <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_path_ids(int **path_id, int FN){
	int FN_level = get_FN_level(FN);
	int path_index = 0;

	path_id[FN][path_index++] = FN;
	if(FN > 1){
		int father = get_leftmost_id(FN_level-1)+(FN-get_leftmost_id(FN_level))/r;
		int links = 0;
		for(int level = FN_level - 1; level >= 0 && links < M; links++,level--){
			path_id[FN][path_index] = path_id[father][path_index-1];
			path_index++;
		}
	} 
	for(; path_index <= M; )
		path_id[FN][path_index++] = UNKNOWN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int set_multinomial_p_pars(double *p, int **path_id, int FN){
	double sum_p = 0;
	int path_length = 0;
	for(; path_length <= M ; path_length++){
		if(path_id[FN][path_length] != UNKNOWN){
			p_multinomial[path_length] = p[path_id[FN][path_length]];
			sum_p += p_multinomial[path_length];
		}
		else break;
	}
	p_multinomial[path_length] = 1 - sum_p;
	return path_length;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_allocation_probabilities(double *p){
	double sum_w = 0;

	for(int FN = 1; FN <= N; FN++){
		int l = get_FN_level(FN);
		p[FN] = L - l + 1; // weights
		sum_w += p[FN];
	}
	for(int FN = 1; FN <= N; FN++)
		p[FN] /= sum_w;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 8){
		fprintf(stdout,"usage : %s L r n k M F c\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode = atoi(argv[3]);
	kcode = atoi(argv[4]);
	M = atoi(argv[5]);
	F = atoi(argv[6]);
	c = atoi(argv[7]);

	N = (pow(r,L+1) - 1)/(r - 1);
	M = ( M > L)?L:M;
	M = ( M < 1)?1:M;

	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int f = 0; f < F; f++){
		file_allocation[f] = (double *)calloc(N + 1,sizeof(double));
		set_allocation_probabilities(file_allocation[f]);
	}

	path_id = (int **)calloc(N + 1, sizeof(int *));
	for(int i = 1; i <= N; i++){
		path_id[i] = (int *)calloc(M + 1, sizeof(int));
		set_path_ids(path_id,i);
	}

	p_multinomial = (double *)calloc(M + 2,sizeof(double));
	n_multinomial = (int *)calloc(M + 2, sizeof(int));

	for(int file = 0; file < F; file++){
#ifdef OUT
		fprintf(stdout,"File %d:\n-----------\n",file);	
#endif
		double average_phit = 0;
		for(int leafFN = get_leftmost_id(L); leafFN <= get_rightmost_id(L) ; leafFN++){
			int path_length = set_multinomial_p_pars(file_allocation[file],path_id,leafFN);
			phit = 0;
			for(int n_coded = 0; n_coded < kcode; n_coded++){
				partial_phit = 0;
				generate_allocations(n_coded,path_length,0,n_coded,leafFN,path_id);
				phit += partial_phit;
//				fprintf(stdout,"gathered %d : Partial phit = %lf\n",n_coded,partial_phit);	
			}
			phit = 1 - phit;
			average_phit += phit;
#ifdef OUT
			fprintf(stdout,"node %d Final phit = %lf\n",leafFN,phit);	
			fprintf(stdout,"path:");	
			for(int path_node = 0; path_node <= M; path_node++)
				fprintf(stdout," %d",path_id[leafFN][path_node]);
			fprintf(stdout," : phit %lf\n",phit);	
#endif
		}
		average_phit /= (get_rightmost_id(L) - get_leftmost_id(L) + 1);
		fprintf(stdout,"File %d Final phit = %lf\n",file,phit);	
	}

	for(int i = 1; i <= N; i++)
		free(path_id[i]);
	free(path_id);
	for(int f = 0; f < F; f++)
		free(file_allocation[f]);
	free(file_allocation);

	free(p_multinomial);
	free(n_multinomial);

	return EXIT_SUCCESS;
}
