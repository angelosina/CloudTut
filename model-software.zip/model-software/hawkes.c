// BASED ON 
// Yuan, B., Li, H., Bertozzi, A. L., Brantingham, P. J., & Porter, M. A. 
// Multivariate spatiotemporal hawkes processes and network reconstruction 
// SIAM Journal on Mathematics of Data Science, 2019, 1(2), 356-382.
// Algorithm 3.3

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_combination.h>
#include <gsl/gsl_sort.h>

//#define DEBUG
#define TRUE 1
#define FALSE 0

#define BACKGROUND 66
#define TRIGGERED 84

gsl_ran_discrete_t **f;

unsigned int n_events = 0;
double T = -1;
double R = 0;
int U = -1;
int out_flag = TRUE;

double *gamma_ = NULL;
double **intensity_ = NULL;
double **K_ = NULL;

double w = 2.0;
double sigma_x = 1;
double sigma_y = 1;
double sigma2;
double rho = 0;

unsigned int n_time_slots;

typedef struct node { 
	int u; // It is fog node id
	double x;
	double y; // It is physical coordinates of fog node
	double t; // It is client request time
	double t_father;
	int father;
	char type;
	unsigned int id;
	struct node* next; 

} Node; 

Node* STACK = NULL;
Node* SET = NULL;

Node *free_h = NULL;
unsigned int n_free = 0;

Node* newNode(int u, double x, double y, double t, char type, int father, unsigned int id, double t_father){ 
	Node* temp;

	if(free_h == NULL){
		temp = (Node*)malloc(sizeof(Node)); 
	}
	else{
		temp = free_h;
		free_h = free_h->next;
		n_free--;
	}
	temp->u = u; 
	temp->x = x; 
	temp->y = y; 
	temp->t = t; 
	temp->type = type; 
	temp->father = father; 
	temp->id = id; 
	temp->t_father = t_father; 
	temp->next = NULL; 
//	printf("End of newNode\n");
	return temp; 
} 

int peek_u(Node** head) { return (*head)->u; } 
double peek_x(Node** head) { return (*head)->x; } 
double peek_y(Node** head) { return (*head)->y; } 
double peek_t(Node** head) { return (*head)->t; } 
char peek_type(Node** head) { return (*head)->type; } 
int peek_father(Node** head) { return (*head)->father; } 
double peek_t_father(Node** head) { return (*head)->t_father; } 
unsigned int peek_id(Node** head) { return (*head)->id; } 

void print_event(Node** event){
	int u_i = peek_u(event);
	double x_i = peek_x(event);
	double y_i = peek_y(event);
	double t_i = peek_t(event);
	char type_i = peek_type(event);
	int father_i = peek_father(event);
	double t_father_i = peek_t_father(event);
	unsigned int id_i = peek_id(event);

	fprintf(stdout,"EVENT id %u u: %d x: %lf y: %lf t: %lf t_father %lf type %c : father %d\n", id_i, u_i, x_i, y_i, t_i, t_father_i, type_i,father_i); 
}
void print_stack(){
	unsigned int n = 0;
	fprintf(stdout,"STACK IS\n---------------\n");
	if(STACK != NULL){
		for(Node* event = STACK; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY STACK\n");
	fprintf(stdout,"length = %u\n",n);
}
void print_set(){
	unsigned int n = 0;
	fprintf(stdout,"SET IS\n---------------\n");
	if(SET != NULL){
		for(Node* event = SET; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY SET\n");
	fprintf(stdout,"length = %u\n",n);
}
void print_free(){
	unsigned int n = 0;
	fprintf(stdout,"FREE LIST IS\n---------------\n");
	if(free_h != NULL){
		for(Node* event = free_h; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY FREE LIST\n");
	fprintf(stdout,"length = %u\n",n);
}
void pop(Node** head) { 
	Node* temp = *head; 
	(*head) = (*head)->next; 

	if(free_h == NULL){
		free_h = temp;
		free_h->next = NULL;
	}
	else{
		temp->next = free_h;
		free_h = temp;
	}
	n_free++;
} 
void push(Node** head, int u, double x, double y, double t, char type, int father, unsigned int id, double t_father) { 
	Node*  temp = newNode(u, x, y, t, type, father, id, t_father); 
	if(*head != NULL){
		temp->next = *head; 
	}
	(*head) = temp; 
} 
void insert(Node** head, int u, double x, double y, double t, char type, int father, unsigned int id, double t_father) { 
	Node* start = (*head); 
	Node* temp = newNode(u, x, y, t, type, father, id, t_father); 

	if ((*head)->t > t) { 
		temp->next = *head; 
		(*head) = temp; 
	} 
	else { 
		while (start->next != NULL && start->next->t < t) { 
			start = start->next; 
		} 
		temp->next = start->next; 
		start->next = temp; 
	} 
} 
int isEmpty(Node** head) { return (*head) == NULL; } 

void allocate_structures(){
	intensity_ = (double **)calloc(U, sizeof(double));
	for(int u = 0; u < U; u++)
		intensity_[u] = (double *)calloc(n_time_slots, sizeof(double));
	gamma_ = (double *)calloc(U, sizeof(double));
	K_ = (double **)calloc(U, sizeof(double *));
	for(int u = 0; u < U; u++)
		K_[u] = (double *)calloc(U, sizeof(double));

}
void deallocate_structures(){
	free(intensity_);
	free(gamma_);
	for(int u = 0; u < U; u++)
		free(K_[u]);
	free(K_);
	for(int u = 0; u < U; u++)
		gsl_ran_discrete_free(f[u]);
	free(f);
	while (!isEmpty(&SET)) 
		pop(&SET); 
	while (!isEmpty(&STACK)) 
		pop(&STACK); 
}
void init_structures(){
	sigma2 = sigma_x * sigma_x;
	for(int u = 0; u < U; u++)
		gamma_[u] = u + 1;
	for(int u = 0; u < U; u++)
		for(int t = 0; t < n_time_slots; t++)
			intensity_[u][t] = gamma_[u];

	for(int u = 0; u < U; u++){
		for(int v = 0; v < U; v++){
			if(u == v)
				K_[u][v] = 1.0 / U;
			else
				K_[u][v] = 1.0 / (2 * U);
		}
	}

	f = (gsl_ran_discrete_t **)calloc(U, sizeof(gsl_ran_discrete_t *));
	for(int u = 0; u < U; u++)
		f[u] = gsl_ran_discrete_preproc(U,K_[u]);
}
double g1(double t){ return w * exp(-w * t); }
double g2(double x, double y){ return exp(-((x *x + y * y) / (2 * sigma2))) / (2 * M_PI * sigma2); }
double g(double t, double x, double y){ return g1(t) * g2(x,y); }

void update_intensity(double t, int u, double x, double y){
	int t_slot = floor(t * (2 * w));

	for(int up = 0; up < U; up++)
		for(int slot = 0; slot < n_time_slots; slot++)
			if(slot - t_slot >= 0){
				intensity_[up][slot] += K_[u][up] * g((slot + 1) / (2 * w) - t, x, y);
			}
}
void generate_background_events(gsl_rng *r){
	unsigned int Nb[U];

	for(unsigned int u = 0; u < U; u++){
		Nb[u] = gsl_ran_poisson(r, gamma_[u] * T);
	}
	for(int u = 0; u < U; u++){
		for(unsigned int i = 0; i < Nb[u]; i++){
			double t = gsl_ran_flat(r, 0, T);
			double x = gsl_ran_flat(r, -R, R);
			double y = gsl_ran_flat(r, -R, R);
			n_events++;
			push(&STACK, u, x, y, t, BACKGROUND, -1, n_events, -1); 
			update_intensity(t, u, x, y);

		}
	}
}
void generate_triggered_events(gsl_rng *r, Node** event){
	double t_i = peek_t(&STACK);
	if(t_i >= 0){
		int u_i = peek_u(&STACK);
		double x_i = peek_x(&STACK);
		double y_i = peek_y(&STACK);
		unsigned int id_i = peek_id(&STACK);

		double lambda_i = 0;
		for(int uprime = 0; uprime < U; uprime++)
			lambda_i += K_[u_i][uprime];
		unsigned int n_i = gsl_ran_poisson(r, lambda_i);

		pop(&STACK); 
		for(unsigned int k = 0; k < n_i; k++){
			int u_k = gsl_ran_discrete(r,f[u_i]);
			double t_k = t_i + gsl_ran_exponential(r, 1.0/w);
			double dx,dy; gsl_ran_bivariate_gaussian(r, sigma_x, sigma_y, rho, &dx, &dy);
			double x_k = x_i + dx;
			double y_k = y_i + dy;
			if(t_k <= T){
				n_events++;
				push(&STACK, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i); 
				update_intensity(t_k, u_k, x_k, y_k);
			}
		}
	}
}
void print_intensity(){
	for(int t = 0; t < n_time_slots; t++){
		fprintf(stdout,"time %.3lf : ",(t + 1) / (2 * w) );
		for(int u = 0; u < U; u++)
			fprintf(stdout,"%lf ",intensity_[u][t]);
		fprintf(stdout,"\n");
	}
}
int main (int argc, char *argv[]){ 
	char c;

	while ((c = getopt (argc, argv, "T:R:U:o:w:h")) != -1)
	switch (c) {
                case 'T':
                        T = atof(optarg);
                        break;
                case 'R':
                        R = atof(optarg);
                        break;
                case 'U':
                        U = atoi(optarg);
                        break;
                case 'o':
                        out_flag = atoi(optarg);
                        break;
                case 'w':
                        w = atof(optarg);
                        break;
                case 'h':
                        fprintf(stderr,"usage: %s -T (T) -R (R) -U (U) -w (w) -o (0|*) -h (help)\n",argv[0]);
                        exit(EXIT_FAILURE);
                default:
                        fprintf(stderr,"Abort: something is wrong in command line options\n");
                        exit(EXIT_FAILURE);
        }
	n_time_slots = (unsigned int)ceil(T * (2 * w));
	const gsl_rng_type *TT;
	gsl_rng *r;

	gsl_rng_env_setup();
	TT = gsl_rng_default;
	r = gsl_rng_alloc (TT);

	allocate_structures();
	init_structures();

	STACK = newNode(-1, -1, -1, -1, BACKGROUND, -1, 0, -1); 
//	SET = newNode(-1, -1, -1, -1, BACKGROUND, -1, 0, -1); 

	generate_background_events(r);

	while (!isEmpty(&STACK) && peek_t(&STACK) >= 0) { 
		generate_triggered_events(r,&STACK);
	} 

	if(out_flag)
		print_intensity();

	deallocate_structures();
	gsl_rng_free (r);

	return 0; 
} 


