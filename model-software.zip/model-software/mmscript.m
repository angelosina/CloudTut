
mmpp();
function iltv = invlaplace(fun, T, maxFnEvals, method)

global cmeParams;
if isempty(cmeParams)
    cmeParams = jsondecode(fileread('iltcme_ext.json'));
end
if ~exist('method','var')
    method = 'cme'; 
end

if strcmp(method, 'cme')

    % find the most steep CME satisfying maxFnEvals
    chosen = 1;
    params = cmeParams(1);
    for i=2:length(cmeParams)
        if cmeParams(i).cv2<params.cv2 && cmeParams(i).n+1<=maxFnEvals
            params = cmeParams(i);
            chosen = i;
        end
    end
   % params = cmeParams(length(cmeParams));
    % compute eta and beta parameters
    eta = [params.c*params.mu1, params.a'*params.mu1 + 1i*params.b'*params.mu1];
    beta = [1, 1 + 1i*(1:params.n)*params.omega] * params.mu1;

elseif strcmp(method,'euler')
    
    n_euler = floor((maxFnEvals-1)/2);
    eta = [0.5, ones(1, n_euler), zeros(1, n_euler-1), 2^-n_euler];
    for k = 1:n_euler-1
%        eta(2*n_euler-k + 1) = eta(2*n_euler-k + 2) + 2^-n_euler * nchoosek(n_euler, k);
       eta(2*n_euler-k + 1) = eta(2*n_euler-k + 2) + exp(sum(log(1:n_euler)) - n_euler*log(2) - sum(log(1:k)) - sum(log(1:(n_euler-k))));
    end
    k = 0:2*n_euler;
    beta = n_euler*log(10)/3 + 1i*pi*k;
    eta  = (10^((n_euler)/3))*(1-mod(k, 2)*2) .* eta;  
    
elseif strcmp(method,'gaver')

    if mod(maxFnEvals,2)==1
        maxFnEvals = maxFnEvals - 1;
    end
    ndiv2 = maxFnEvals/2;
    eta = zeros(1,maxFnEvals);
    beta = zeros(1,maxFnEvals);
    for k = 1:maxFnEvals % itration index
        inside_sum = 0.0;
        for j = floor((k+1)/2):min(k,ndiv2) %  eta summation index
%            inside_sum=inside_sum+((j^((ndiv2+1))/factorial(ndiv2))*(nchoosek(ndiv2, j)*nchoosek(2*j, j)*nchoosek(j, k-j)));           
           inside_sum=inside_sum+exp((ndiv2+1)*log(j) - sum(log(1:(ndiv2-j))) + sum(log(1:2*j)) - 2*sum(log(1:j)) - sum(log(1:(k-j))) - sum(log(1:(2*j-k))));
        end
        eta(k)=log(2.0)*(-1)^(k+ndiv2)*inside_sum;
        beta(k) = k * log(2.0);
    end    
    
else
    error('This inverse laplace transform method is unknown. Supported ones: cme, euler, gaver');
end

% common part for all abate-whitt variants
[eta_mesh,T_mesh]= meshgrid(eta, T);
beta_mesh = meshgrid(beta, T);
iltv = 1./reshape(T,[],1) .* sum(real(eta_mesh .* arrayfun(fun, beta_mesh./T_mesh)), 2);

end

function Wv=LST(s)
global pie;
global rho;
global g;
global Q;
global LAMBDA;
global mu;
global m;

    if s == 0
        W=pie;
    else
        A=(s*eye(m)+Q-LAMBDA*(1-(mu/(mu+s))));
       % A,rank(A)
       %OK W=s*(1-rho)*(g/A);
        W=(1-rho)*(g/A);
    end
    Wv=sum(W);
end

function Wv=LSTpdf(s)
global pie;
global rho;
global g;
global Q;
global LAMBDA;
global mu;
global m;

    if s == 0
        W=pie;
    else
        A=(s*eye(m)+Q-LAMBDA*(1-(mu/(mu+s))));
       % A,rank(A)
       W=s*(1-rho)*(g/A);
        %W=(1-rho)*(g/A);
    end
    Wv=sum(W);
end
    
function mmpp()
    global m;
    global mu;
    global epsilon1;
    global Q;
    nclients = 4;
    Ton = 10.0; Toff = 2.5; Lon = 1.0; Loff = 0.0; mu=500.0;
    
    T=4; funEvals=150; spacing = 0.1;
    m=nclients+1; 
    epsilon1 = 1e-6;
    epsilon2 = 1e-6;
    
    Q = zeros(m,m);
    for i=1:m
        if i > 1
            Q(i,i-1)=(i - 1)/Ton;
            Q(i,i)=Q(i,i)-Q(i,i-1);
        end
        if i < m 
            Q(i,i+1)=(m - (i - 1)) / Toff;
            Q(i,i)=Q(i,i)-Q(i,i+1);
        end
    end
    global LAMBDA;
    LAMBDA=zeros(m,m);
    for i=1:m
        LAMBDA(i,i)=( i - 1) * Lon + (nclients - (i - 1)) * Loff;
    end
    lambda = diag(LAMBDA);
    THETA = max(diag(LAMBDA-Q)); 
    sum = 0; i = 0;
    while sum <= 1 - epsilon1
        psi(i + 1)=(mu * (THETA^i))/((THETA+mu)^(i+1));
        if psi(i + 1) < epsilon1
            break;
        end
        sum = sum + psi(i+1);
        i = i + 1;   
    end
    nstar = i ;
    Gkm1=zeros(m,m);
    G=zeros(m,m);
    k=1;
    while 0 < 1
        H_n=eye(m);
        Gk=psi(1)*H_n;
        for n=2:nstar+1
            H_n = (eye(m)+(1/THETA)*(Q-LAMBDA+LAMBDA*Gkm1))*H_n;
            Gk = Gk + psi(n) * H_n;        
        end
        if norm(Gkm1-Gk) < epsilon2
            G = Gk;
            break;
        end
        Gkm1=Gk;
        k = k +1;
    end
    mc=dtmc(G);
    global g;
    g=asymptotics(mc);
    global pie;
    QD=zeros(m,m);
    for row=1:m
        for col=1:m
            if row ~= col
                QD(row,col) = Q(row,col)/(-Q(row,row));
            end
        end
    end
    mc=dtmc(QD);
    pie=asymptotics(mc);
    lambdatot=pie*lambda;
    global rho;
    rho=lambdatot/mu;
    LAMBDA, Q, pie, G, g
    fprintf('lambdat tot = %f mu = %f rho is  %f\n',lambdatot, mu, rho);
    
    
%     M1=Q+ones([m,1])*pie;
%     wmed = (2*rho+lambdatot*(2/mu^2)-(2*(1/mu)*((1-rho)*g+(1/mu)*pie*LAMBDA)/M1)*lambda) / (2*(1-rho));
%     fprintf('Wmed = %f\n',wmed);
%     tFuns = [];
%     tFuns(1).lt=@(s)LST(s);
%     tFuns(1).xvals=spacing:spacing:T;
%     for funEvals=370:1:390
%         fprintf('funEvals = %d\n==============\n',funEvals);
%         for T=1:1:10
%             tFuns(1).xvals=T:T:T;
%             cme = invlaplace(tFuns(1).lt, tFuns(1).xvals, funEvals, "cme");
%             fprintf('P(W <= %d) = %f\n',T,cme(1));
%         end
%     end
    
end
