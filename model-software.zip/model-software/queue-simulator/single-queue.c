#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <float.h>
#include <limits.h>
#include "lcgrand.h" /* Header file for the random-number-generator */

#define Q_LIMIT 4096 /* Limit on the queue length */

#define BUSY 1 /* Mnemonics for server's being busy */
#define IDLE 0 /* and idle. */

#define SIMULATION_END 0
#define ARRIVAL 1 
#define DEPARTURE 2 

#define TRUE 1
#define FALSE 1

#define NUM_EVENTS 2

int next_event_type, num_custs_delayed, num_in_q, server_status;
float area_num_in_q, area_server_status, mean_interarrival, mean_service_time, sim_time, time_arrival[Q_LIMIT + 1], time_last_event, time_next_event[NUM_EVENTS + 1], total_of_delays;
FILE *tracefile;

void initialize(void);
void timing(void);
void arrive(void);
void depart(void);
void report(void);
void update_time_avg_stats(void);
float expon(float mean);

int main(int argc, char *argv[]) {
	if(argc != 3){
		fprintf(stderr,"usage: %s mean-service-time trace-file",argv[0]);
		exit(EXIT_FAILURE);
	}
	mean_service_time = atof(argv[1]);	
	tracefile = fopen(argv[2], "r");

	initialize();
	while(TRUE){
		timing();
		update_time_avg_stats();
		switch(next_event_type){
			case SIMULATION_END: 
				goto simulation_end;
				break;
			case ARRIVAL:
				arrive();
				break;
			case DEPARTURE:
				depart();
				break;
		}
	}
simulation_end:
	fclose(tracefile);
	report();

	return EXIT_SUCCESS;
}

void initialize(void){ /* Initialize function. */
	/* Initialize the simulation clock. */
	sim_time = 0;

	/* Initialize the state variables. */
	server_status   = IDLE;
	num_in_q        = 0;
	time_last_event = 0.0;

	/* Initialize the statistical counters. */
	num_custs_delayed  = 0;
	total_of_delays    = 0.0;
	area_num_in_q      = 0.0;
	area_server_status = 0.0;

	/* Initialize the event list. Since no customers are present, the departure (service completion) event is eliminated from consideration. */
	float first_arrival;
	fscanf(tracefile, "%f", &first_arrival);
	time_next_event[ARRIVAL] = sim_time + first_arrival;
	time_next_event[DEPARTURE] = FLT_MAX;
}

void  timing(void){ /* Timing function. */
	int i;
	float min_time_next_event = FLT_MAX;

	next_event_type = SIMULATION_END;
	/* Determine the event type for the next event to occur. */
	for(i = 1; i <= NUM_EVENTS; ++i){
		if(time_next_event[i] < min_time_next_event){
			min_time_next_event = time_next_event[i];
			next_event_type = i;
		}
	}

	/* The event list is not empty, so advance the simulation clock. */
	if(min_time_next_event < FLT_MAX)
		sim_time = min_time_next_event;
}

void arrive(void){ /* Arrival event function. */
	/* Schedule next arrival. */
	if(!feof(tracefile)){
		float delay, arrival;
		fscanf(tracefile, "%f", &arrival);
		time_next_event[ARRIVAL] = arrival;

		/* Check to see whether server is busy. */
		if(server_status == BUSY){
			/* Server is busy so increment the number of customers in the queue. */
			++num_in_q;
	
			/* Check to see whether an overflow condition exists. */
			if(num_in_q > Q_LIMIT){
				/* The queue has overflowed, so stop the simulation. */
				fprintf(stdout, "\nOverflow of the array time_arrival at time %f", sim_time);
				exit(EXIT_FAILURE);
			}
	
			/* There is still room in the queue, so store the time of arrival of the arriving customer at the (new) end of time_arrival. */
			time_arrival[num_in_q] = sim_time;
#ifdef DEBUG
			fprintf(stdout,"Arrival in busy queue at time %lf customers in queue = %d\n",sim_time,num_in_q);
#endif
		}
	
		else{
			/* Server is idle, so arriving customer has a delay of zero. */
			delay = 0.0;
			total_of_delays += delay;
	
			/* Increment the number of customers delayed, and make server busy. */
			++num_custs_delayed;
			server_status = BUSY;
	
			/* Schedule a departure (service completion). */
			time_next_event[DEPARTURE] = sim_time + expon(mean_service_time);
#ifdef DEBUG
			fprintf(stdout,"Arrival in idle queue at time %lf customers in queue = %d\n",sim_time,num_in_q);
#endif
		}
	}
	else
		time_next_event[ARRIVAL] = FLT_MAX;
}

void depart(void){ /*Departure event function. */
	int i;
	float delay;

	/* Check to see whether the queue is empty. */
	if(num_in_q == 0){
		/* The queue is empty so make the server idle and eliminate the
		 * departure (service completion) event from consideration. */
		server_status = IDLE;
		time_next_event[DEPARTURE] = FLT_MAX;
#ifdef DEBUG
		fprintf(stdout,"Departure leaving idle queue at time %lf customers in queue = %d\n",sim_time,num_in_q);
#endif
	}
	else{
		/* The queue is nonempty, so decrement the number of customers in queue. */
		--num_in_q;

		/* Compute the delay of the customer who is beginning service
		 * and update the total delay of accumulator. */
		delay = sim_time - time_arrival[1];
		total_of_delays += delay;

		/* Increment the number of customers delayed, and schedule departure. */
		++num_custs_delayed;
		time_next_event[DEPARTURE] = sim_time + expon(mean_service_time);

		/* Move each customer in queue (if any) up one place. */
		for(i = 1; i <= num_in_q; ++i){
			time_arrival[i] = time_arrival[i + 1];
		}
#ifdef DEBUG
		fprintf(stdout,"Departure leaving busy queue at time %lf customers in queue = %d\n",sim_time,num_in_q);
#endif
	}
}

void report(void){ /*Report generator function */
	/* Compute and write estimates of desired measures of performance. */
	fprintf(stdout, "queuedelay = %lf\t", total_of_delays / num_custs_delayed);
	fprintf(stdout, "queuelength %lf\t", area_num_in_q / sim_time);
	fprintf(stdout, "utilization %lf\t", area_server_status / sim_time);
	fprintf(stdout, "endtime %lf\n", sim_time);
}

void update_time_avg_stats(void){ /* Update area accumulators for time-average statistics. */
	float time_since_last_event;

	/* Compute time since last event, and update last-event-time- marker. */
	time_since_last_event = sim_time - time_last_event;
	time_last_event = sim_time;

	/* Update area under number-in-queue function */
	area_num_in_q += num_in_q * time_since_last_event;

	/* Update area under server-busy indicator function. */
	area_server_status += server_status * time_since_last_event;
}

float expon(float mean){ /* Exponential variate generation function. */
	/* Return an exponential random variate with mean "mean". */
	return -mean * log(lcgrand(1));
}
