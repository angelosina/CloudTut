extern int get_FN_level(int);
extern int get_leftmost_id(int);
extern int get_rightmost_id(int);
extern int get_father(int);
extern int get_brother(int, int);

extern void print_fog_nodes_state(double *, double *, double *);
extern void print_file_state(double *, double *, double *);
extern void print_rp_state();

extern void set_rp(int );
extern void set_file_allocations(int , double *, double *);
extern void set_file_popularities(int );
extern void set_fog_nodes_capabilities(int );
extern void set_mds_parameters(int , double *, double *, double *, double *, double ,  double , double ,  double , double );
extern void init_model_parameters();
extern void allocate_structures();
extern void free_structures();
