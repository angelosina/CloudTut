#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_integration.h>

#include "inverse_laplace.h"

#define ABS_ERR 1e-2
#define REL_ERR 1e-2
#define LIMIT 10000


#define TRUE 1
#define FALSE 0
#define UNKNOWN -1
//#define DEBUG_DTMC
//#define DEBUG
//#define DEBUG_LST
//#define DEBUG_WMED
//#define DEBUG
//#define DEBUG_LST

double *w = NULL;

gsl_vector **g = NULL;
gsl_vector **pie = NULL;
gsl_matrix ** LAMBDA = NULL;
gsl_matrix ** Q = NULL;


#define EXPONENTIAL 'm'
#define DETERMINISTIC 'd'

double *lambda_tot = NULL;
double *rho = NULL;

char stype;
double xmax;
int npoints = 1;

double epsilon1 = 1e-8;
double epsilon2 = 1e-8;

#define MAX_ITER 10000
 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_vector(FILE *f, const gsl_vector *v, const char *title){
        int status, n = 0;

	fprintf(f,"======== VECTOR %s START =========\n",title);
	double sum = 0;
	for (size_t j = 0; j < v->size; j++) {
		if ((status = fprintf(f, "%lf ", gsl_vector_get(v, j))) < 0)
			return -1;
		n += status;
		sum += gsl_vector_get(v,j);
	}
	fprintf(f," : sum %lf \n======== VECTOR %s END =========\n",sum,title);
	return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_complex_vector(FILE *f, const gsl_vector_complex *v, const char *title){
	fprintf(f,"======== VECTOR %s START =========\n",title);
	for (size_t j = 0; j < v->size; j++){
		gsl_complex velem = gsl_vector_complex_get(v,j);
		fprintf(f, "%lf %ci%lf ", GSL_REAL(velem),(GSL_IMAG(velem))<0?' ':'+',GSL_IMAG(velem));
	}
	fprintf(f,"\n======== VECTOR %s END =========\n",title);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_matrix(FILE *f, const gsl_matrix *matrix, const char *title){
        int status, n = 0;

	fprintf(f,"======== MATRIX %s START =========\n",title);
        for (size_t i = 0; i < matrix->size1; i++) {
		double row_sum = 0;
                for (size_t j = 0; j < matrix->size2; j++) {
                        if ((status = fprintf(f, "%lf ", gsl_matrix_get(matrix, i, j))) < 0)
                                return -1;
			row_sum += gsl_matrix_get(matrix, i, j);
                        n += status;
                }
                if ((status = fprintf(f, " : sum %lf\n",row_sum)) < 0)
                        return -1;
                n += status;
        }
	fprintf(f,"======== MATRIX %s END =========\n",title);
        return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_complex_matrix(FILE *f, const gsl_matrix_complex *matrix, const char *title){
        int status, n = 0;

	fprintf(f,"======== MATRIX %s START =========\n",title);
        for (size_t i = 0; i < matrix->size1; i++) {
                for (size_t j = 0; j < matrix->size2; j++) {
                        gsl_complex melem = gsl_matrix_complex_get(matrix, i, j);
                        if ((status = fprintf(f, "%lf %ci%lf ", GSL_REAL(melem),((GSL_IMAG(melem))<0)?' ':'+',GSL_IMAG(melem)) < 0))
                                return -1;
                        n += status;
                }
                if ((status = fprintf(f, "\n")) < 0)
                        return -1;
                n += status;
        }
	fprintf(f,"======== MATRIX %s END =========\n",title);
        return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix * invert_a_matrix(gsl_matrix *matrix) {
	int size = matrix->size1; int s;
	gsl_permutation *p = gsl_permutation_alloc(size);
	gsl_matrix *copy = gsl_matrix_alloc(size, size);

	gsl_matrix_memcpy(copy,matrix);
	gsl_linalg_LU_decomp(copy, p, &s);
	gsl_matrix *inv = gsl_matrix_alloc(size, size);
	gsl_linalg_LU_invert(copy, p, inv);

	gsl_matrix_free(copy);
	gsl_permutation_free(p);
	return inv;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix_complex * invert_a_complex_matrix(gsl_matrix_complex *matrix) {
	int size = matrix->size1; int s;
	gsl_permutation *p = gsl_permutation_alloc(size);
	gsl_matrix_complex *copy = gsl_matrix_complex_alloc(size, size);

	gsl_matrix_complex_memcpy(copy,matrix);
	gsl_linalg_complex_LU_decomp(copy, p, &s);
	gsl_matrix_complex *inv = gsl_matrix_complex_alloc(size, size);
	gsl_linalg_complex_LU_invert(copy, p, inv);

	gsl_matrix_complex_free(copy);
	gsl_permutation_free(p);
	return inv;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void row_matrix_prod_in_place(gsl_vector *vector, gsl_matrix *matrix, gsl_vector *result){
	for(int column = 0; column < matrix->size2; column++){
		double sum = 0;
		for(int row = 0; row < matrix->size1; row++)
			sum += gsl_vector_get(vector, row) * gsl_matrix_get(matrix, row, column);
		gsl_vector_set(result, column, sum);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector *row_matrix_prod(gsl_vector *vector, gsl_matrix *matrix){
	gsl_vector *result = gsl_vector_calloc(vector->size);

	for(int column = 0; column < matrix->size2; column++){
		double sum = 0;
		for(int row = 0; row < matrix->size1; row++)
			sum += gsl_vector_get(vector, row) * gsl_matrix_get(matrix, row, column);
		gsl_vector_set(result, column, sum);
	}
	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void matrix_matrix_prod(gsl_matrix *A, gsl_matrix *B, gsl_matrix* result){
	for(int row = 0; row < A->size1; row++){
		for(int column = 0; column < B->size2; column++){
			double sum = 0;
			for(int i = 0; i < B->size2; i++)
				sum += gsl_matrix_get(A, row,i) * gsl_matrix_get(B, i, column);
			gsl_matrix_set(result, row, column, sum);
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double row_column_prod(gsl_vector *row_vector, gsl_vector *column_vector){
	double product = 0;
	for(int index = 0; index < row_vector->size; index++)
		product += gsl_vector_get(row_vector, index) * gsl_vector_get(column_vector, index);
	return product;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector_complex *row_matrix_prod_complex(gsl_vector_complex *vector, gsl_matrix_complex *matrix){
	int m = vector->size;

	gsl_vector_complex *result = gsl_vector_complex_calloc(m);
	for(int column = 0; column < matrix->size2; column++){
		gsl_complex sum = gsl_complex_rect(0,0);
		for(int row = 0; row < matrix->size1; row++){
			gsl_complex vecelem = gsl_vector_complex_get(vector,row);
			gsl_complex matelem = gsl_matrix_complex_get(matrix,row,column);
			sum = gsl_complex_add(sum, gsl_complex_mul(vecelem,matelem));   
		}
		gsl_vector_complex_set(result, column, sum);
	}
	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector_complex *gsl_vector_clone_double_to_complex(gsl_vector *v){
	int m = v->size;
	gsl_vector_complex *c = gsl_vector_complex_calloc(m);
	for(int i = 0; i < v->size; i++)
		gsl_vector_complex_set(c,i,gsl_complex_rect(gsl_vector_get(v,i),0));
	return c;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix_complex *gsl_matrix_clone_double_to_complex(gsl_matrix *md){
	int m = md->size1;
	gsl_matrix_complex *mc = gsl_matrix_complex_calloc(m,m);
	for(int row = 0; row < md->size1; row++)
		for(int col = 0; col < md->size2; col++)
			gsl_matrix_complex_set(mc,row,col,gsl_complex_rect(gsl_matrix_get(md,row,col),0));
	return mc;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double moment_H(int order, int mmpp_index, double *h){
	if(stype == EXPONENTIAL){
        	return gsl_sf_fact(order)/ pow(1/h[mmpp_index],order);
	}
	else if(stype == DETERMINISTIC){
		return pow(h[mmpp_index],order);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_complex H(gsl_complex s, int mmpp_index, double *h){
	if(stype == EXPONENTIAL){
	        gsl_complex mu_z = gsl_complex_rect(1/h[mmpp_index],0);
        	return gsl_complex_div(mu_z, gsl_complex_add(mu_z,s));
	}
	else if(stype == DETERMINISTIC){
		gsl_complex exponent = gsl_complex_rect(-h[mmpp_index],0);
		exponent = gsl_complex_mul(exponent,s);
		return gsl_complex_exp(exponent);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_complex complex_LST(gsl_complex s, int mmpp_index, int *ids, int *nclients, double *h){
	int m = nclients[mmpp_index] + 1;
	int mmpp_id = ids[mmpp_index];

	gsl_vector_complex *g_z = gsl_vector_clone_double_to_complex(g[mmpp_id]);
	gsl_vector_complex *pie_z = gsl_vector_clone_double_to_complex(pie[mmpp_id]);
	gsl_matrix_complex *LAMBDA_z = gsl_matrix_clone_double_to_complex(LAMBDA[mmpp_id]);
	gsl_matrix_complex *Q_z = gsl_matrix_clone_double_to_complex(Q[mmpp_id]);

	gsl_complex zero_z = gsl_complex_rect(0,0);
	gsl_complex one_z = gsl_complex_rect(1,0);
	gsl_complex rho_z = gsl_complex_rect(rho[mmpp_id],0);
	gsl_complex one_minus_rho_z = gsl_complex_rect(1-rho[mmpp_id],0);
	gsl_complex ret_val = gsl_complex_rect(0,0);
	gsl_vector_complex *W = gsl_vector_complex_calloc(m);
	if(gsl_complex_abs(s) == 0){
		gsl_vector_complex_memcpy(W, pie_z);
	}
	else{
		gsl_complex one_minus_H = gsl_complex_sub(one_z,H(s, mmpp_index, h));
		gsl_matrix_complex *L_times_one_minus_H = gsl_matrix_complex_calloc(m,m); 
		gsl_matrix_complex *Q_minus_L_times_one_minus_H = gsl_matrix_complex_calloc(m,m);
		gsl_matrix_complex *SQUARE_BRCK = gsl_matrix_complex_calloc(m,m);

		gsl_matrix_complex_memcpy(L_times_one_minus_H,LAMBDA_z);
		gsl_matrix_complex_scale(L_times_one_minus_H, one_minus_H);
		gsl_matrix_complex_memcpy(Q_minus_L_times_one_minus_H, Q_z);
		gsl_matrix_complex_sub(Q_minus_L_times_one_minus_H, L_times_one_minus_H);
		gsl_matrix_complex_set_identity(SQUARE_BRCK);
		gsl_matrix_complex_scale(SQUARE_BRCK, s);
		gsl_matrix_complex_add(SQUARE_BRCK, Q_minus_L_times_one_minus_H);

		gsl_matrix_complex *SQUARE_BRCK_inverse = invert_a_complex_matrix(SQUARE_BRCK);
		gsl_vector_complex * result = row_matrix_prod_complex(g_z, SQUARE_BRCK_inverse);
		// COMPUTATION OF s(1-rho): to obtain CDF F(s)/s must be inverted therefore I do not multiply by s!!
		// and just scale by 1 - rho
		gsl_complex scale_factor = one_minus_rho_z;
		gsl_vector_complex_scale(result, scale_factor);
		// Multiply by H(s) since sojourn time is the sum of waiting and service
		scale_factor = H(s, mmpp_index, h);
		gsl_vector_complex_scale(result, scale_factor);
		gsl_vector_complex_memcpy(W, result);

		gsl_matrix_complex_free(L_times_one_minus_H);
		gsl_matrix_complex_free(Q_minus_L_times_one_minus_H);
		gsl_matrix_complex_free(SQUARE_BRCK);
		gsl_matrix_complex_free(SQUARE_BRCK_inverse);
		gsl_vector_complex_free(result);
	}
	for(int i = 0; i < m; i++)
		ret_val = gsl_complex_add(ret_val, gsl_vector_complex_get(W, i));
	gsl_vector_complex_free(pie_z);
	gsl_vector_complex_free(g_z);
	gsl_matrix_complex_free(LAMBDA_z);
	gsl_matrix_complex_free(Q_z);
	gsl_vector_complex_free(W);
	return ret_val;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_mmpp(double x, int mmpp_index, int *ids, int *nclients, double *h){
	gsl_complex hnT = gsl_complex_rect(0,0);
	gsl_complex T_z = gsl_complex_rect(x,0);
	
	for (int k = 0; k < n_inverse; k++){
		gsl_complex etak = gsl_complex_rect(eta_re[k], eta_im[k]);
		gsl_complex betak = gsl_complex_rect(beta_re[k], beta_im[k]);
		gsl_complex funarg = gsl_complex_div(betak, T_z);
		hnT = gsl_complex_add(hnT,gsl_complex_mul(etak, complex_LST(funarg, mmpp_index, ids, nclients, h)));
	}
	hnT = gsl_complex_div(hnT, T_z);
	return GSL_REAL(hnT);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_max_mmpp(double x, int n_fog_nodes, int *ids, int *nclients, double *h){
	double pret = 1;

	for(int i = 0; i < n_fog_nodes; i++)
		pret *= CDF_mmpp(x, i, ids, nclients, h);
//	fprintf(stdout,"CDFofMAX(x=%lf)=%lf\n",x,pret);
	return pret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_max_mmpp_checked(double x, int n_fog_nodes, int *ids, int *nclients, double *h){
	double pret = 1;

	for(int i = 0; i < n_fog_nodes; i++){
		double p = CDF_mmpp(x, i, ids, nclients, h);
		if( p > 1)
			p = 1;
		else if (p < 0)
			p = 0;
		pret *= p;
	}
//	fprintf(stdout,"CDFofMAX(x=%lf)=%lf\n",x,pret);
	return pret;
}
#ifdef GSL
struct CDFpars{
        int n_fog_nodes;
};
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_mmpp_to_integrate_by_GSL(double x, void *params){
	struct CDFpars *CDFp = (struct CDFpars *)params;
	int n_fog_nodes = CDFp->n_fog_nodes;
	return 1 - CDF_max_mmpp(x, n_fog_nodes, nclients, h);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_average_of_MMPP_by_GSL(int n_fog_nodes, double b){
        gsl_integration_workspace *w = gsl_integration_workspace_alloc(LIMIT);
        double result, error;

        gsl_function F;
        F.function = &CDF_mmpp_to_integrate_by_GSL;
        struct CDFpars params;
        params.n_fog_nodes = n_fog_nodes;
        F.params = &params;

	double a = 0;
	int key = 1; // CORRESPONDS TO GAUSS_KONROD 61 point rules key=1,2,..,6
        gsl_integration_qag(&F, a, b, ABS_ERR, REL_ERR, LIMIT, key, w, &result, &error);
        gsl_integration_workspace_free (w);
        return result;
}
#endif
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_average_of_CCDF(int n_fog_nodes, int *ids, int *nclients, double *h){
	double eps_incr = 1e-4;
	double yp = 1, yc = 1, xc;

	double hmin = DBL_MAX;
	for(int i = 0; i < n_fog_nodes; i++)
		if( h[i] < hmin )
			hmin = h[i];
	double step = hmin / npoints; // This is OK for any service distribution

	double w = 0;
	for(xc = step; ; xc += step){ 
		yc = 1 - CDF_max_mmpp(xc, n_fog_nodes, ids, nclients, h);
		if(yc > 0 && yc <= 1 ){ 
			w += step * (yp + yc) / 2;
			fprintf(stdout,"(%lf,%lf) integral %lf\n",xc,yc,w);
			if( yp < eps_incr && yc < eps_incr && fabs(yp - yc) < eps_incr)
				break;
			yp = yc;
		}
		else {
			fprintf(stdout,"(%lf,%lf) integral %lf turned into ",xc,yc,w);
			yc = 0;
			w += step * (yp + yc) / 2;
			fprintf(stdout,"(%lf,%lf) integral %lf by summing %lf where yp = %lf\n",xc,yc,w,step*(yp+yc)/2,yp);
			break;
		}
	}
	xmax = xc - step;
	fprintf(stdout,"eval : xmax = %lf\n",xmax);
//	w = compute_average_of_MMPP_by_GSL(n_fog_nodes, xmax);
//	fprintf(stdout,"wm GSL integrated is %lf\n",w);
	return w;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector * my_my_solve_DTMC(gsl_matrix *data, char name[]){
int size = data->size1;

// FOR DTMC SOLUTION LOOK HERE: https://nicolewhite.github.io/2014/06/10/steady-state-transition-matrix.html
	gsl_vector *x = gsl_vector_calloc(size);
	// Adding a bottom row [1,1,..1] to matrix
	gsl_matrix *P = gsl_matrix_alloc(size + 1, size);
	for(int row = 0; row < size; row++)
		for(int col = 0; col < size; col++)
			gsl_matrix_set(P,row,col,gsl_matrix_get(data,row,col));
	for(int col = 0; col < size; col++)
		gsl_matrix_set(P,size,col,1);
	gsl_vector *b = gsl_vector_calloc(size+1);
	gsl_vector_set_zero(b);
	gsl_vector_set(b,size,1);

	gsl_vector *tau = gsl_vector_alloc(size);
	gsl_vector *residual = gsl_vector_alloc(size+1);
	gsl_linalg_QR_decomp(P, tau);
	gsl_linalg_QR_lssolve(P, tau, b, x, residual);
// FOR DTMC SOLUTION LOOK HERE: https://nicolewhite.github.io/2014/06/10/steady-state-transition-matrix.html
#ifdef DEBUG_DTMC
	print_vector(stdout,x,name);
	double sum = 0;
	for(int i = 0; i < size; i++)
		sum += gsl_vector_get(x,i);
	fprintf(stdout,"sum of %s is %lf\n",name,sum);
#endif
	gsl_matrix_free(P);
	gsl_vector_free(tau);
	gsl_vector_free(residual);
	gsl_vector_free(b);
	return x;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double gsl_my_matrix_norm(gsl_matrix *matrix){
	double matrix_norm = 0;

	for (int j = 0; j < matrix->size1; j++){
		gsl_vector_view column = gsl_matrix_column (matrix, j);
		matrix_norm += gsl_blas_dnrm2 (&column.vector);
	}
	return matrix_norm;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double psi(int n, double h, double THETA){
	double psi_ret;

	if(stype == DETERMINISTIC){
		if( n > 0 )
			psi_ret = exp(-THETA * h) * pow((THETA * h) / n,n);
		else
			psi_ret = exp(-THETA * h);
	} 
	else if(stype == EXPONENTIAL){
		psi_ret = ((1/h) * pow(THETA,n)) / pow((1/h) +  THETA, n + 1);
	}
	if(isnan(psi_ret)){
		psi_ret = 0;
		fprintf(stdout,"Alert!! Computed psi(%d...) = NaN!!\n",n);
	}
	return psi_ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void gsl_matrix_normalize(gsl_matrix *matrix){
	int size = matrix->size1;

	for(int row = 0; row < size; row++){
		double row_sum = 0;
		for(int col = 0; col < size; col++)
			row_sum += gsl_matrix_get(matrix,row,col);
		for(int col = 0; col < size; col++)
			gsl_matrix_set(matrix,row,col,gsl_matrix_get(matrix,row,col) / row_sum);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void build_superposed_MMPP(int mmpp_index, double Ton, double Toff, double Lon, double Loff, int *nclients){
	int m = nclients[mmpp_index] + 1; 

	LAMBDA[mmpp_index] = gsl_matrix_calloc(m, m);
	for(int i = 0; i < m; i++)
		gsl_matrix_set(LAMBDA[mmpp_index], i, i, i * Lon + (nclients[mmpp_index] - i) * Loff);

	Q[mmpp_index] = gsl_matrix_calloc(m, m);
	for(int i = 0; i < m; i++){
		double row_sum = 0;
		if( i > 0 ) {
			gsl_matrix_set(Q[mmpp_index], i, i - 1, i/Ton);
			row_sum += gsl_matrix_get(Q[mmpp_index], i, i - 1);
		}
		if(i < m - 1) {
			gsl_matrix_set(Q[mmpp_index], i, i + 1, (m - i)/Toff);
			row_sum += gsl_matrix_get(Q[mmpp_index], i, i + 1);
		}
		gsl_matrix_set(Q[mmpp_index], i, i, -row_sum);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_MMPP(int mmpp_index, double Ton, double Toff, double Lon, double Loff, double *h){
	// Computing pie
	int m = Q[mmpp_index]->size1;

	gsl_matrix *DISCRETE_Q = gsl_matrix_calloc(m, m);
	for(int row = 0; row < m; row++){
		for(int col = 0; col < m; col++){
			if(row != col)
				gsl_matrix_set(DISCRETE_Q, row, col, gsl_matrix_get(Q[mmpp_index], row, col) / (-gsl_matrix_get(Q[mmpp_index], row, row)));
		}
	}

	gsl_matrix *P = gsl_matrix_calloc(m, m); // Used later
	gsl_matrix_memcpy(P,DISCRETE_Q);	
	gsl_matrix *I = gsl_matrix_calloc(m, m); // Used later
	gsl_matrix_set_identity(I); 
	gsl_matrix_sub(P,I); 
	gsl_matrix *DISCRETE_QT = gsl_matrix_calloc(m, m);
	gsl_matrix_transpose_memcpy(DISCRETE_QT,P);
	pie[mmpp_index] = my_my_solve_DTMC(DISCRETE_QT,"PIE");

	// Computing average lambda_tot, and rho
	lambda_tot[mmpp_index] = 0;
	for(int i = 0; i < m; i++)
		lambda_tot[mmpp_index] += gsl_vector_get(pie[mmpp_index], i) * gsl_matrix_get(LAMBDA[mmpp_index], i, i);
	rho[mmpp_index] = lambda_tot[mmpp_index] * h[mmpp_index];


	// Preparing constant matrix LAMBDA - Q
	gsl_matrix * LAMBDA_minus_Q = gsl_matrix_calloc(m, m);
	gsl_matrix_memcpy(LAMBDA_minus_Q, LAMBDA[mmpp_index]);
	gsl_matrix_sub(LAMBDA_minus_Q, Q[mmpp_index]);

	// Preparing constant matrix Q - LAMBDA
	gsl_matrix * Q_minus_LAMBDA = gsl_matrix_calloc(m, m);
	gsl_matrix_memcpy(Q_minus_LAMBDA, Q[mmpp_index]);
	gsl_matrix_sub(Q_minus_LAMBDA, LAMBDA[mmpp_index]);

	// Computing THETA
	double THETA = -DBL_MAX;
	for(int i = 0; i < m; i++){
		if(gsl_matrix_get(LAMBDA_minus_Q,i,i) > THETA){
			THETA = gsl_matrix_get(LAMBDA_minus_Q,i,i);
		}
	}
	// Computing n*
	double sum_of_psin = 0;
	int n = 0; int nstar; 
	double psin;
	do {
		psin = psi(n, h[mmpp_index], THETA);
		sum_of_psin += psin;
		n++;
	} while((sum_of_psin <= 1 - epsilon1) && n <= MAX_ITER && psin >= epsilon1);
	nstar = n - 1;

	// Computing psi's
	double psival[nstar + 1];
	for(int n = 0; n <= nstar; n++)
		psival[n] = psi(n, h[mmpp_index], THETA);

	// MATRIX ALLOCATION
	gsl_matrix ** H = (gsl_matrix **)calloc(nstar + 1,sizeof(gsl_matrix *));
	for(int i = 0; i <= nstar; i++)
		H[i] = gsl_matrix_calloc(m, m);
	gsl_matrix *LGPROD = gsl_matrix_calloc(m, m);
	gsl_matrix *THREE_TERMS = gsl_matrix_calloc(m, m);
	gsl_matrix *SQUAREBRCK = gsl_matrix_calloc(m, m);
	gsl_matrix *GDIFF = gsl_matrix_calloc(m, m);
	
	// Computing matrix G
	// Computing matrix G
	// Computing matrix G
	
	gsl_matrix *G = gsl_matrix_calloc(m, m);
	gsl_matrix *Gkp1 = gsl_matrix_calloc(m, m);
	gsl_matrix *Gk = gsl_matrix_calloc(m, m);
	gsl_matrix_set_zero(G);
	gsl_matrix_set_zero(Gk);
	int k = 1;
	while(TRUE){/* Main loop. Exiting when G(k)-G(k+1) is below epsilon */
		gsl_matrix_set_identity(H[0]);
		for(int i = 0; i < nstar; i++){
			matrix_matrix_prod(LAMBDA[mmpp_index], Gk, LGPROD);
			gsl_matrix_memcpy(THREE_TERMS, Q_minus_LAMBDA);
			gsl_matrix_add(THREE_TERMS, LGPROD);
			gsl_matrix_scale(THREE_TERMS, 1/THETA);
			gsl_matrix_set_identity(SQUAREBRCK);
			gsl_matrix_add(SQUAREBRCK, THREE_TERMS);
			matrix_matrix_prod(SQUAREBRCK, H[i], H[i+1]);
		}
		gsl_matrix_set_zero(Gkp1);
		for(int i = 0; i <= nstar; i++){
			gsl_matrix_scale(H[i], psival[i]);
			gsl_matrix_add(Gkp1, H[i]);
		}
		gsl_matrix_memcpy(GDIFF, Gk);
		gsl_matrix_sub(GDIFF, Gkp1);
		double mnorm = gsl_my_matrix_norm(GDIFF);
		if(mnorm < epsilon2 || k > MAX_ITER){
			gsl_matrix_memcpy(G, Gkp1);
			break;
		}
		k++;
		gsl_matrix_memcpy(Gk, Gkp1);
	}/* Main loop. Exiting when G(k)-G(k+1) is below epsilon */
	// Computing vector g 
	gsl_matrix_memcpy(P,G);
	gsl_matrix_normalize(P);
	gsl_matrix_sub(P,I);
	gsl_matrix *GT = gsl_matrix_calloc(m, m);
	gsl_matrix_transpose_memcpy(GT,P);
	g[mmpp_index] = my_my_solve_DTMC(GT,"g");
	// freeing what is used to compute g
	for(int i = 0; i <= nstar; i++)
		gsl_matrix_free(H[i]);
	free(H);
	gsl_matrix_free(LGPROD);
	gsl_matrix_free(THREE_TERMS);
	gsl_matrix_free(SQUAREBRCK);
	gsl_matrix_free(GDIFF);
	gsl_matrix_free(Gkp1);
	gsl_matrix_free(Gk);
	gsl_matrix_free(GT);
	gsl_matrix_free(G);
	gsl_matrix_free(LAMBDA_minus_Q);
	gsl_matrix_free(Q_minus_LAMBDA);
	gsl_matrix_free(I);
	gsl_matrix_free(P);
	gsl_matrix_free(DISCRETE_Q);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_WMED(int mmpp_index, int *nclients, double *h){
	// Compute wmed
	int m = nclients[mmpp_index] + 1;
	 

	gsl_vector *lambda_T = gsl_vector_calloc(m); 
	for(int i = 0; i < m; i++)
		gsl_vector_set(lambda_T,i,gsl_matrix_get(LAMBDA[mmpp_index], i, i));
//	rho[mmpp_index] = lambda_tot[mmpp_index] * h;

	gsl_vector * pie_LAMBDA = row_matrix_prod(pie[mmpp_index], LAMBDA[mmpp_index]);
	gsl_vector_scale(pie_LAMBDA, h[mmpp_index]); 
	gsl_vector *bracket = gsl_vector_calloc(m);
//	printf("HERE");
	gsl_vector_memcpy(bracket,g[mmpp_index]);
//	printf("AFTER HERE");
	gsl_vector_scale(bracket,1 - rho[mmpp_index]);
	gsl_vector_add(bracket, pie_LAMBDA);
	gsl_matrix *e_pie = gsl_matrix_calloc(m,m);
	for(int row = 0; row < m; row++)
		gsl_matrix_set_row(e_pie, row, pie[mmpp_index]);
	gsl_matrix *Q_plus_epie = gsl_matrix_calloc(m,m);
	gsl_matrix_memcpy(Q_plus_epie,Q[mmpp_index]);
	gsl_matrix_add(Q_plus_epie,e_pie);
	gsl_matrix *inv_Q_plus_epie = invert_a_matrix(Q_plus_epie);
	gsl_vector * three_prod = row_matrix_prod(bracket, inv_Q_plus_epie);
	gsl_vector_scale(three_prod,2*h[mmpp_index]);
	double wmed = row_column_prod(three_prod, lambda_T);
//	printf("wmed []*lT = %lf\n",wmed);
	wmed = 2 * rho[mmpp_index] + lambda_tot[mmpp_index] * moment_H(2, mmpp_index, h) - wmed; 
//	printf("2rho+Ltot*H(2) - wmed []*lT = %lf\n",wmed);
//	printf("rho = %lf - Ltot = %lf - H(2) = %lf - h = %lf\n",rho[mmpp_index], lambda_tot[mmpp_index], moment_H(2, mmpp_index,h), h[mmpp_index]);
	wmed = wmed / (2 *(1 - rho[mmpp_index]));
//	printf("(2rho+Ltot*H(2) - wmed []*lT)/ (2*(1-rho)) = %lf\n",wmed);
	wmed = wmed + h[mmpp_index];
//	printf("(2rho+Ltot*H(2) - wmed []*lT)/ (2*(1-rho)) + h= %lf\n",wmed);
	// freeing what is used to compute wmed
	gsl_vector_free(three_prod);			
	gsl_vector_free(bracket);			
	gsl_vector_free(pie_LAMBDA);			
	gsl_vector_free(lambda_T);
	gsl_matrix_free(e_pie);
	gsl_matrix_free(Q_plus_epie);
	gsl_matrix_free(inv_Q_plus_epie);
	return wmed;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void free_MMPP(int mmpp_index){
	gsl_matrix_free(LAMBDA[mmpp_index]);
	gsl_matrix_free(Q[mmpp_index]);
	gsl_vector_free(g[mmpp_index]);
	gsl_vector_free(pie[mmpp_index]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void build_and_solve_all_mmpp_queues(int n_fog_nodes , int *nclients, double *h, double Ton , double Toff , double Lon , double Loff ){
	fprintf(stdout,"building and solving for j:");
	fprintf(stdout,"n_fog_nodes : %d\n",n_fog_nodes);
	fprintf(stdout,"nclients: ");
	for(int i = 1; i < n_fog_nodes; i++)
		fprintf(stdout,"%d ",nclients[i]);
	fprintf(stdout,"\n");
	fprintf(stdout,"h: ");
	for(int i = 1; i < n_fog_nodes; i++)
		fprintf(stdout,"%lf ",h[i]);
	fprintf(stdout,"\n");
	fprintf(stdout,"Ton : %lf - ",Ton);
	fprintf(stdout,"Toff : %lf - ",Toff);
	fprintf(stdout,"Lon : %lf - ",Lon);
	fprintf(stdout,"Loff : %lf\n",Loff);
	stype = 'd';
	npoints = 5;

	w = (double *)calloc(n_fog_nodes, sizeof(double));
	lambda_tot = (double *)calloc(n_fog_nodes, sizeof(double));
	rho = (double *)calloc(n_fog_nodes, sizeof(double));

	g = (gsl_vector **)calloc(n_fog_nodes, sizeof(gsl_vector *));
	pie = (gsl_vector **)calloc(n_fog_nodes, sizeof(gsl_vector *));
	LAMBDA = (gsl_matrix **)calloc(n_fog_nodes, sizeof(gsl_matrix *));
	Q = (gsl_matrix **)calloc(n_fog_nodes, sizeof(gsl_matrix *));

	for(int i = 1; i < n_fog_nodes; i++){
		build_superposed_MMPP(i, Ton, Toff, Lon, Loff, nclients);
		compute_MMPP(i, Ton, Toff, Lon, Loff, h);
		w[i] = compute_WMED(i, nclients, h);
		fprintf(stdout,"MMPP %d : nclients = %d lambda = %lf, mu = %lf, rho = %lf h = %lf wisolated = %lf\n",i,nclients[i],lambda_tot[i],1/h[i],rho[i],h[i],w[i]);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_average_of_max( int n_fog_nodes , int *ids, int *nclients, double *h, double Ton , double Toff , double Lon , double Loff ){
	
	fprintf(stdout,"Running average latency for:");
	fprintf(stdout,"n_fog_nodes : %d - ",n_fog_nodes);
	fprintf(stdout,"FN ids: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%d ",ids[i]);
	fprintf(stdout," - ");
	fprintf(stdout,"nclients: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%d ",nclients[i]);
	fprintf(stdout," - ");
	fprintf(stdout,"h: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%lf ",h[i]);
	fprintf(stdout," - ");
	fprintf(stdout,"Ton : %lf - ",Ton);
	fprintf(stdout,"Toff : %lf - ",Toff);
	fprintf(stdout,"Lon : %lf - ",Lon);
	fprintf(stdout,"Loff : %lf\n",Loff);
	stype = 'd';
	npoints = 5;

	double average_of_max = compute_average_of_CCDF(n_fog_nodes, ids, nclients, h);
	fprintf(stdout,"Average latency = %lf\n",average_of_max);
	return average_of_max;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_deadline_probability(double deadline, int n_fog_nodes , int *ids, int *nclients, double *h, double Ton , double Toff , double Lon , double Loff ){
	fprintf(stdout,"Running deadline probability for deadline %lf :\n",deadline);
	fprintf(stdout,"n_fog_nodes : %d\n",n_fog_nodes);
	fprintf(stdout,"FN ids: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%d ",ids[i]);
	fprintf(stdout,"\n");
	fprintf(stdout,"nclients: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%d ",nclients[i]);
	fprintf(stdout,"\n");
	fprintf(stdout,"h: ");
	for(int i = 0; i < n_fog_nodes; i++)
		fprintf(stdout,"%lf ",h[i]);
	fprintf(stdout,"\n");
	fprintf(stdout,"Ton : %lf - ",Ton);
	fprintf(stdout,"Toff : %lf - ",Toff);
	fprintf(stdout,"Lon : %lf - ",Lon);
	fprintf(stdout,"Loff : %lf\n",Loff);
	stype = 'd';
	npoints = 5;
	double deadline_probability = CDF_max_mmpp_checked(deadline, n_fog_nodes, ids, nclients, h);
	fprintf(stdout,"P(LATENCY < %lf) = %lf\n",deadline,deadline_probability);
	return deadline_probability;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void free_all_mmpp_queues(int n_fog_nodes){

	for(int i = 1; i < n_fog_nodes; i++){
		free_MMPP(i);
	}
	free(Q); free(LAMBDA); free(g); free(pie); free(w);
	free(lambda_tot); free(rho); 
}
#ifdef MAIN
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 8){
		fprintf(stdout,"usage: %s n_fog_nodes T_on T_off Lambda_on Lambda_off service_distribution n_points\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	int n_fog_nodes = atoi(argv[1]);
	double Ton = atof(argv[2]);
	double Toff = atof(argv[3]);
	double Lon = atof(argv[4]);
	double Loff = atof(argv[5]);
	stype = argv[6][0]; // values can only be m (exponential) or d (deterministic)
	npoints = atoi(argv[7]);

	nclients = (int *)calloc(n_fog_nodes, sizeof(int));
	w = (double *)calloc(n_fog_nodes, sizeof(double));
	lambda_tot = (double *)calloc(n_fog_nodes, sizeof(double));
	rho = (double *)calloc(n_fog_nodes, sizeof(double));
	h = (double *)calloc(n_fog_nodes, sizeof(double));

	g = (gsl_vector **)calloc(n_fog_nodes, sizeof(gsl_vector *));
	pie = (gsl_vector **)calloc(n_fog_nodes, sizeof(gsl_vector *));
	LAMBDA = (gsl_matrix **)calloc(n_fog_nodes, sizeof(gsl_matrix *));
	Q = (gsl_matrix **)calloc(n_fog_nodes, sizeof(gsl_matrix *));


	for(int i = 0; i < n_fog_nodes; i++){
		nclients[i] = 10 + 20 *i;
		h[i] = ((double)1 / nclients[i]) * 0.9;
	}

	for(int i = 0; i < n_fog_nodes; i++){
		build_superposed_MMPP(i, Ton, Toff, Lon, Loff);
//		fprintf(stdout,"Building done!\n");
		compute_MMPP(i, Ton, Toff, Lon, Loff);
//		fprintf(stdout,"Computing done!\n");
		w[i] = compute_WMED(i);
//		fprintf(stdout,"wm for process %d computed : it is %lf\n",i,w[i]);
	}
	double average_of_max = CDF_max_mmpp(deadline, n_fog_nodes, nclients, h);

	for(int i = 0; i < n_fog_nodes; i++){
		free_MMPP(i);
	}
	free(Q); free(LAMBDA); free(g); free(pie); free(nclients); free(w);
	free(lambda_tot); free(rho); free(h);
	return EXIT_SUCCESS;
}
#endif
