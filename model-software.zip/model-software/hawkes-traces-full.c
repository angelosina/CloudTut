// BASED ON 
// Yuan, B., Li, H., Bertozzi, A. L., Brantingham, P. J., & Porter, M. A. 
// Multivariate spatiotemporal hawkes processes and network reconstruction 
// SIAM Journal on Mathematics of Data Science, 2019, 1(2), 356-382.
// Algorithm 3.3

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_combination.h>
#include <gsl/gsl_sort.h>

//#define DEBUG
#define TRUE 1
#define FALSE 0

#define BACKGROUND 66
#define TRIGGERED 84

#define MAX_STRING 256

gsl_ran_discrete_t **f;

unsigned int n_events = 0;
double T = -1;
double R = 0;
int C = -1;
int N = -1;
int ordered_flag = TRUE;
unsigned long int seed = 0;

double *tau_f = NULL;
double **K_ = NULL;
unsigned int *cardinality_ = NULL;

double w = 2.0;
double sigma_x = 1;
double sigma_y = 1;
double rho = 0;

FILE *fp = NULL;
char dummy[MAX_STRING];
char dummychar;
unsigned int dummyint;

typedef struct node { 
	int u; // It is fog node id
	double x;
	double y; // It is physical coordinates of fog node
	double t; // It is client request time
	double t_father;
	int u_father;
	unsigned int id_father;
	char type;
	unsigned int id;
	struct node* next; 

} Node; 

Node* STACK = NULL;
Node* SET = NULL;

Node *free_h = NULL;
unsigned int n_free = 0;

Node* newNode(int u, double x, double y, double t, char type, int father, unsigned int id, double t_father, unsigned int id_father){ 
	Node* temp;

	if(free_h == NULL){
		temp = (Node*)malloc(sizeof(Node)); 
	}
	else{
		temp = free_h;
		free_h = free_h->next;
		n_free--;
	}
	temp->u = u; 
	temp->x = x; 
	temp->y = y; 
	temp->t = t; 
	temp->type = type; 
	temp->u_father = father; 
	temp->id = id; 
	temp->t_father = t_father; 
	temp->id_father = id_father; 
	temp->next = NULL; 
	return temp; 
} 

int peek_u(Node** head) { return (*head)->u; } 
double peek_x(Node** head) { return (*head)->x; } 
double peek_y(Node** head) { return (*head)->y; } 
double peek_t(Node** head) { return (*head)->t; } 
char peek_type(Node** head) { return (*head)->type; } 
int peek_u_father(Node** head) { return (*head)->u_father; } 
double peek_t_father(Node** head) { return (*head)->t_father; } 
unsigned int peek_id(Node** head) { return (*head)->id; } 
unsigned int peek_id_father(Node** head) { return (*head)->id_father; } 

void print_event(Node** event){
	int u_i = peek_u(event);
	double x_i = peek_x(event);
	double y_i = peek_y(event);
	double t_i = peek_t(event);
	char type_i = peek_type(event);
	int father_i = peek_u_father(event);
	double t_father_i = peek_t_father(event);
	unsigned int id_i = peek_id(event);
	unsigned int id_father_i = peek_id_father(event);

	fprintf(stdout,":: EVENT :: type %c : id %u : u %d : x %lf : y %lf : t %lf :: FATHER :: t_father %lf : u_father %d : id_father %u\n", type_i,id_i, u_i, x_i, y_i, t_i, t_father_i, father_i, id_father_i); 
}
void print_stack(){
	unsigned int n = 0;
	fprintf(stdout,"STACK IS\n---------------\n");
	if(STACK != NULL){
		for(Node* event = STACK; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY STACK\n");
	fprintf(stdout,"length = %u\n",n);
}
void print_set(){
	unsigned int n = 0;
	fprintf(stdout,"SET IS\n---------------\n");
	if(SET != NULL){
		for(Node* event = SET; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY SET\n");
	fprintf(stdout,"length = %u\n",n);
}
void print_free(){
	unsigned int n = 0;
	fprintf(stdout,"FREE LIST IS\n---------------\n");
	if(free_h != NULL){
		for(Node* event = free_h; event != NULL ; n++, event = event->next)
			print_event(&event);
	}
	else
		fprintf(stdout,"EMPTY FREE LIST\n");
	fprintf(stdout,"length = %u\n",n);
}
void pop(Node** head) { 
	Node* temp = *head; 
	(*head) = (*head)->next; 

	if(free_h == NULL){
		free_h = temp;
		free_h->next = NULL;
	}
	else{
		temp->next = free_h;
		free_h = temp;
	}
	n_free++;
} 
void push(Node** head, int u, double x, double y, double t, char type, int father, unsigned int id, double t_father, unsigned int id_father) { 
	Node*  temp = newNode(u, x, y, t, type, father, id, t_father, id_father); 
	if(*head != NULL){
		temp->next = *head; 
	}
	(*head) = temp; 
} 
void insert(Node** head, int u, double x, double y, double t, char type, int father, unsigned int id, double t_father, unsigned int id_father) { 
	Node* start = (*head); 
	Node* temp = newNode(u, x, y, t, type, father, id, t_father, id_father); 

	if ((*head)->t > t) { 
		temp->next = *head; 
		(*head) = temp; 
	} 
	else { 
		while (start->next != NULL && start->next->t < t) { 
			start = start->next; 
		} 
		temp->next = start->next; 
		start->next = temp; 
	} 
} 
int isEmpty(Node** head) { return (*head) == NULL; } 

void allocate_structures(){
	fscanf(fp,"%s %d",dummy,&N);
	fscanf(fp,"%s %d",dummy,&C);

	tau_f = (double *)calloc(C, sizeof(double));
	cardinality_ = (unsigned int *)calloc(C, sizeof(unsigned int));
	K_ = (double **)calloc(C, sizeof(double *));
	for(int u = 0; u < C; u++)
		K_[u] = (double *)calloc(C, sizeof(double));

}
void deallocate_structures(){
	free(tau_f);
	free(cardinality_);
	for(int u = 0; u < C; u++)
		free(K_[u]);
	free(K_);
	for(int u = 0; u < C; u++)
		gsl_ran_discrete_free(f[u]);
	free(f);

	Node* temp;
	while (SET != NULL){
		temp = SET;
		SET = SET->next;
		free(temp);
	}
	while (STACK != NULL){
		temp = STACK;
		STACK = STACK->next;
		free(temp);
	}
	while (free_h != NULL){
		temp = free_h;
		free_h = free_h->next;
		free(temp);
	}
}
void init_structures(){

	fgets(dummy, MAX_STRING, fp);
	for(int u = 0; u < C; u++){
		fscanf(fp,"%s %u %c %u %lf",dummy,&dummyint,&dummychar,&cardinality_[u],&tau_f[u]);
		tau_f[u] *= N;
		fprintf(stdout,"%s %u %c %u %lf\n",dummy,dummyint,dummychar,cardinality_[u],tau_f[u]);
	}
	for(int u = 0; u < C; u++){
		for(int v = 0; v < C; v++){
			fscanf(fp,"%lf",&K_[u][v]);
		}
	}
//	for(int u = 0; u < C; u++){
//		for(int v = 0; v < C; v++){
//			fprintf(stdout,"%lf ",K_[u][v]);
//		}
//		fprintf(stdout,"\n");
//	}
	fscanf(fp,"%s %lf",dummy,&T);
//	fprintf(stdout,"%s %lf\n",dummy,T);
	fscanf(fp,"%s %lf",dummy,&R);
//	fprintf(stdout,"%s %lf\n",dummy,R);
	fscanf(fp,"%s %lf",dummy,&w);
//	fprintf(stdout,"%s %lf\n",dummy,w);
	fscanf(fp,"%s %lf",dummy,&sigma_x);
//	fprintf(stdout,"%s %lf\n",dummy,sigma_x);
	fscanf(fp,"%s %lf",dummy,&sigma_y);
//	fprintf(stdout,"%s %lf\n",dummy,sigma_y);
	fscanf(fp,"%s %lf",dummy,&rho);
//	fprintf(stdout,"%s %lf\n",dummy,rho);
	
//	for(int u = 0; u < C; u++)
//		tau_f[u] = u + 1;

/*	for(int u = 0; u < C; u++){
		for(int v = 0; v < C; v++){
			if(u == v)
				K_[u][v] = 1.0 / C;
			else
				K_[u][v] = 1.0 / (2 * C);
		}
	}
*/

	f = (gsl_ran_discrete_t **)calloc(C, sizeof(gsl_ran_discrete_t *));
	for(int u = 0; u < C; u++)
		f[u] = gsl_ran_discrete_preproc(C,K_[u]);
}

void generate_background_events(gsl_rng *r){
	unsigned int Nb[C];

	for(unsigned int u = 0; u < C; u++){
		Nb[u] = gsl_ran_poisson(r, tau_f[u] * T);
	}
	for(int u = 0; u < C; u++){
		for(unsigned int i = 0; i < Nb[u]; i++){
			double t = gsl_ran_flat(r, 0, T);
			double x = gsl_ran_flat(r, -R, R);
			double y = gsl_ran_flat(r, -R, R);
			n_events++;
			push(&STACK, u, x, y, t, BACKGROUND, -1, n_events, -1, 0); 
			if(ordered_flag)
				insert(&SET, u, x, y, t, BACKGROUND, -1, n_events, -1, 0); 
			else
				push(&SET, u, x, y, t, BACKGROUND, -1, n_events, -1, 0); 

		}
	}
}
void generate_triggered_events(gsl_rng *r, Node** event){
	double t_i = peek_t(&STACK);
	if(t_i >= 0){
		int u_i = peek_u(&STACK);
		double x_i = peek_x(&STACK);
		double y_i = peek_y(&STACK);
		unsigned int id_i = peek_id(&STACK);

		double lambda_i = 0;
		for(int uprime = 0; uprime < C; uprime++)
			lambda_i += K_[u_i][uprime];
		unsigned int n_i = gsl_ran_poisson(r, lambda_i);

		pop(&STACK); 
		for(unsigned int k = 0; k < n_i; k++){
			int u_k = gsl_ran_discrete(r,f[u_i]);
			double t_k = t_i + gsl_ran_exponential(r, 1.0/w);
			double dx,dy; gsl_ran_bivariate_gaussian(r, sigma_x, sigma_y, rho, &dx, &dy);
			double x_k = x_i + dx;
			double y_k = y_i + dy;
			if(t_k <= T){
				n_events++;
				push(&STACK, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i); 
				if(ordered_flag)
					insert(&SET, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i); 
				else
					push(&SET, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i); 
			}
		}
	}
}
int main (int argc, char *argv[]){ 
	char c;
	char par_file[MAX_STRING];

	while ((c = getopt (argc, argv, "f:s:h")) != -1)
	switch (c) {
                case 'f':
                        strcpy(par_file,optarg);
                        break;
                case 's':
                        seed = (unsigned)atol(optarg);
                        break;
                case 'h':
                        fprintf(stderr,"usage: %s -f (pathname) -s (seed) -h (help)\n",argv[0]);
                        exit(EXIT_FAILURE);
                default:
                        fprintf(stderr,"Abort: something is wrong in command line options\n");
                        exit(EXIT_FAILURE);
        }
	const gsl_rng_type *TT;
	gsl_rng *r;

	gsl_rng_env_setup();
	TT = gsl_rng_default;
	r = gsl_rng_alloc (TT);
	gsl_rng_set(r,seed);

	fp = fopen(par_file,"r");
	allocate_structures();
	init_structures();
	fclose(fp);

	STACK = newNode(-1, -1, -1, -1, BACKGROUND, -1, 0, -1, 0); 
	SET = newNode(-1, -1, -1, -1, BACKGROUND, -1, 0, -1, 0); 


	generate_background_events(r);

	while (!isEmpty(&STACK) && peek_t(&STACK) >= 0) { 
		generate_triggered_events(r,&STACK);
	} 
	print_set();

	deallocate_structures();
	gsl_rng_free (r);

	return 0; 
} 


