#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
 
int ccc(int n, int m){
	int sum = 0;
	for(int i = 0; i <= m; i++)
		sum += (n - i) <= m;
	return sum;
}
int max(int a, int b){
	return (a>b)?a:b;
}

int main(int argc, char *argv[]){

	for(int n = 1; n <= 60; n++)
		for(int m = 1; m <= n; m++)
			fprintf(stdout,"ccc(n %d, m %d) = %d vs %d - %s\n",n,m,ccc(n,m),max(0,2*m-n+1),ccc(n,m)==max(0,2*m-n+1)?"OK":"FAIL");
}
