#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

//#define OUT 
#define UNKNOWN -1
#define TRUE 1
#define FALSE 0

int L = 0;
int r = 0;
int ncode = 0;
int kcode = 0;
int F = 0;
int c = 0;
int N = 0;
int max_time = 0;


double multinomial_phit = 0;
double multinomial_partial_phit = 0;
double poissonized_phit = 0;
double poissonized_partial_phit = 0;

double *p = NULL;
char *active_FN = NULL;

double **file_allocation = NULL;
int **rp = NULL;
double ***mobility_pie = NULL;
double ***mobility_transition_probabilities = NULL;

extern double Pcumulative_sum_of_binomials(int , int , int , double *);
extern void row_matrix_product(double *, double *, double **, int );

#define CDF_SHIFTED_EXP(x,lambda,tau) ((x >= tau)?(1 - exp(-lambda*(x - tau))):0)

double CDF_max_shifted_exp(double x, double *lambda, double *tau, int nexp){
	double ret = 1;
	for(int exp_index = 0; exp_index < nexp; exp_index++)
		ret *= CDF_SHIFTED_EXP(x,lambda[exp_index],tau[exp_index]);
	return ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_rp(int **rp, int FN_id){
	int rp_card = get_FN_level(FN_id) + 1; // It shall be a function that will decide the cardinality of rp(i)

	rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
	rp[FN_id][0] = rp_card;
// It shall be the function we like: it is father relationship by now
	rp[FN_id][1] = FN_id;
	for(int rp_id = 2; rp_id <= rp[FN_id][0]; rp_id++){
		int previous_FN_id = rp[FN_id][rp_id-1];
		int FN_level = get_FN_level(previous_FN_id);
		int father = get_leftmost_id(FN_level - 1) + (previous_FN_id - get_leftmost_id(FN_level)) / r;
		rp[FN_id][rp_id] = father;
	}
// It shall be the function we like: it is father relationship by now
//	fprintf(stdout,"rp FN %d :",FN_id);
//	for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
//		fprintf(stdout," %d",rp[FN_id][rp_id]);
//	fprintf(stdout,"\n");
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_overall_load_to_each_FN(double *load_to_FN, double *average_number_of_clients, double *request_rate, double *rate_FN_service, double *sojourn_times, int **rp, int N, int T){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		load_to_FN[FN_id] = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
				load_to_FN[rp[FN_id][rp_id]] += average_number_of_clients[FN_id] * request_rate[FN_id];
			}
		}
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(load_to_FN[FN_id] < rate_FN_service[FN_id])
			sojourn_times[FN_id] = 1 / (1 - load_to_FN[FN_id] / rate_FN_service[FN_id]);
		else
			sojourn_times[FN_id] = UNKNOWN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_allocation_probabilities(int file_id){
	double sum_w = 0;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		int l = get_FN_level(FN_id);
		file_allocation[file_id][FN_id] = L - l + 1 + (file_id); // weights
		sum_w += file_allocation[file_id][FN_id];
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		file_allocation[file_id][FN_id] /= sum_w;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_average_number_of_clients_for_each_FN(double *average_number_of_clients, int N, double ***mobility_pie, int T){
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			double sum = 0;
			for(int nc = 0; nc <= c; nc++){
				sum += (nc * mobility_pie[FN_id][T][nc]);
//				fprintf(stdout,"mobility_pie(%d) = %lf : ",nc,mobility_pie[FN_id][T][nc]);
			}
//			fprintf(stdout,"\n");
			average_number_of_clients[FN_id] = sum;
//			fprintf(stdout,"average in %d : %lf\n",FN_id,average_number_of_clients[FN_id]);
//		}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_unfeasibility_for_each_FN(double *p_unfeasible_poisson, int F, int N, int ncode, unsigned int *FN_capacity, int T){
	double FN_allocation[F];

	for(int FN_id = 1; FN_id <= N; FN_id++){
		double sum_of_lambda = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_lambda += file_allocation[file_id][FN_id];
		sum_of_lambda *= ncode;
		p_unfeasible_poisson[FN_id]  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);

#ifdef UNUSED_FOR_MULTINOMIAL
		for(int file_id = 0; file_id < F; file_id++)
			FN_allocation[file_id] = file_allocation[file_id][FN_id];
//		for(int file_id = 0; file_id < F; file_id++)
//			fprintf(stdout,"%lf ",FN_allocation[file_id]);
//		fprintf(stdout,"\n");
		
		p_unfeasible_multinomial[FN_id] = Pcumulative_sum_of_binomials(FN_capacity[FN_id] + 1 , F , ncode , FN_allocation); // + 1 is because function computes P(S >= s)
//		fprintf(stdout,"Fog node %d : probability overallocating poisson %lf multinomial %lf\n",FN_id,p_unfeasible_poisson[FN_id],p_unfeasible_multinomial[FN_id]);
#endif
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_fog_nodes_state(int t_, int N, double *average_number_of_clients, double *load_to_FN, double *rate_FN_service, double *sojourn_times, double *p_unfeasible_poisson, double *multinomial_phit, double *poissonized_phit, int *capacity){
	fprintf(stdout,"Time %d : fog nodes status :\n",t_);
	for(int FN_id = 1; FN_id <= N ; FN_id++)
		fprintf(stdout,"FN %3d LVL %2d cap %3d nclnts %5.2lf\tload %5.2lf\tservice %5.2lf\toverload %s\tsojourn %5.3lf\tunfeas %.6lf\tmult phit %.6lf\tpoiss phit %.6lf\n",FN_id,get_FN_level(FN_id),capacity[FN_id],average_number_of_clients[FN_id],load_to_FN[FN_id],rate_FN_service[FN_id],(load_to_FN[FN_id] < rate_FN_service[FN_id])?"NO":"YES",sojourn_times[FN_id],p_unfeasible_poisson[FN_id],multinomial_phit[FN_id],poissonized_phit[FN_id]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_file_state(int t_, int file_id, double *multinomial_phit, double *poissonized_phit, double *popularity, double delay){
	fprintf(stdout,"\t\tTime %d : file %d pop %.6lf : hit poissonized %.6lf while multinomial %.6lf delay %5.3lf\n",t_,file_id,popularity[file_id],poissonized_phit[file_id],multinomial_phit[file_id],delay);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_transition_matrix(int T){
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int row = 0; row <= c; row++){
				double row_sum = 0;
				for(int column = 0; column <= c; column++){
					mobility_transition_probabilities[FN_id][row][column] = (column + 1) + (rand()%c);
					row_sum += mobility_transition_probabilities[FN_id][row][column];
				}
				for(int column = 0; column <= c; column++)
					mobility_transition_probabilities[FN_id][row][column] /= row_sum;
			}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 8){
		fprintf(stdout,"usage : %s L r n k F c maxT\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode = atoi(argv[3]);
	kcode = atoi(argv[4]);
	F = atoi(argv[5]);
	c = atoi(argv[6]);
	max_time = atoi(argv[7]);

	N = (pow(r,L+1) - 1)/(r - 1);

// DETERMINE WHICH FN CAN ISSUE REQUESTS
	active_FN = (char *)calloc(N + 1, sizeof(char));
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(FN_id >= get_leftmost_id(L) && FN_id <= get_rightmost_id(L))
		       active_FN[FN_id] = TRUE;
		else	
		       active_FN[FN_id] = FALSE;
// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
		set_allocation_probabilities(file_id);
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	double file_popularity[F];
	double popularity_sum = 0;
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] = file_id + 1;
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] /= popularity_sum;
// SET RP(i) RETURNED BY ROUTING/SEARCH ALGORITHM
	rp = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++){
//		rp[FN_id] = (int *)calloc(M + 1, sizeof(int));
		if(active_FN[FN_id])
			set_rp(rp,FN_id);
		else
			rp[FN_id] = NULL;
	}
// RATE A CLIENT INSISTING ON FOG NODE FN_id ISSUES A REQUEST 
	double rate_client_request[N+1];
	for(int FN_id = 1; FN_id <= N;  FN_id++){
		if(active_FN[FN_id])
			rate_client_request[FN_id] = FN_id;
		else
			rate_client_request[FN_id] = 0;
	}
// RATE A FOG NODES FULLFILS REQUESTS
	double rate_FN_service[N+1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rate_FN_service[FN_id] = (L - get_FN_level(FN_id) + 1) * ncode ; // weights
// FOG NODES CAPACITY
	unsigned int FN_capacity[N + 1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) *  3 ; // weights
// LOAD OFFERED TO A FOG NODES
	double load_to_FN[N+1];
// SOJOURN TIMES IN FOG NODES
	double sojourn_times[N+1];
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_pie = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id])
			mobility_pie[FN_id] = (double **)calloc(2,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			mobility_pie[FN_id][0] = (double *)calloc(c + 1,sizeof(double));
			mobility_pie[FN_id][1] = (double *)calloc(c + 1,sizeof(double));
		}
	}
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_transition_probabilities = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id])
			mobility_transition_probabilities[FN_id] = (double **)calloc(c + 1,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= c; nc++)
				mobility_transition_probabilities[FN_id][nc] = (double *)calloc(c + 1,sizeof(double));
		}
	}
// INITIALIZATION OF MARKOV CHAINS
	int T = 0, Tp1 = 1;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= c; nc++)
				mobility_pie[FN_id][T][nc] = 0;
			mobility_pie[FN_id][T][rand()%(c+1)] = 1;
		}
	}
	double average_number_of_clients[N + 1];
	double p_unfeasible_poisson[N + 1];

	double FN_average_multinomial_phit[N + 1];
	double FN_average_poissonized_phit[N + 1];
	double file_average_multinomial_phit[F];
	double file_average_poissonized_phit[F];
	double delay = 0;
	int N_FN = 0;
	double overall_multinomial_phit = 0;
	double overall_poissonized_phit = 0;
	double average_client_sum = 0;
	double p_feasible = 1;
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
	for( int t_ = 0; t_ <= max_time; t_++){/* For each time step */
		compute_average_number_of_clients_for_each_FN(average_number_of_clients, N, mobility_pie, T);
		compute_overall_load_to_each_FN(load_to_FN, average_number_of_clients, rate_client_request, rate_FN_service, sojourn_times,rp, N, T);
		compute_unfeasibility_for_each_FN(p_unfeasible_poisson, F, N, ncode, FN_capacity, T);
		for(int FN_id = 1; FN_id <= N; FN_id++)
			if(active_FN[FN_id])
				FN_average_multinomial_phit[FN_id] = FN_average_poissonized_phit[FN_id] = 0;
		for(int file_id = 0; file_id < F; file_id++)
			file_average_multinomial_phit[file_id] = file_average_poissonized_phit[file_id] = 0;
		for(int file_id = 0, delay = 0; file_id < F; file_id++){
			N_FN = 0;
			for(int FN_id = 1; FN_id <= N ; FN_id++){
				if(active_FN[FN_id]){
					double psum = 0;
					for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
						psum += file_allocation[file_id][rp[FN_id][rp_id]];
					multinomial_phit = gsl_cdf_binomial_Q(kcode - 1, psum, ncode);
					poissonized_phit = gsl_cdf_poisson_Q(kcode - 1, ncode * psum);
					FN_average_multinomial_phit[FN_id] += file_popularity[file_id] * multinomial_phit;
					FN_average_poissonized_phit[FN_id] += file_popularity[file_id] * poissonized_phit;
					file_average_multinomial_phit[file_id] += multinomial_phit;
					file_average_poissonized_phit[file_id] += poissonized_phit;
					delay = 0;
					for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
						if(sojourn_times[rp[FN_id][rp_id]] != UNKNOWN)
							delay += ( 2 * (rp_id+1) + sojourn_times[rp[FN_id][rp_id]]);
						else{
							delay = UNKNOWN;
							break;
						}
					}
					N_FN++;
				}
			}
			file_average_multinomial_phit[file_id] /= N_FN;
			file_average_poissonized_phit[file_id] /= N_FN;
//			print_file_state(t_, file_id, file_average_multinomial_phit, file_average_poissonized_phit, file_popularity, delay);
		}
		overall_multinomial_phit = overall_poissonized_phit = average_client_sum = 0;
		for(int FN_id = 1; FN_id <= N; FN_id++)
			if(active_FN[FN_id])
				average_client_sum += average_number_of_clients[FN_id];
		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				overall_multinomial_phit +=  (average_number_of_clients[FN_id]/average_client_sum) * FN_average_multinomial_phit[FN_id];
				overall_poissonized_phit +=  (average_number_of_clients[FN_id]/average_client_sum) * FN_average_poissonized_phit[FN_id];
			}
		}
		p_feasible = 1;
		for(int FN_id = 1; FN_id <= N; FN_id++)
			p_feasible *= (1 - p_unfeasible_poisson[FN_id]);

		print_fog_nodes_state(t_,N,average_number_of_clients,load_to_FN,rate_FN_service,sojourn_times,p_unfeasible_poisson,FN_average_multinomial_phit,FN_average_poissonized_phit,FN_capacity);
		fprintf(stdout,"----------------\nTime %d : Overall multinomial_phit = %lf vs overall poissonized %lf p_feasibile allocation poisson %lf\n",t_,overall_multinomial_phit,overall_poissonized_phit,p_feasible);

		set_transition_matrix(t_);

		for(int FN_id = 1; FN_id <= N; FN_id++)
			if(active_FN[FN_id])
				row_matrix_product(mobility_pie[FN_id][Tp1], mobility_pie[FN_id][T], mobility_transition_probabilities[FN_id], c + 1 );

		T = (t_ + 1) % 2; 
		Tp1 = (T+1) % 2;
	}

	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(rp[FN_id]);
	free(rp);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			free(mobility_pie[FN_id][0]);
			free(mobility_pie[FN_id][1]);
		}
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(mobility_pie[FN_id]);
	free(mobility_pie);

	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= c; nc++)
				free(mobility_transition_probabilities[FN_id][nc]);
		}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id]){
			free(mobility_transition_probabilities[FN_id]);
		}
	free(mobility_transition_probabilities);

	free(active_FN);

	return EXIT_SUCCESS;
}
