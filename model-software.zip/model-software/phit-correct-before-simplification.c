#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

//#define OUT 
#define UNKNOWN -1

int L = 0;
int r = 0;
int ncode = 0;
int kcode = 0;
int M = 0;
int F = 0;
int c = 0;
int N = 0;
int max_time = 0;


double multinomial_phit = 0;
double multinomial_partial_phit = 0;
double poissonized_phit = 0;
double poissonized_partial_phit = 0;

double *p = NULL;

double **file_allocation = NULL;
int **path_id = NULL;
double ***mobility_pie = NULL;
double ***mobility_transition_probabilities = NULL;

extern double Pcumulative_sum_of_binomials(int , int , int , double *);
extern void row_matrix_product(double *, double *, double **, int );

#define CDF_SHIFTED_EXP(x,lambda,tau) ((x >= tau)?(1 - exp(-lambda*(x - tau))):0)

double CDF_max_shifted_exp(double x, double *lambda, double *tau, int nexp){
	double ret = 1;
	for(int exp_index = 0; exp_index < nexp; exp_index++)
		ret *= CDF_SHIFTED_EXP(x,lambda[exp_index],tau[exp_index]);
	return ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_path_ids(int **path_id, int FN_id){
	int FN_level = get_FN_level(FN_id);
	int path_index = 0;

	path_id[FN_id][path_index++] = FN_id;
	if(FN_id > 1){
		int father = get_leftmost_id(FN_level-1)+(FN_id-get_leftmost_id(FN_level))/r;
		int links = 0;
		for(int level = FN_level - 1; level >= 0 && links < M; links++,level--){
			path_id[FN_id][path_index] = path_id[father][path_index-1];
			path_index++;
		}
	} 
	for(; path_index <= M; )
		path_id[FN_id][path_index++] = UNKNOWN;
//	fprintf(stdout,"path FN %d :",FN_id);
//	for(path_index = 0; path_index <= M; path_index++)
//		fprintf(stdout," %d",path_id[FN_id][path_index]);
//	fprintf(stdout,"\n");
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int set_distribution_parameters(int file_id, int **path_id, int FN_id, double *p_multinomial, double *lambda_poisson){
	double sum_p = 0;
	int path_length = 0;
	for(; path_length <= M ; path_length++){
		if(path_id[FN_id][path_length] != UNKNOWN){
			p_multinomial[path_length] = file_allocation[file_id][path_id[FN_id][path_length]];
			sum_p += p_multinomial[path_length];
		}
		else break;
	}
	p_multinomial[path_length] = 1 - sum_p;
	for(int i = 0; i <= path_length ; i++)
		lambda_poisson[i] = ncode * p_multinomial[i];
	return path_length;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_overall_load_to_each_FN(double *load_to_FN, double *average_number_of_clients, double *request_rate, double *rate_FN_service, double *sojourn_times, int **path_id, int N, int M, int T){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		load_to_FN[FN_id] = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int path_length = 0; path_id[FN_id][path_length] != UNKNOWN && path_length <= M; path_length++){
			load_to_FN[path_id[FN_id][path_length]] += average_number_of_clients[FN_id] * request_rate[FN_id];
		}
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(load_to_FN[FN_id] < rate_FN_service[FN_id])
			sojourn_times[FN_id] = 1 / (1 - load_to_FN[FN_id] / rate_FN_service[FN_id]);
		else
			sojourn_times[FN_id] = UNKNOWN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_allocation_probabilities(int file_id){
	double sum_w = 0;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		int l = get_FN_level(FN_id);
		file_allocation[file_id][FN_id] = L - l + 1 + (file_id); // weights
		sum_w += file_allocation[file_id][FN_id];
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		file_allocation[file_id][FN_id] /= sum_w;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_average_number_of_clients_for_each_FN(double *average_number_of_clients, int N, double ***mobility_pie, int T){
	for(int FN_id = 1; FN_id <= N; FN_id++){
		double sum = 0;
		for(int nc = 0; nc <= c; nc++){
			sum += (nc * mobility_pie[FN_id][T][nc]);
//			fprintf(stdout,"mobility_pie(%d) = %lf : ",nc,mobility_pie[FN_id][T][nc]);
		}
//		fprintf(stdout,"\n");
		average_number_of_clients[FN_id] = sum;
//		fprintf(stdout,"average in %d : %lf\n",FN_id,average_number_of_clients[FN_id]);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_unfeasibility_for_each_FN(double *p_unfeasible_poisson, double *p_unfeasible_multinomial, int F, int N, int ncode, unsigned int *FN_capacity, int T){
	double FN_allocation[F];

	for(int FN_id = 1; FN_id <= N; FN_id++){
		double sum_of_lambda = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_lambda += file_allocation[file_id][FN_id];
		sum_of_lambda *= ncode;
		p_unfeasible_poisson[FN_id]  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);

		for(int file_id = 0; file_id < F; file_id++)
			FN_allocation[file_id] = file_allocation[file_id][FN_id];
//		for(int file_id = 0; file_id < F; file_id++)
//			fprintf(stdout,"%lf ",FN_allocation[file_id]);
//		fprintf(stdout,"\n");
		
		p_unfeasible_multinomial[FN_id] = Pcumulative_sum_of_binomials(FN_capacity[FN_id] + 1 , F , ncode , FN_allocation); // + 1 is because function computes P(S >= s)

//		fprintf(stdout,"Fog node %d : probability overallocating poisson %lf multinomial %lf\n",FN_id,p_unfeasible_poisson[FN_id],p_unfeasible_multinomial[FN_id]);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_fog_nodes_state(int t_, int N, double *average_number_of_clients, double *load_to_FN, double *rate_FN_service, double *sojourn_times, double *p_unfeasible_poisson, double *p_unfeasible_multinomial){
	fprintf(stdout,"Time %d : fog nodes status :\n",t_);
	for(int FN_id = 1; FN_id <= N ; FN_id++)
		fprintf(stdout,"\tFN %3d LEVEL %2d : nclients %5.2lf\toverall load %5.2lf\tservice rate %5.2lf\toverloaded %s\tsojourn times %5.3lf\tunfeasability poisson %.6lf\tmultinomial %.6lf\n",FN_id,get_FN_level(FN_id),average_number_of_clients[FN_id],load_to_FN[FN_id],rate_FN_service[FN_id],(load_to_FN[FN_id] < rate_FN_service[FN_id])?"NO":"YES",sojourn_times[FN_id],p_unfeasible_poisson[FN_id],p_unfeasible_multinomial[FN_id]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_file_state(int t_, int file_id, int FN_id, double poissonized_phit, double multinomial_phit, double delay){
	fprintf(stdout,"\t\tTime %d : file %d status : hit from FN %3d is poissonized %.6lf while multinomial %.6lf delay %5.3lf\n",t_,file_id,FN_id,poissonized_phit,multinomial_phit,delay);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 9){
		fprintf(stdout,"usage : %s L r n k M F c maxT\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode = atoi(argv[3]);
	kcode = atoi(argv[4]);
	M = atoi(argv[5]);
	F = atoi(argv[6]);
	c = atoi(argv[7]);
	max_time = atoi(argv[8]);

	N = (pow(r,L+1) - 1)/(r - 1);
	M = ( M > L)?L:M;
	M = ( M < 1)?1:M;


// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
		set_allocation_probabilities(file_id);
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	double file_popularity[F];
	double popularity_sum = 0;
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] = file_id + 1;
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] /= popularity_sum;
// PATH RETURNED BY ROUTING/SEARCH ALGORITHM
	path_id = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		path_id[FN_id] = (int *)calloc(M + 1, sizeof(int));
		set_path_ids(path_id,FN_id);
	}
// RATE A CLIENT INSISTING ON FOG NODE FN_id ISSUES A REQUEST 
	double rate_client_request[N+1];
	for(int FN_id = 1; FN_id < get_leftmost_id(L);  FN_id++){
		rate_client_request[FN_id] = 0;
	}
	for(int FN_id = get_leftmost_id(L); FN_id <= get_rightmost_id(L); FN_id++){
		rate_client_request[FN_id] = FN_id;
	}
// RATE A FOG NODES FULLFILS REQUESTS
	double rate_FN_service[N+1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rate_FN_service[FN_id] = (L - get_FN_level(FN_id) + 1) * ncode ; // weights
// FOG NODES CAPACITY
	unsigned int FN_capacity[N + 1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) * ncode ; // weights
// LOAD OFFERED TO A FOG NODES
	double load_to_FN[N+1];
// SOJOURN TIMES IN FOG NODES
	double sojourn_times[N+1];
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_pie = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_pie[FN_id] = (double **)calloc(2,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_pie[FN_id][0] = (double *)calloc(c + 1,sizeof(double));
		mobility_pie[FN_id][1] = (double *)calloc(c + 1,sizeof(double));
	}
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_transition_probabilities = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_transition_probabilities[FN_id] = (double **)calloc(c + 1,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int nc = 0; nc <= c; nc++)
			mobility_transition_probabilities[FN_id][nc] = (double *)calloc(c + 1,sizeof(double));
	}
// INITIALIZATION OF MARKOV CHAINS
	int T = 0, Tp1 = 1;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int nc = 0; nc <= c; nc++)
			mobility_pie[FN_id][T][nc] = 0;
		mobility_pie[FN_id][T][rand()%(c+1)] = 1;
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int row = 0; row <= c; row++){
			double row_sum = 0;
			for(int column = 0; column <= c; column++){
				mobility_transition_probabilities[FN_id][row][column] = (column + 1) + (rand()%c);
				row_sum += mobility_transition_probabilities[FN_id][row][column];
			}
			for(int column = 0; column <= c; column++)
				mobility_transition_probabilities[FN_id][row][column] /= row_sum;
		}
	}
	double p_multinomial[M + 2];
	double lambda_poisson[M + 2];
	double average_number_of_clients[N + 1];
	double p_unfeasible_poisson[N + 1];
	double p_unfeasible_multinomial[N + 1];

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
	for( int t_ = 0; t_ <= max_time; t_++){/* For each time step */
		compute_average_number_of_clients_for_each_FN(average_number_of_clients, N, mobility_pie, T);
		compute_overall_load_to_each_FN(load_to_FN, average_number_of_clients, rate_client_request, rate_FN_service, sojourn_times,path_id, N, M, T);
		compute_unfeasibility_for_each_FN(p_unfeasible_poisson, p_unfeasible_multinomial, F, N, ncode, FN_capacity, T);
//		print_fog_nodes_state(t_,N,average_number_of_clients,load_to_FN,rate_FN_service,sojourn_times,p_unfeasible_poisson,p_unfeasible_multinomial);

		double overall_multinomial_phit = 0;
		double overall_poissonized_phit = 0;
		for(int file_id = 0; file_id < F; file_id++){
			double average_multinomial_phit = 0;
			double average_poissonized_phit = 0;
			double average_number_of_hit_requests_multinomial = 0;
			double average_number_of_hit_requests_poissonized = 0;
			for(int leafFN = get_leftmost_id(L); leafFN <= get_rightmost_id(L) ; leafFN++){
				int path_length = set_distribution_parameters(file_id,path_id,leafFN,p_multinomial,lambda_poisson);
				multinomial_phit = 0;
				poissonized_phit = 0;
				for(int n_coded = 0; n_coded < kcode; n_coded++){
					multinomial_partial_phit = gsl_ran_binomial_pdf(ncode-n_coded,p_multinomial[path_length],ncode);
					multinomial_phit += multinomial_partial_phit;

					poissonized_partial_phit = gsl_ran_poisson_pdf(n_coded,ncode-lambda_poisson[path_length]);
					poissonized_phit += poissonized_partial_phit;
				}
				multinomial_phit = 1 - multinomial_phit;
				average_multinomial_phit += multinomial_phit;
				average_number_of_hit_requests_multinomial += average_number_of_clients[leafFN] * file_popularity[file_id] * multinomial_phit; // TO ADJUST TO ACCOUNT FOR RATES

				poissonized_phit = 1 - poissonized_phit;
				average_poissonized_phit += poissonized_phit;
				average_number_of_hit_requests_poissonized += average_number_of_clients[leafFN] * file_popularity[file_id] * poissonized_phit; // TO ADJUST TO ACCOUNT FOR RATES

				fprintf(stdout,"compare sum %lf vs CDF %lf k %d p %lf n %d\n",multinomial_phit,gsl_cdf_binomial_Q(kcode - 1, 1-p_multinomial[path_length], ncode),kcode,p_multinomial[path_length],ncode);

				double delay = 0;
				for(int n_contacted = 0; n_contacted < path_length; n_contacted++)
					if(sojourn_times[path_id[leafFN][n_contacted]] != UNKNOWN)
						delay += ( 2 * (n_contacted+1) + sojourn_times[path_id[leafFN][n_contacted]]);
					else{
						delay = UNKNOWN;
						break;
					}

//				print_file_state(t_, file_id, leafFN, poissonized_phit, multinomial_phit, delay);
			}
			average_multinomial_phit /= (get_rightmost_id(L) - get_leftmost_id(L) + 1);
			average_poissonized_phit /= (get_rightmost_id(L) - get_leftmost_id(L) + 1);

			overall_multinomial_phit += file_popularity[file_id] * average_multinomial_phit; 
			overall_poissonized_phit += file_popularity[file_id] * average_poissonized_phit; 
		}
//		fprintf(stdout,"----------------\nTime %d : Overall multinomial_phit = %lf vs overall poissonized %lf \n",t_,overall_multinomial_phit,overall_poissonized_phit);

		for(int FN_id = 1; FN_id <= N; FN_id++){
			row_matrix_product(mobility_pie[FN_id][Tp1], mobility_pie[FN_id][T], mobility_transition_probabilities[FN_id], c + 1 );
		}
		T = (t_ + 1) % 2; 
		Tp1 = (T+1) % 2;
	}

	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(path_id[FN_id]);
	free(path_id);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

	for(int FN_id = 1; FN_id <= N; FN_id++){
		free(mobility_pie[FN_id][0]);
		free(mobility_pie[FN_id][1]);
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(mobility_pie[FN_id]);
	free(mobility_pie);

	for(int FN_id = 1; FN_id <= N; FN_id++)
		for(int nc = 0; nc <= c; nc++)
			free(mobility_transition_probabilities[FN_id][nc]);
	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(mobility_transition_probabilities[FN_id]);
	free(mobility_transition_probabilities);

	return EXIT_SUCCESS;
}
