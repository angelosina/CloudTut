#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

//#define OUT 
#define UNKNOWN -1

int L = 0;
int r = 0;
int ncode = 0;
int kcode = 0;
int M = 0;
int F = 0;
int c = 0;
int N = 0;
int max_time = 0;

int **path_id = NULL;

double multinomial_phit = 0;
double multinomial_partial_phit = 0;
double poissonized_phit = 0;
double poissonized_partial_phit = 0;

double *p = NULL;

//double *p_multinomial = NULL;
//int *n_multinomial = NULL;
//double *lambda_poisson = NULL;

double **file_allocation = NULL;

//double *file_popularity = NULL;
//double *rate_client_request = NULL;
//double *rate_FN_service = NULL;
//double *FN_capacity = NULL;


double ***mobility_pie = NULL;
double ***mobility_transition_probabilities = NULL;

extern double Pcumulative_sum_of_binomials(int , int , int , double *);
//extern double Psum_of_binomials(int s, int F, int n, double *p){
extern void row_matrix_product(double *, double *, double **, int );
//void row_matrix_product(double *result, double *row_vector, double **square_matrix, int size);


#define CDF_SHIFTED_EXP(x,lambda,tau) ((x >= tau)?(1 - exp(-lambda*(x - tau))):0)

//double *lambda = NULL;
//double *tau = NULL;

double CDF_max_shifted_exp(double x, double *lambda, double *tau, int nexp){
	double ret = 1;
	for(int exp_index = 0; exp_index < nexp; exp_index++){
		ret *= CDF_SHIFTED_EXP(x,lambda[exp_index],tau[exp_index]);
//		fprintf(stdout,"l %lf tau %lf\n",lambda[exp_index],tau[exp_index]);
	}
	return ret;
}
#ifdef IF_NEEDED
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void genColex(int n,int r,int k,int a, int b,int *c,int *minimum, int FN_id, int **path_id){
	if (n==0){
#ifdef OUT
		for( int ii=1; ii <= k; ii++)
			fprintf(stdout,"%d ",a+c[ii]);
		fprintf(stdout," - ");
#endif
		int path_length = 0;
		int sum_n = 0;
		for(; path_length <= M ; path_length++){
			if(path_id[FN_id][path_length] != UNKNOWN){
				n_multinomial[path_length] = a + c[path_length + 1];
				sum_n += n_multinomial[path_length];
			}
			else
				break;
		}
		n_multinomial[path_length] = ncode - sum_n;
#ifdef OUT
		for(int ii = 0; ii <= path_length ; ii++){
			fprintf(stdout,"fn %d ncf %d pmult %lf : ",path_id[FN_id][ii],n_multinomial[ii],p_multinomial[ii]);
		}
		fprintf(stdout," +++ path length %d +++ ",path_length);
#endif

		double p_allocation = gsl_ran_multinomial_pdf (path_length + 1, p_multinomial, n_multinomial);
		multinomial_partial_phit += p_allocation;
#ifdef OUT
		fprintf(stdout," %lf\n",p_allocation);
#endif
	}
	else{
		if (c[r]==b)
    			r = r-1;
  		int l = minimum[n];
  		for (int i=l; i <= r; i++){
			int e;
   			if (i==l)
				e = n-(l-1)*b;
    			else
				e = 1;
    			c[i] = c[i]+e;
    			genColex(n-e,i,k,a,b,c,minimum,FN_id,path_id);
    			c[i] = c[i]-e;
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int find(int n,int k,int b){
	int t=-1;
	for (int s=1; s <= k; s++)
		if (s*b >= n){
			t = s;
			break;
		}
	return t;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generateMin(int *impossible, int n, int k, int b, int *m){
	*impossible = 0;
	for (int i=1; i <= n; i++){
   		int q = find(i,k,b);
   		if (q==-1){
			*impossible=1;
			break;
   		}
   	m[i] = q;
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generate_allocations(int n_coded_fragments,int path_length,int min_c,int max_c, int FN_id, int **path_id){

	if (!(path_length*min_c>n_coded_fragments || path_length*max_c<n_coded_fragments || n_coded_fragments<0 || path_length<0)){
		int im;
		int minimum[n_coded_fragments-path_length*min_c+1];
		generateMin(&im,n_coded_fragments-path_length*min_c,path_length,max_c-min_c,minimum);

		int *c = (int *)calloc(path_length+1,sizeof(int));
		if (im==0)
			genColex(n_coded_fragments-path_length*min_c,path_length,path_length,min_c,max_c-min_c,c,minimum,FN_id,path_id);
		free(c);
	}
}
#endif
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_path_ids(int **path_id, int FN_id){
	int FN_level = get_FN_level(FN_id);
	int path_index = 0;

	path_id[FN_id][path_index++] = FN_id;
	if(FN_id > 1){
		int father = get_leftmost_id(FN_level-1)+(FN_id-get_leftmost_id(FN_level))/r;
		int links = 0;
		for(int level = FN_level - 1; level >= 0 && links < M; links++,level--){
			path_id[FN_id][path_index] = path_id[father][path_index-1];
			path_index++;
		}
	} 
	for(; path_index <= M; )
		path_id[FN_id][path_index++] = UNKNOWN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int set_distribution_parameters(int file_id, int **path_id, int FN_id, double *p_multinomial, double *lambda_poisson){
	double sum_p = 0;
	int path_length = 0;
	for(; path_length <= M ; path_length++){
		if(path_id[FN_id][path_length] != UNKNOWN){
			p_multinomial[path_length] = file_allocation[file_id][path_id[FN_id][path_length]];
			sum_p += p_multinomial[path_length];
		}
		else break;
	}
	p_multinomial[path_length] = 1 - sum_p;
	for(int i = 0; i <= path_length ; i++)
		lambda_poisson[i] = ncode * p_multinomial[i];
	return path_length;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_allocation_probabilities(int file_id){
	double sum_w = 0;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		int l = get_FN_level(FN_id);
		file_allocation[file_id][FN_id] = L - l + 1 + (file_id); // weights
		sum_w += file_allocation[file_id][FN_id];
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		file_allocation[file_id][FN_id] /= sum_w;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 9){
		fprintf(stdout,"usage : %s L r n k M F c maxT\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode = atoi(argv[3]);
	kcode = atoi(argv[4]);
	M = atoi(argv[5]);
	F = atoi(argv[6]);
	c = atoi(argv[7]);
	max_time = atoi(argv[8]);

	N = (pow(r,L+1) - 1)/(r - 1);
	M = ( M > L)?L:M;
	M = ( M < 1)?1:M;


//	double lambda[M+1];
//	double tau[M+1];
//	for(int exp_index = 0; exp_index <= M; exp_index++){
//		lambda[exp_index] = exp_index + 1;
//		tau[exp_index] = exp_index + 1;
//	}
//	fprintf(stdout,"%lf and %lf product %lf max %lf\n", CDF_SHIFTED_EXP(5.2,1,5),CDF_SHIFTED_EXP(5.4,1,5), CDF_SHIFTED_EXP(5.2,1,5)*CDF_SHIFTED_EXP(5.4,1,5),CDF_max_shifted_exp(3.3, lambda, tau, M+1));
//	exit(1);

// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
		set_allocation_probabilities(file_id);
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	double file_popularity[F];
	double popularity_sum = 0;
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] = file_id + 1;
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] /= popularity_sum;
// PATH RETURNED BY ROUTING/SEARCH ALGORITHM
	path_id = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		path_id[FN_id] = (int *)calloc(M + 1, sizeof(int));
		set_path_ids(path_id,FN_id);
	}
// RATE A CLIENT INSISTING ON FOG NODE FN_id ISSUES A REQUEST 
//	rate_client_request = (double *)calloc(N + 1, sizeof(double));
	double rate_client_request[N+1];
//	double sum_rate_client_request = 0;
	for(int FN_id = get_leftmost_id(L); FN_id <= get_rightmost_id(L); FN_id++){
		rate_client_request[FN_id] = FN_id;
//		sum_rate_client_request += rate_client_request[FN_id];
	}
//	for(int FN_id = get_leftmost_id(L); FN_id <= get_rightmost_id(L); FN_id++){
//		rate_client_request[FN_id] /= sum_rate_client_request;
//	}
	double rate_FN_service[N+1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rate_FN_service[FN_id] = (L - get_FN_level(FN_id) + 1) * ncode ; // weights
// FOG NODES CAPACITY
//	FN_capacity = (double *)calloc(N + 1, sizeof(double));
	double FN_capacity[N + 1];
	for(int FN_id = 1; FN_id <= N; FN_id++)
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) * ncode ; // weights
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_pie = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_pie[FN_id] = (double **)calloc(2,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_pie[FN_id][0] = (double *)calloc(c + 1,sizeof(double));
		mobility_pie[FN_id][1] = (double *)calloc(c + 1,sizeof(double));
	}
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_transition_probabilities = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		mobility_transition_probabilities[FN_id] = (double **)calloc(c + 1,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int nc = 0; nc <= c; nc++)
			mobility_transition_probabilities[FN_id][nc] = (double *)calloc(c + 1,sizeof(double));
	}
// INITIALIZATION OF MARKOV CHAINS
	int T = 0, Tp1 = 1;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int nc = 0; nc <= c; nc++)
			mobility_pie[FN_id][T][nc] = 0;
		mobility_pie[FN_id][T][rand()%(c+1)] = 1;
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		for(int row = 0; row <= c; row++){
			double row_sum = 0;
			for(int column = 0; column <= c; column++){
				mobility_transition_probabilities[FN_id][row][column] = (column + 1) + (rand()%c);
				row_sum += mobility_transition_probabilities[FN_id][row][column];
			}
			for(int column = 0; column <= c; column++)
				mobility_transition_probabilities[FN_id][row][column] /= row_sum;
		}
	}

// PARAMETRS FOR MULTINOMIAL AND POISSON DISTRIBUTIONS
//	p_multinomial = (double *)calloc(M + 2,sizeof(double));
//	n_multinomial = (int *)calloc(M + 2, sizeof(int));
//	lambda_poisson = (double *)calloc(M + 2,sizeof(double));

	double p_multinomial[M + 2];
	double n_multinomial[M + 2];
	double lambda_poisson[M + 2];

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////

	for( int t_ = 0; t_ <= max_time; t_++){/* For each time step */
		double average_number_of_clients[N + 1];
		for(int FN_id = 1; FN_id <= N; FN_id++){
			double sum = 0;
			for(int nc = 0; nc <= c; nc++){
				sum += (nc * mobility_pie[FN_id][T][nc]);
//				fprintf(stdout,"mobility_pie(%d) = %lf : ",nc,mobility_pie[FN_id][T][nc]);
			}
//			fprintf(stdout,"\n");
			average_number_of_clients[FN_id] = sum;
//			fprintf(stdout,"average in %d : %lf\n",FN_id,average_number_of_clients[FN_id]);
			
		}

		for(int FN_id = 1; FN_id <= N; FN_id++){
			double sum_of_lambda = 0;
			for(int file_id = 0; file_id < F; file_id++)
				sum_of_lambda += file_allocation[file_id][FN_id];
			sum_of_lambda *= ncode;
			double p_unfeasible_poisson  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);

			double FN_allocation[F];
			for(int file_id = 0; file_id < F; file_id++)
				FN_allocation[file_id] = file_allocation[file_id][FN_id];
			double p_unfeasible_multinomial = Pcumulative_sum_of_binomials(FN_capacity[FN_id] + 1 , F , ncode , FN_allocation); // + 1 is because function computes P(S >= s)

			fprintf(stdout,"Fog node %d : probability overallocating poisson %lf multinomial %lf\n",FN_id,p_unfeasible_poisson,p_unfeasible_multinomial);
		}
		double overall_multinomial_phit = 0;
		double overall_poissonized_phit = 0;
		for(int file_id = 0; file_id < F; file_id++){
			double average_multinomial_phit = 0;
			double average_poissonized_phit = 0;
			double average_number_of_hit_requests_multinomial = 0;
			double average_number_of_hit_requests_poissonized = 0;
			for(int leafFN = get_leftmost_id(L); leafFN <= get_rightmost_id(L) ; leafFN++){
				int path_length = set_distribution_parameters(file_id,path_id,leafFN,p_multinomial,lambda_poisson);
				multinomial_phit = 0;
				poissonized_phit = 0;
				for(int n_coded = 0; n_coded < kcode; n_coded++){
//					generate_allocations(n_coded,path_length,0,n_coded,leafFN,path_id);
					multinomial_partial_phit = gsl_ran_binomial_pdf(ncode-n_coded,p_multinomial[path_length],ncode);
					multinomial_phit += multinomial_partial_phit;

					poissonized_partial_phit = gsl_ran_poisson_pdf(n_coded,ncode-lambda_poisson[path_length]);
					poissonized_phit += poissonized_partial_phit;
				}
				multinomial_phit = 1 - multinomial_phit;
				average_multinomial_phit += multinomial_phit;
				average_number_of_hit_requests_multinomial += average_number_of_clients[leafFN] * file_popularity[file_id] * multinomial_phit; // TO ADJUST TO ACCOUNT FOR RATES

				poissonized_phit = 1 - poissonized_phit;
				average_poissonized_phit += poissonized_phit;
				average_number_of_hit_requests_poissonized += average_number_of_clients[leafFN] * file_popularity[file_id] * poissonized_phit; // TO ADJUST TO ACCOUNT FOR RATES
			}
			average_multinomial_phit /= (get_rightmost_id(L) - get_leftmost_id(L) + 1);
			average_poissonized_phit /= (get_rightmost_id(L) - get_leftmost_id(L) + 1);

//			double absolute_difference = fabs(average_multinomial_phit - average_poissonized_phit);	
//			fprintf(stdout,"Time %d : File %d popularity %.4lf : average multinomial_phit = %lf vs average poissonized %lf absolute difference %lg mult perc %lf poiss perc %lf\n",t_,file_id,file_popularity[file_id],average_multinomial_phit,average_poissonized_phit,absolute_difference,absolute_difference/average_multinomial_phit,absolute_difference/average_poissonized_phit);	
//			fprintf(stdout,"Time %d : File %d popularity %.4lf : average multinomial hit request = %lf vs average poissonized hit request %lf\n",t_,file_id,file_popularity[file_id],average_number_of_hit_requests_multinomial,average_number_of_hit_requests_poissonized);
			overall_multinomial_phit += file_popularity[file_id] * average_multinomial_phit; 
			overall_poissonized_phit += file_popularity[file_id] * average_poissonized_phit; 
		}
//		double absolute_difference = fabs(overall_multinomial_phit - overall_poissonized_phit);	
//		fprintf(stdout,"----------------\nTime %d : Overall multinomial_phit = %lf vs overall poissonized %lf absolute difference %lg mult perc %lf poiss perc %lf\n",t_,overall_multinomial_phit,overall_poissonized_phit,absolute_difference,absolute_difference/overall_multinomial_phit,absolute_difference/overall_poissonized_phit);	
		fprintf(stdout,"----------------\nTime %d : Overall multinomial_phit = %lf vs overall poissonized %lf \n",t_,overall_multinomial_phit,overall_poissonized_phit);

		for(int FN_id = 1; FN_id <= N; FN_id++){
			row_matrix_product(mobility_pie[FN_id][Tp1], mobility_pie[FN_id][T], mobility_transition_probabilities[FN_id], c + 1 );
		}
		T = (t_ + 1) % 2; 
		Tp1 = (T+1) % 2;
	}

	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(path_id[FN_id]);
	free(path_id);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

//	free(p_multinomial);
//	free(n_multinomial);
//	free(lambda_poisson);
//	free(probability_client_request);
//	free(FN_capacity);

	for(int FN_id = 1; FN_id <= N; FN_id++){
		free(mobility_pie[FN_id][0]);
		free(mobility_pie[FN_id][1]);
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(mobility_pie[FN_id]);
	free(mobility_pie);

	for(int FN_id = 1; FN_id <= N; FN_id++)
		for(int nc = 0; nc <= c; nc++)
			free(mobility_transition_probabilities[FN_id][nc]);
	for(int FN_id = 1; FN_id <= N; FN_id++)
		free(mobility_transition_probabilities[FN_id]);
	free(mobility_transition_probabilities);

	return EXIT_SUCCESS;
}
