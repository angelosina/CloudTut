#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include "defines.h"
#include "extern-declarations.h"

extern int get_FN_level(int);
extern int get_leftmost_id(int);
extern int get_rightmost_id(int);
extern int get_father(int);
extern int get_brother(int, int);

extern void print_fog_nodes_state(double *, double *, double *);
extern void print_file_state(double *, double *, double *);
extern void print_rp_state();

extern int MIN(int , int);
extern int MAX(int , int);

#define TRUE 1
#define FALSE 0

#define TOP 1
#define BOTTOM 0

int C = 2;

double *additional = NULL;
double *numerator = NULL;
double *tau = NULL;
double **K = NULL;


/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int is_top(int f) {
	return (f >= F - topF)?TRUE:FALSE;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_overall_request_rate(int file_id){
	double ret_value;
	double T = topF;

	if(is_top(file_id))
		ret_value = (tau[TOP] / T) + tau[BOTTOM] * (K[BOTTOM][TOP] / ((F - T) * T)) + tau[TOP] * (K[TOP][TOP] / ( T * T));
	else
		ret_value = (tau[BOTTOM] / (F - T)) + tau[BOTTOM] * (K[BOTTOM][BOTTOM] / ((F - T) * (F - T))) + tau[TOP] * (K[TOP][BOTTOM] / ( (F - T) * T));
	return ret_value;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int nextvec(int *from, int *to, int *init, int comp) {/* Init nextvec */
        int r,flag;

        r = 0;
        do {
                flag = TRUE;
                if(from[r] + 1 > to[r]) {
                        from[r] = (init!=NULL)?init[r]:0;
                        r++;
                        flag = FALSE;
                }
                else
                        from[r]++;
        } while((r < comp) && (!flag));
        if(r < comp)
                return(TRUE);
        else
        return(FALSE);
}/* End nextvec */
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_rp(int t_){

#ifndef VALIDATION
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_card = 1; // It shall be a function that will decide the cardinality of rp(i)

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;

			rp[FN_id][1] = FN_id;
			for(int rp_id = 2; rp_id <= rp[FN_id][0]; rp_id++){
				rp[FN_id][rp_id] = get_father(rp[FN_id][rp_id-1]);
			}
		}
	}
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_allocations(int t_, double *p_unfeasible_allocation, double *hn_pois){

#ifndef VALIDATION
	for(int file_id = 0; file_id < F; file_id++){
		int n_decreased = 0;
		int n_offload = 0;

		double weight_removed = 0;
		for(int FN_id = 2; FN_id <= N; FN_id++){
			if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0){
				weight_removed += MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				n_decreased++;
			}
		}
		if(n_decreased > 0){
			for(int FN_id = 2; FN_id <= N; FN_id++){
				if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
					n_offload++;
			}
			if(n_offload > 0){
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0)
						file_allocation[file_id][FN_id] -= MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				}
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
						file_allocation[file_id][FN_id] += weight_removed / n_offload;
				}
			}
		}
//		printf("In set_file_alloc fle %d ndec %d noffl %d remweigh %lf\n",file_id,n_decreased,n_offload,weight_removed);
	}
#ifdef DEBUG_FILE_ALLOC
	printf("Dopo set_file_alloc\n");
	print_file_state(NULL, NULL, NULL);
#endif
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_popularities(int t_){
	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_fog_nodes_capabilities(int t_){
	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_mds_parameters(int t_, double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double PIE_n_mult,  double PIE_n_pois, double PIE_f_mult,  double PIE_f_pois, double unfeasibility){
	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void init_model_parameters(){

// FILE POPULARITY

//	double additional[C];
//	double numerator[C];
//	double tau[C];
//	double K[C][C];

	tau = (double *)calloc(C,sizeof(double));
	additional = (double *)calloc(C,sizeof(double));
	numerator = (double *)calloc(C,sizeof(double));
	K = (double **)calloc(C,sizeof(double *));
	for(int i = 0; i < C; i++)
		K[i] = (double *)calloc(C,sizeof(double));

	tau[BOTTOM] = 0.0001;
	tau[TOP] = 0.001;

	K[TOP][TOP] = K[BOTTOM][TOP] = 0.85;
	K[TOP][BOTTOM] = K[BOTTOM][BOTTOM] = 0.10;

	additional[BOTTOM] = tau[BOTTOM] * K[BOTTOM][BOTTOM] + tau[TOP] * K[TOP][BOTTOM];
	additional[TOP] = tau[BOTTOM] * K[BOTTOM][TOP] + tau[TOP] * K[TOP][TOP];

	numerator[BOTTOM] = tau[BOTTOM] + additional[BOTTOM];
	numerator[TOP] = tau[TOP] + additional[TOP];

	double denominator = numerator[BOTTOM] + numerator[TOP];

	double popularity_sum = 0;
//	double sum_of_overall = 0;
//	for(int file_id = 0; file_id < F; file_id++){
//		sum_of_overall += compute_overall_request_rate(file_id);
//	}
	for(int file_id = 0; file_id < F; file_id++){
		//file_popularity[file_id] = file_id + 1;
		if(is_top(file_id))
			file_popularity[file_id] = (numerator[TOP] / denominator) / topF;
		else
			file_popularity[file_id] = (numerator[BOTTOM] / denominator) / (F - topF);

//		if(is_top(file_id)){
//			fprintf(stdout,"fpop %d = %lf num = %lf den = %lf vs %lf\n",file_id, file_popularity[file_id],numerator[TOP],denominator,compute_overall_request_rate(file_id)/sum_of_overall);
//		}
//		else{
//			fprintf(stdout,"fpop %d = %lf num = %lf den = %lf vs %lf\n",file_id, file_popularity[file_id],numerator[BOTTOM],denominator,compute_overall_request_rate(file_id)/sum_of_overall);
//		}
///////////// WARNING //////////////
///////////// WARNING //////////////
///////////// WARNING //////////////
///////////// WARNING //////////////
		file_popularity[file_id] = 1;
///////////// WARNING //////////////
///////////// WARNING //////////////
///////////// WARNING //////////////
///////////// WARNING //////////////
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] /= popularity_sum;
//		fprintf(stdout,"norm fpop %d = %lf\n",file_id, file_popularity[file_id]);
	}
//	exit(1);
	////////////////
	free(tau);
	free(additional);
	free(numerator);
	for(int i = 0; i < C; i++)
		free(K[i]);
	free(K);
//MDS-LIKE PARAMETERS
	for(int file_id = 0; file_id < F; file_id++){

		if(file_id < F - topF){
			kcode[file_id] = kcode_at_0;
			ncode[file_id] = ncode_at_0;
		}
		else{
			kcode[file_id] = kcode_at_0_topF;
			ncode[file_id] = ncode_at_0_topF;
		}
	}
//FOG NODES' CAPACITY
	int leaf_capacity = kcode_at_0 * Fmax;
	int overall_capacity = 0;
	for(int FN_id = 2; FN_id <= N; FN_id++){
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) * leaf_capacity;
		overall_capacity +=  FN_capacity[FN_id];
	}
	MAXF = topF + (overall_capacity - topF * ncode_at_0_topF) / ncode_at_0;
//	fprintf(stdout,"MAXF %lf overall %d topf %d ncode at 0 %d and %d \n",MAXF,overall_capacity,topF,ncode_at_0_topF,ncode_at_0);
// FILE ALLOCATION
	for(int file_id = 0; file_id < F; file_id++){
		double sum_w = 0;
		file_allocation[file_id][0] = 0;
		file_allocation[file_id][ROOT_FN] = kcode[file_id]; /* Not used to compute p_i since counter for file_id is not updated */
		for(int FN_id = 2; FN_id <= N; FN_id++){
			int l = get_FN_level(FN_id);

			if(file_id < F - topF){
				//file_allocation[file_id][FN_id] = (L - l + 1) -  (1 - pow((double)l  / L,z)); // weights
				file_allocation[file_id][FN_id] = (L - l + pow((double)l  / L,z)); // weights
				/*switch(l){
					case 3:
						file_allocation[file_id][FN_id] = 1;
						break;
					case 2:
						file_allocation[file_id][FN_id] = y;
						break;
					case 1:
						file_allocation[file_id][FN_id] = z;
						break;
				}
//				fprintf(stdout,"level %d value %lf y %lf z %lf\n",l,file_allocation[file_id][FN_id],y,z);
//				*/
			}
			else
				//file_allocation[file_id][FN_id] = pow( (L - l + 1) -  (1 - pow((double)l  / L,z)) , y); // weights
				file_allocation[file_id][FN_id] = pow( (L - l + pow((double)l  / L,z)) , y); // weights
//			file_allocation[file_id][FN_id] = FN_capacity[FN_id]; // weights
			file_allocation[file_id][0] += file_allocation[file_id][FN_id];
		}
	}
#ifdef DEBUG_FILE_ALLOC
	printf("After init\n");
	print_file_state(NULL, NULL, NULL);
#endif
// CLIENT POPULATION FOR FRONTIER (ACTIVE) FN
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_depth = MAX(1,get_FN_level(FN_id)); 
			int rp_card = n_replicas * rp_depth;


			int extra_overall = extra_brothers + extra_uncles + extra_grandpas;

			rp_card += extra_overall;

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;

			int previous = FN_id;
			for(int depth = 1; depth <= rp_depth; depth++){
				for(int replica = 0; replica < n_replicas; replica++){
					rp[FN_id][ (depth - 1) * n_replicas + replica + 1] = get_brother(previous,replica);
				}
				previous = get_father(previous);
			}

			int insert_position = rp_card - extra_overall + 1;

			for(int distance = 1; distance <= extra_brothers; distance++)
				rp[FN_id][insert_position++] = get_brother(FN_id,distance);
			for(int distance = 1; distance <= extra_uncles; distance++)
				rp[FN_id][insert_position++] = get_brother(get_father(FN_id),distance);
			for(int distance = 1; distance <= extra_grandpas; distance++)
				rp[FN_id][insert_position++] = get_brother(get_father(get_father(FN_id)),distance);
		}
// It shall be the function we like: it is father relationship by now
	}
#ifdef DEBUG_RP
	print_rp_state();
#endif

}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void allocate_structures(){

	N = (pow(r,L+1) - 1)/(r - 1);
	ncode_at_0_topF = ncode_at_0;
	kcode_at_0_topF = kcode_at_0;

// DETERMINE WHICH FN CAN ISSUE REQUESTS
        active_FN = (char *)calloc(N + 1, sizeof(char));
        for(int FN_id = 1; FN_id <= N; FN_id++){
                if(get_FN_level(FN_id) == L){
                       active_FN[FN_id] = TRUE;
                       Nactive++;
                }
                else
                       active_FN[FN_id] = FALSE;
        }
// THE ABOVE LOOP MUST PRECEDE EVERYTHING !!!

// MDS CODING PARAMETERS
	ncode = (int *)calloc(F, sizeof(int));
	kcode = (int *)calloc(F, sizeof(int));
// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	file_popularity = (double *)calloc(F,sizeof(double));
// SET RP(i) RETURNED BY ROUTING/SEARCH ALGORITHM
	rp = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rp[FN_id] = NULL;
// FOG NODES CAPACITY
	FN_capacity =(unsigned int *)calloc(N + 1, sizeof(unsigned int));
// FOG NODES AVERAGE OCCUPANCY
	average_occupancy = (double *)calloc(N+1, sizeof(double));
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void free_structures(){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(rp[FN_id]);
	free(rp);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

	free(FN_capacity);
	free(average_occupancy);
	free(file_popularity);
	free(active_FN);
	free(kcode);
	free(ncode);
}
