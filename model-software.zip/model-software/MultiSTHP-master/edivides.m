
function y = edivides(a,b)
  y=a./b;
end