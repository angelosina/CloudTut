function y = etimes(a,b)
  y=a.*b; 
end
