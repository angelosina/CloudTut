#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_errno.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_roots.h>


#define NUMERICAL_ACCURACY 1e-4

extern double exp();
extern double log();

double K(double u, int F, int n, double *p){
	double ret = 0;

	for(int i = 1; i <= F; i++){
		ret += log(1 - p[i] + p[i] * exp(u));
	}
	ret *= n;
//	fprintf(stdout,"K( u = %lf ) = %lf\n",u,ret);
	return ret;
}

double q(double u, int i, double *p){
	double ret = (p[i]* exp(u))/(1-p[i]+p[i]*exp(u));
//	fprintf(stdout,"q( u = %lf , i = %d , p = %lf ) = %lf\n",u,i,p[i],ret);
	return ret;
}

double K1(double u, int F, int n, double *p){
	double ret = 0;

	for(int i = 1; i <= F; i++){
		ret += q(u,i,p);
	}
	ret *= n;
//	fprintf(stdout,"K1( u = %lf ) = %lf\n",u,ret);
	return ret;
}
double K2(double u, int F, int n, double *p){
	double ret = 0;

	for(int i = 1; i <= F; i++){
		ret += q(u,i,p) * (1 - q(u,i,p) ); 
	}
	ret *= n;
//	fprintf(stdout,"K2( u = %lf ) = %lf\n",u,ret);
	return ret;
}
double K3(double u, int F, int n, double *p){
	double ret = 0;

	for(int i = 1; i <= F; i++){
		ret += q(u,i,p) * (1 - q(u,i,p) ) * (1 - 2 * q(u,i,p)); 
	}
	ret *= n;
//	fprintf(stdout,"K3( u = %lf ) = %lf\n",u,ret);
	return ret;
}
double K4(double u, int F, int n, double *p){
	double ret = 0;

	for(int i = 1; i <= F; i++){
		ret += q(u,i,p) * (1 - q(u,i,p) ) * (1 - 6 * q(u,i,p) * (1 - q(u,i,p))); 
	}
	ret *= n;
//	fprintf(stdout,"K4( u = %lf ) = %lf\n",u,ret);
	return ret;
}
/////////////////////// ROOT COMPUTATION //////////////////////////
struct Kpars{
	int F;
	int n;
	double *p;
	int s;
};

double K1max(double u, void *params){
	struct Kpars *kp = (struct Kpars *) params;
	int F = kp->F;
	int n = kp->n;
	double *p = kp->p;
	int s = kp->s;

	return K1(u,F,n,p) - s;
}
double compute_utilde(int s, int F, int n, double *p){
	int status;
	int iter = 0, max_iter = 10000;
	const gsl_root_fsolver_type *T;
	gsl_root_fsolver *solver;
	double utilde = 0;
	double x_lo = -2*F-1, x_hi = 2*F+1;
	gsl_function FNC;
	struct Kpars params;
//	printf("utilde : s %d F %d n %d \n",s,F,n);

	params.F = F;
	params.n = n;
	params.p = p;
	params.s = s;

	FNC.function = &K1max;
	FNC.params = &params;

	T = gsl_root_fsolver_brent;
	solver = gsl_root_fsolver_alloc (T);
	gsl_root_fsolver_set (solver, &FNC, x_lo, x_hi);

//	printf ("using %s method\n",gsl_root_fsolver_name (solver));
//	printf ("%5s [%9s, %9s] %9s %10s %9s\n", "iter", "lower", "upper", "root", "err", "err(est)");

	do{
		iter++;
		status = gsl_root_fsolver_iterate (solver);
		utilde = gsl_root_fsolver_root (solver);
		x_lo = gsl_root_fsolver_x_lower (solver);
		x_hi = gsl_root_fsolver_x_upper (solver);
		status = gsl_root_test_interval (x_lo, x_hi, 0, 0.001);

//		if (status == GSL_SUCCESS)
//			printf ("Converged: %5d [%.7f, %.7f] %.7f %.7f\n", iter, x_lo, x_hi, utilde, x_hi - x_lo);
	} while (status == GSL_CONTINUE && iter < max_iter);
	gsl_root_fsolver_free (solver);
	return utilde;
}
/////////////////////// ROOT COMPUTATION //////////////////////////

double P1(double utilde, int s, int F, int n, double *p){
	double ret = (exp(K(utilde,F,n,p)-utilde*s)) / (sqrt(2*M_PI*K2(utilde,F,n,p)));

//	fprintf(stdout,"utilde = %lf s = %d K1 = %lf\n",utilde,s,K1(utilde,F,n,p));
//	fprintf(stdout,"utilde = %lf s = %d K2 = %lf\n",utilde,s,K2(utilde,F,n,p));

	return ret;
}
double P2(double utilde, double p1_estimate, int s, int F, int n, double *p){
	double ret = p1_estimate * (1 + K4(utilde,F,n,p)/(8*pow(K2(utilde,F,n,p),2)) - (5*pow(K3(utilde,F,n,p),2))/(24*pow(K2(utilde,F,n,p),3)));

//	fprintf(stdout,"utilde = %lf s = %d K1 = %lf\n",utilde,s,K1(utilde,F,n,p));
//	fprintf(stdout,"utilde = %lf s = %d K2 = %lf\n",utilde,s,K2(utilde,F,n,p));

	return ret;
}
double Pcumulative_sum_of_binomials(int s, int F, int n, double *p){
	double utilde  = compute_utilde(s, F, n, p);
//	double utilde  = -0.1232;
	double wtilde = GSL_SIGN(utilde) * sqrt(2*utilde*K1(utilde,F,n,p)-2*K(utilde,F,n,p));
	double utilde1 = (1 - exp(-utilde))*sqrt(K2(utilde,F,n,p));
	double ES = 0;
	for(int f = 1; f <= F; f++)
		ES += p[f];
	ES *= n;
	double ret;
	double psi_density = gsl_ran_ugaussian_pdf(wtilde);
	if( s != ES  && utilde != 0){
		double fi_probability =  gsl_cdf_ugaussian_P(wtilde);
		ret = 1 - fi_probability - psi_density * (1 / wtilde - 1 / utilde1);
		double u2tilde = utilde * sqrt(K2(utilde,F,n,p));
		double k3tilde = K3(utilde,F,n,p)*pow(K2(utilde,F,n,p),-1.5);
		double k4tilde = K4(utilde,F,n,p)*pow(K2(utilde,F,n,p),-2);
		ret = ret - psi_density*(1/u2tilde*( k4tilde/8 - (5*pow(k3tilde,2))/24) - 1/pow(u2tilde,3) - k3tilde/(2*pow(u2tilde,2))+1/pow(wtilde,3) );
	}
	else{
		ret = 0.5 - (1 / (M_SQRTPI * M_SQRT2)) * ( K3(0,F,n,p) / (6 * pow(K2(0,F,n,p),1.5)) - 1 / (sqrt(K2(0,F,n,p))));
	}
	return ret;
}
double Psum_of_binomials(int s, int F, int n, double *p){
	double ret = -1;

	if(s == 0){
		ret = 1;
		for(int f = 1; f <= F; f++)
			ret *= (1 - p[f]);
		ret = pow(ret,n);
	}
	else if(s==F*n){
		ret = 1;
		for(int f = 1; f <= F; f++)
			ret *= p[f];
		ret = pow(ret,n);
	}
	else{
		double utilde  = compute_utilde(s, F, n, p);
		double p1_estimate = P1(utilde, s, F, n, p);
		ret = P2(utilde, p1_estimate, s, F, n, p);
	}
	return ret;
}
#ifdef MAIN
void main(int argc, char *argv[]){
	if(argc != 3){
		fprintf(stdout,"Command line error!\n");
		exit(EXIT_FAILURE);
	}
	int n = atoi(argv[1]);
	int F = atoi(argv[2]);

	double *p = (double *)calloc(F+1,sizeof(double));
	for(int f = 1; f <= F; f++){
		p[f] = f/(double)F;
		p[f] = 0.1;
	}

	/*
	double x_lo = -F*F;
	double x_hi = -x_lo;
	for(int s = 1; s < F * n; s++){
		for(double u = x_lo; u <= x_hi; u += 0.01){
			//fprintf(stdout,"s = %d umin = %lf K1 - s = %lf\n",s,x_lo,K1(x_lo,F,n,p) - s);
			//fprintf(stdout,"s = %d umax = %lf K1 - s = %lf\n",s,x_hi,K1(x_hi,F,n,p) - s);
			fprintf(stdout,"s = %d u = %lf K1 - s = %lf\n",s,u,K1(u,F,n,p) - s);
		}
		break;
	}
	}*/

	double sum = 0;
	for(int s = 1; s <= F * n; s++){
		double pcum = Pcumulative_sum_of_binomials(s,F,n,p);
		double pgt = 0;
		for(int sprime = 0; sprime < s; sprime++)
			pgt += Psum_of_binomials(sprime,F,n,p);
		pgt = 1 - pgt;
		fprintf(stdout,"Pcum( >= %d) = %lf vs %lf\n",s,pcum,pgt);
	}
//	fprintf(stdout,"-----------\nsum = %lf\n",sum);

	free(p);
}
#endif
