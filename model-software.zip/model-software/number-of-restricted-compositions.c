#include <stdio.h>
#include <stdlib.h>
#include <stdio.h>
#include <limits.h>
 
//TAKEN FROM ROSETTA CODE http://rosettacode.org/wiki/Rosetta_Code
//
/* We go to some effort to handle overflow situations */
 
static unsigned long gcd_ui(unsigned long x, unsigned long y) {
	unsigned long t;
	if (y < x) { 
		t = x; x = y; y = t; 
	}
	while (y > 0) {
		t = y;  y = x % y;  x = t;  /* y1 <- x0 % y0 ; x1 <- y0 */
	}
	return x;
}
 
unsigned long binomial(unsigned long n, unsigned long k) {
	unsigned long d, g, r = 1;

	if (k == 0) return 1;
	if (k == 1) return n;
	if (k >= n) return (k == n);
	if (k > n/2) k = n-k;
	for (d = 1; d <= k; d++) {
		if (r >= ULONG_MAX/n) {  /* Possible overflow */
			unsigned long nr, dr;  /* reduced numerator / denominator */
			g = gcd_ui(n, d);  
			nr = n/g;  
			dr = d/g;
			g = gcd_ui(r, dr);  
			r = r/g;  
			dr = dr/g;
			if (r >= ULONG_MAX/nr) 
				return 0;  /* Unavoidable overflow */
			r *= nr;
			r /= dr;
			n--;
		} else {
			r *= n--;
			r /= d;
		}
	}
	return r;
}
 
unsigned long int ckn[100][100];

unsigned long int C(int n, int k){

	for(int local_n = 0; local_n <= n; local_n++){
		ckn[local_n][0] = 0;
		ckn[local_n][1] = 1;
	}
	for(int local_k = 0; local_k <= k; local_k++){
		ckn[0][local_k] = 1;
	}
	for(int local_n = 0; local_n <= n; local_n++){
		for(int local_k = 2; local_k <= k; local_k++){
			unsigned long int sum = 0;
			for(unsigned long int i = 0; i <= local_n; i++)
				sum += ckn[local_n - i][local_k - 1];
			ckn[local_n][local_k] = sum;
		}
	}
	return ckn[n][k];
}

unsigned long int cknm[100][100];
int min(int a, int b){
	return (a < b)? a: b;
}

unsigned long int Cknm(int n, int k, int m){

	for(int local_n = 0; local_n <= n; local_n++){
		cknm[local_n][0] = 0;
		cknm[local_n][1] = 0;
	}
	for(int local_k = 0; local_k <= k; local_k++){
		cknm[0][local_k] = 1;
	}
	for(int local_n = 0; local_n <= n; local_n++){
		unsigned long int sum = 0;
		for(unsigned long int i = 0; i <= min(m,local_n); i++)
			sum += ((local_n - i) <= min(m,local_n));
		cknm[local_n][2] = sum;
//		fprintf(stdout,"cknm[%d][2] = %lu\n",local_n,cknm[local_n][2]);
	}
	for(int local_n = 0; local_n <= n; local_n++){
		for(int local_k = 3; local_k <= k; local_k++){
			unsigned long int sum = 0;
			for(unsigned long int i = 0; i <= min(m,local_n); i++)
				sum += cknm[local_n - i][local_k - 1];
			cknm[local_n][local_k] = sum;
//			fprintf(stdout,"cknm[%d][%d] = %lu\n",local_n,local_k,cknm[local_n][local_k]);
		}
	}
	return cknm[n][k];
}

unsigned long int recCknm(int n, int k, int m){

	if(k == 0 || k == 1)
		return 0;
	if(n == 0)
		return 1;
	if(k == 2){
		int sum  = 0;
		for(unsigned long int i = 0; i <= m; i++)
			sum += ((n - i) <= m);
		return sum;
	}
	int sum = 0;
	for(unsigned long int i = 0; i <= m; i++)
		sum += recCknm(n - i,k - 1,m);
	return sum;
}



int main(int argc, char *argv[]){
        if(argc != 4){
                fprintf(stdout,"usage : %s n k m\n",argv[0]);
                exit(EXIT_FAILURE);
        }

	unsigned long int n = atoi(argv[1]);
	unsigned long int k = atoi(argv[2]);
	unsigned long int m = atoi(argv[3]);

	if(m > n){
                fprintf(stdout,"usage : %s n k m (0 <= m < n)\n",argv[0]);
                exit(EXIT_FAILURE);
	}

	//fprintf(stdout,"C(%lu,%lu) = %lu vs %lu C(%lu,%lu,%lu) = %lu iterative %lu\n",n,k,C(n,k),binomial(n+k-1,n),n,k,m,recCknm(n,k,m),Cknm(n,k,m));
	fprintf(stdout,"C(%lu,%lu) = %lu vs %lu C(%lu,%lu,%lu) = %lu iterative %lu\n",n,k,C(n,k),binomial(n+k-1,n),n,k,m,-1,Cknm(n,k,m));
}
