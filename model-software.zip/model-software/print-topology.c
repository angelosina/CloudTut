#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include "defines.h"
#include "extern-declarations.h"

extern int get_FN_level(int);
extern int get_leftmost_id(int);
extern int get_rightmost_id(int);
extern int get_father(int);
extern int get_brother(int, int);

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_fog_nodes_state(double *p_unfeasible_poisson, double *hn_mult, double *hn_pois){
	fprintf(stdout,"\nfog nodes status :\n---------------\n");
	for(int FN_id = 1; FN_id <= N ; FN_id++)
		if(active_FN[FN_id])
			fprintf(stdout,"F %d FN %3d\tACT %c\tLVL %2d\tcap %3u\tocc %lf\tunfeas %.6lf\tmult phit %.6lf\tpoiss phit %.6lf\t\n",F,FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],p_unfeasible_poisson[FN_id],hn_mult[FN_id],hn_pois[FN_id]);
		else
			fprintf(stdout,"F %d FN %3d\tACT %c\tLVL %2d\tcap %3u\tocc %lf\tunfeas %.6lf\n",F,FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],p_unfeasible_poisson[FN_id]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_file_state(double *hf_mult, double *hf_pois, double *popularity){
	fprintf(stdout,"\nfile status :\n---------------\n");
	for(int file_id = 0; file_id < F ; file_id++){
		fprintf(stdout,"file %d n %d k %d pop %.6lf : hit pois %.6lf hit mult %.6lf\n",file_id,ncode[file_id],kcode[file_id],(popularity != NULL)?popularity[file_id]:-1,(hf_pois != NULL)?hf_pois[file_id]:-1,(hf_mult != NULL)?hf_mult[file_id]:-1);
		for(int FN_id = 2; FN_id <= N; FN_id++)
			fprintf(stdout,"ALLOC FILE %d : FN %d : WEIGHT %lf FRACTION %lf POPULARITY %lf\n",file_id,FN_id, file_allocation[file_id][FN_id],file_allocation[file_id][FN_id]/file_allocation[file_id][0],file_popularity[file_id]);
		fprintf(stdout,"\n");
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_rp_state(){

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			fprintf(stdout,"rp FN %d :",FN_id);
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
				fprintf(stdout," %d",rp[FN_id][rp_id]);
			fprintf(stdout,"\n");
		}
	}
}
