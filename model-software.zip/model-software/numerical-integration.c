#include <stdio.h>
#include <math.h>
#include <gsl/gsl_integration.h>

#define ABS_ERR 1e-2
#define LIMIT 10000
#define CDF_SHIFTED_EXP(x,lambda,tau) ((x >= tau)?(1 - exp(-lambda*(x - tau))):0)

struct CDFpars{
	double *lambda;
	double *tau;
	int nexp;
};

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_max_shifted_exp(double x, void *params){
	struct CDFpars *CDFp = (struct CDFpars *) params;
		
	double *lambda = CDFp->lambda;
	double *tau = CDFp->tau;
	int nexp = CDFp->nexp;

	double ret = 1;
	for(int exp_index = 0; exp_index < nexp; exp_index++)
		ret *= CDF_SHIFTED_EXP(x,lambda[exp_index],tau[exp_index]);
	return 1 - ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_average_of_max_mm1(int nexp, double *lambda, double *tau){
	gsl_integration_workspace *w = gsl_integration_workspace_alloc(LIMIT);
	    
	double result, error;

	gsl_function F;
	F.function = &CDF_max_shifted_exp;

	struct CDFpars params;
	params.nexp = nexp;
	params.lambda = lambda;
	params.tau = tau;

	F.params = &params;

#ifdef DEBUG_NUMERICAL_INTEGRATION
	for(int i = 0; i < params.nexp; i++){
		fprintf(stdout,"%d:\tlambda %lf\ttau %lf\n",i,params.lambda[i],params.tau[i]);
	}
#endif

	gsl_integration_qagiu (&F, 0, ABS_ERR, 0, LIMIT, w, &result, &error); 

	gsl_integration_workspace_free (w);

	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_deadline_probability_mm1(double x, double *lambda, double *tau, int nexp){
	double ret = 1;
	for(int exp_index = 0; exp_index < nexp; exp_index++)
		ret *= CDF_SHIFTED_EXP(x,lambda[exp_index],tau[exp_index]);
	return ret;
}
#ifdef MAIN
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	int nexp = atoi(argv[1]);

	struct CDFpars params;
	params.nexp = nexp;
	params.lambda = (double *)calloc(nexp,sizeof(double));
	params.tau = (double *)calloc(nexp,sizeof(double));
	for(int i = 0; i < nexp; i++){
		params.lambda[i]  = (i + 1) * 100;
		params.tau[i]  = 0;
	}

	for(double x = 0; x <= 10; x+=0.01)
		fprintf(stdout,"%lf\t%lf\t%lf\n",x,CDF_max_shifted_exp(x,&params),compute_average_of_max(nexp, params.lambda, params.tau));
}
#endif
