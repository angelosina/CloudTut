#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_complex.h>
#include <gsl/gsl_complex_math.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_sf.h>

#define TRUE 1
#define FALSE 0
#define UNKNOWN -1
//#define DEBUG_DTMC
//#define DEBUG
//#define DEBUG_LST
#define DEBUG_WMED

double eta_re[] = {249686.75089589274,382732.93380384881,88148.288914264354,-245020.07990289867,-460302.1797150168,-458681.06264076044,-244770.15062243768,77201.723952866014,354768.77936759085,460341.56813613488,350561.69455266237,83972.621321363666,-210075.65492150935,-394778.67180406733,-390166.16727901512,-207822.27703214576,59045.402822311153,283312.9720966983,364939.99397380062,275778.92464517686,68061.980923854062,-155156.17885635444,-291217.38386328047,-285218.75005622336,-151606.72147835026,38130.766758825455,193206.91275058326,246954.91456786395,185162.62317258015,47485.0756814272,-96163.406775693249,-180765.3654233744,-175351.92474078029,-93233.728836394323,19335.897918405633,108296.76594672141,137375.47417148124,102189.01560277808,27797.846461516412,-46924.209048793993,-88995.420105206882,-85354.008470754517,-45538.256303025308,6454.5494264575836,45580.29650108132,57284.887107854745,42101.506635416154,12415.184931709937,-15610.234015545337,-30195.736782099575,-28327.773424458075,-15078.583399109475,698.75559899328664,11411.986709906812,13904.816234161673,9686.2592694193627,2858.7092874042328,-2617.4404499174366,-4773.3249979526609,-3917.7664881484438,-1685.1183645542219,270.566022663852,1127.2744019593792,987.06781935439369,428.14522997316243,-27.456062486818233,-185.719107221583,-133.0880269164856,-35.742537792258673,13.136007244076264,14.611961676057774,3.8607594635180855,-0.56894515736785656,-0.37724977804167831,-0.014478006280629263};
double eta_im[] = {0,-319941.92920755706,-489398.12000720081,-429739.3386668592,-171217.74409898781,162511.07264995552,414352.12261764,468739.52365566726,305357.53902427253,6341.8193579149656,-285315.13088051527,-434916.58035156241,-378957.6919977967,-152084.65719078461,133285.1330612551,343028.4890400751,384914.35354517552,249316.74566230152,9028.6471862146573,-219460.52972652085,-332726.55672492989,-287405.0543441177,-115999.19006194576,93750.31962118423,243613.97941528319,270956.27910304494,174500.23430104362,9438.9744479254878,-143144.73205048556,-215946.58447631416,-184846.92456416113,-75377.2195837355,54397.617066246472,144089.0355410045,158780.56781178643,101770.0792812963,8150.0555727868459,-75395.549202888113,-113402.60435792759,-96096.231958353514,-39960.909449427687,23835.970128398745,65951.857359759408,71851.808841650229,45787.8807034247,5434.7002913801625,-28677.810873854974,-43041.534797604269,-35851.009791702534,-15302.092924392169,6390.1544986817871,19513.832159654452,20698.131968799094,12842.409434168172,2098.5148669040054,-5902.2810061676846,-8538.6226678614767,-6519.0488934336136,-2476.5139865313567,952.91370488468976,2427.5684422911222,2094.774886864031,940.65273383323006,-64.658818763290668,-480.16581858446676,-400.85507913043722,-151.06418363817932,22.028475449498078,61.400863770257345,31.792897645917609,3.1489932612457108,-4.0777914369267112,-1.616745387667393,-0.01826225358848077,0.042460597656638746};
double beta_re[] = {12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794,12.540986242234794};
double beta_im[] = {0,5.5822187141710673,11.164437428342135,16.746656142513203,22.328874856684269,27.911093570855336,33.493312285026406,39.075530999197476,44.657749713368538,50.2399684275396,55.822187141710671,61.404405855881734,66.986624570052811,72.568843284223874,78.151061998394951,83.733280712566014,89.315499426737077,94.89771814090814,100.4799368550792,106.06215556925028,111.64437428342134,117.22659299759242,122.80881171176347,128.39103042593456,133.97324914010562,139.55546785427669,145.13768656844775,150.71990528261881,156.3021239967899,161.88434271096094,167.46656142513203,173.04878013930306,178.63099885347415,184.21321756764522,189.79543628181628,195.37765499598737,200.9598737101584,206.5420924243295,212.12431113850056,217.70652985267159,223.28874856684268,228.87096728101375,234.45318599518484,240.0354047093559,245.61762342352694,251.19984213769803,256.78206085186912,262.36427956604018,267.94649828021124,273.52871699438231,279.11093570855337,284.69315442272443,290.2753731368955,295.85759185106656,301.43981056523762,307.02202927940868,312.6042479935798,318.18646670775087,323.76868542192187,329.350904136093,334.93312285026406,340.51534156443512,346.09756027860612,351.67977899277724,357.26199770694831,362.84421642111937,368.42643513529043,374.0086538494615,379.59087256363256,385.17309127780362,390.75530999197474,396.33752870614575,401.91974742031681,407.50196613448793,413.084184848659};
//#define DEBUG
//#define DEBUG_LST

gsl_vector *g = NULL;
gsl_vector *pie = NULL;
gsl_vector *lambda_T = NULL;
gsl_matrix * LAMBDA = NULL;
gsl_matrix * Q = NULL;
gsl_matrix * DISCRETE_Q = NULL;

double mu;
double lambda_tot;
double rho;

int m;
double epsilon1 = 1e-4;
double epsilon2 = 1e-4;

#define MAX_ITER 1000
 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_vector(FILE *f, const gsl_vector *v, const char *title){
        int status, n = 0;

	fprintf(f,"======== VECTOR %s START =========\n",title);
	for (size_t j = 0; j < v->size; j++) {
		if ((status = fprintf(f, "%lf ", gsl_vector_get(v, j))) < 0)
			return -1;
		n += status;
	}
	fprintf(f,"\n======== VECTOR %s END =========\n",title);
	return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_complex_vector(FILE *f, const gsl_vector_complex *v, const char *title){
	fprintf(f,"======== VECTOR %s START =========\n",title);
	for (size_t j = 0; j < v->size; j++){
		gsl_complex velem = gsl_vector_complex_get(v,j);
		fprintf(f, "%lf %ci%lf ", GSL_REAL(velem),(GSL_IMAG(velem))<0?' ':'+',GSL_IMAG(velem));
	}
	fprintf(f,"\n======== VECTOR %s END =========\n",title);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_matrix(FILE *f, const gsl_matrix *m, const char *title){
        int status, n = 0;

	fprintf(f,"======== MATRIX %s START =========\n",title);
        for (size_t i = 0; i < m->size1; i++) {
                for (size_t j = 0; j < m->size2; j++) {
                        if ((status = fprintf(f, "%lf ", gsl_matrix_get(m, i, j))) < 0)
                                return -1;
                        n += status;
                }
                if ((status = fprintf(f, "\n")) < 0)
                        return -1;
                n += status;
        }
	fprintf(f,"======== MATRIX %s END =========\n",title);
        return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int print_complex_matrix(FILE *f, const gsl_matrix_complex *m, const char *title){
        int status, n = 0;

	fprintf(f,"======== MATRIX %s START =========\n",title);
        for (size_t i = 0; i < m->size1; i++) {
                for (size_t j = 0; j < m->size2; j++) {
                        gsl_complex melem = gsl_matrix_complex_get(m, i, j);
                        if ((status = fprintf(f, "%lf %ci%lf ", GSL_REAL(melem),((GSL_IMAG(melem))<0)?' ':'+',GSL_IMAG(melem)) < 0))
                                return -1;
                        n += status;
                }
                if ((status = fprintf(f, "\n")) < 0)
                        return -1;
                n += status;
        }
	fprintf(f,"======== MATRIX %s END =========\n",title);
        return n;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix * invert_a_matrix(gsl_matrix *matrix) {
	int size = matrix->size1;
	gsl_permutation *p = gsl_permutation_alloc(size);
	int s;

	gsl_matrix *copy = gsl_matrix_alloc(size, size);
	gsl_matrix_memcpy(copy,matrix);

// Compute the LU decomposition of this matrix
	gsl_linalg_LU_decomp(copy, p, &s);
// Compute the  inverse of the LU decomposition
	gsl_matrix *inv = gsl_matrix_alloc(size, size);
	gsl_linalg_LU_invert(copy, p, inv);
	gsl_matrix_free(copy);
	gsl_permutation_free(p);
//	print_matrix(stdout,inv,"LU DECOMP inverse");
	return inv;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix_complex * invert_a_complex_matrix(gsl_matrix_complex *matrix) {
	int size = matrix->size1;
	gsl_permutation *p = gsl_permutation_alloc(size);
	int s;

	gsl_matrix_complex *copy = gsl_matrix_complex_alloc(size, size);
	gsl_matrix_complex_memcpy(copy,matrix);

// Compute the LU decomposition of this matrix
	gsl_linalg_complex_LU_decomp(copy, p, &s);
// Compute the  inverse of the LU decomposition
	gsl_matrix_complex *inv = gsl_matrix_complex_alloc(size, size);
	gsl_linalg_complex_LU_invert(copy, p, inv);
	gsl_matrix_complex_free(copy);
	gsl_permutation_free(p);
	return inv;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void row_matrix_prod_in_place(gsl_vector *vector, gsl_matrix *matrix, gsl_vector *result){

	for(int column = 0; column < m; column++){
		double sum = 0;
		for(int row = 0; row < m; row++)
			sum += gsl_vector_get(vector, row) * gsl_matrix_get(matrix, row, column);
		gsl_vector_set(result, column, sum);
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector *row_matrix_prod(gsl_vector *vector, gsl_matrix *matrix){
	gsl_vector *result = gsl_vector_calloc(m);

	for(int column = 0; column < m; column++){
		double sum = 0;
		for(int row = 0; row < m; row++)
			sum += gsl_vector_get(vector, row) * gsl_matrix_get(matrix, row, column);
		gsl_vector_set(result, column, sum);
	}
	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix *matrix_matrix_prod(gsl_matrix *A, gsl_matrix *B){
	gsl_matrix *result = gsl_matrix_calloc(m,m);

	for(int row = 0; row < m; row++){
		for(int column = 0; column < m; column++){
			double sum = 0;
			for(int i = 0; i < m; i++)
				sum += gsl_matrix_get(A, row,i) * gsl_matrix_get(B, i, column);
			gsl_matrix_set(result, row, column, sum);
		}
	}
	print_matrix(stdout,result,"MATRIX PRODUCT");
	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double row_column_prod(gsl_vector *row_vector, gsl_vector *column_vector){

	double product = 0;
	for(int index = 0; index < m; index++)
		product += gsl_vector_get(row_vector, index) * gsl_vector_get(column_vector, index);
	return product;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector_complex *row_matrix_prod_complex(gsl_vector_complex *vector, gsl_matrix_complex *matrix){
	gsl_vector_complex *result = gsl_vector_complex_calloc(m);

	for(int column = 0; column < m; column++){
		gsl_complex sum = gsl_complex_rect(0,0);
		for(int row = 0; row < m; row++){
			gsl_complex vecelem = gsl_vector_complex_get(vector,row);
			gsl_complex matelem = gsl_matrix_complex_get(matrix,row,column);
			sum = gsl_complex_add(sum, gsl_complex_mul(vecelem,matelem));   
		}
		gsl_vector_complex_set(result, column, sum);
	}
	return result;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector_complex *gsl_vector_clone_double_to_complex(gsl_vector *v){
	gsl_vector_complex *c = gsl_vector_complex_calloc(m);
	for(int i = 0; i < m; i++)
		gsl_vector_complex_set(c,i,gsl_complex_rect(gsl_vector_get(v,i),0));
	return c;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix_complex *gsl_matrix_clone_double_to_complex(gsl_matrix *md){
	gsl_matrix_complex *mc = gsl_matrix_complex_calloc(m,m);
	for(int row = 0; row < m; row++)
		for(int col = 0; col < m; col++)
			gsl_matrix_complex_set(mc,row,col,gsl_complex_rect(gsl_matrix_get(md,row,col),0));
	return mc;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_complex H(gsl_complex s){
	gsl_complex mu_z = gsl_complex_rect(mu,0);
	return gsl_complex_div(mu_z, gsl_complex_add(mu_z,s));
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_complex complex_LST(gsl_complex s){
	gsl_vector_complex *g_z = gsl_vector_clone_double_to_complex(g);
	gsl_vector_complex *pie_z = gsl_vector_clone_double_to_complex(pie);
	gsl_matrix_complex *LAMBDA_z = gsl_matrix_clone_double_to_complex(LAMBDA);
	gsl_matrix_complex *Q_z = gsl_matrix_clone_double_to_complex(Q);

	gsl_complex zero_z = gsl_complex_rect(0,0);
	gsl_complex one_z = gsl_complex_rect(1,0);
	gsl_complex rho_z = gsl_complex_rect(rho,0);
	gsl_complex one_minus_rho_z = gsl_complex_rect(1-rho,0);

	gsl_complex ret_val = gsl_complex_rect(0,0);
	gsl_vector_complex *W = gsl_vector_complex_calloc(m);

	if(gsl_complex_abs(s) == 0){
		gsl_vector_complex_memcpy(W, pie_z);
	}
	else{
		// H(s) for exponential whose parameter is mu is H(s) = mu / (mu +s)
		gsl_complex muz = gsl_complex_rect(mu,0);
		gsl_complex one_minus_H = gsl_complex_sub(one_z,gsl_complex_div(muz,gsl_complex_add(muz,s)));
#ifdef DEBUG_LST
		char title[64];
		sprintf(title,"mu = %lf s = %lf + i%lf SCALED DOWN BY %lf + i%lf",mu,GSL_REAL(s),GSL_IMAG(s),GSL_REAL(one_minus_H),GSL_IMAG(one_minus_H));
#endif
		gsl_matrix_complex *L_times_one_minus_H = gsl_matrix_complex_calloc(m,m); 
		gsl_matrix_complex_memcpy(L_times_one_minus_H,LAMBDA_z);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,L_times_one_minus_H,"COPY of LAMBDA");
#endif
		gsl_matrix_complex_scale(L_times_one_minus_H, one_minus_H);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,L_times_one_minus_H,title);
#endif
		gsl_matrix_complex *Q_minus_L_times_one_minus_H = gsl_matrix_complex_calloc(m,m);
		gsl_matrix_complex_memcpy(Q_minus_L_times_one_minus_H, Q_z);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,Q_minus_L_times_one_minus_H,"COPY of Q");
#endif
		gsl_matrix_complex_sub(Q_minus_L_times_one_minus_H, L_times_one_minus_H);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,Q_minus_L_times_one_minus_H,"Q - LAMBDA(1-H(s))");
#endif
		gsl_matrix_complex *SQUARE_BRCK = gsl_matrix_complex_calloc(m,m);
		gsl_matrix_complex_set_identity(SQUARE_BRCK);
		gsl_matrix_complex_scale(SQUARE_BRCK, s);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,SQUARE_BRCK,"sI");
#endif
		gsl_matrix_complex_add(SQUARE_BRCK, Q_minus_L_times_one_minus_H);
#ifdef DEBUG_LST
		print_complex_matrix(stdout,SQUARE_BRCK,"sI + Q - LAMBDA(1-H(s))");
#endif
		gsl_matrix_complex *SQUARE_BRCK_inverse = invert_a_complex_matrix(SQUARE_BRCK);
		gsl_vector_complex * result = row_matrix_prod_complex(g_z, SQUARE_BRCK_inverse);

#ifdef DEBUG_LST
		print_complex_vector(stdout,result,"result");
#endif
		// COMPUTATION OF s(1-rho): to obtain CDF F(s)/s must be inverted therefore I do not multiply by s!!
		// and just scale by 1 - rho
		
		//gsl_complex scale_factor = gsl_complex_mul(s, one_minus_rho_z)); // this is in the MMPP cookbook
		gsl_complex scale_factor = one_minus_rho_z;
#ifdef DEBUG_LST
		fprintf(stdout,"Scake factor 1 - rho_z = %lf + i %lf\n",GSL_REAL(one_minus_rho_z),GSL_IMAG(one_minus_rho_z));
#endif
		gsl_vector_complex_scale(result, scale_factor);
#ifdef DEBUG_LST
		print_complex_vector(stdout,result,"scaled result");
#endif
	
		// Multiply by H(s) since sojourn time is the sum of waiting and service
		scale_factor = H(s);
#ifdef DEBUG_LST
		fprintf(stdout,"Scale factor H(s) = %lf + i %lf\n",GSL_REAL(scale_factor),GSL_IMAG(scale_factor));
#endif
		gsl_vector_complex_scale(result, scale_factor);

		gsl_vector_complex_memcpy(W, result);
#ifdef DEBUG_LST
		print_complex_vector(stdout,W,"FINAL W");
#endif

		gsl_matrix_complex_free(L_times_one_minus_H);
		gsl_matrix_complex_free(Q_minus_L_times_one_minus_H);
		gsl_matrix_complex_free(SQUARE_BRCK);
		gsl_matrix_complex_free(SQUARE_BRCK_inverse);
		gsl_vector_complex_free(result);
	}
	for(int i = 0; i < m; i++)
		ret_val = gsl_complex_add(ret_val, gsl_vector_complex_get(W, i));

	gsl_vector_complex_free(pie_z);
	gsl_vector_complex_free(g_z);
	gsl_matrix_complex_free(LAMBDA_z);
	gsl_matrix_complex_free(Q_z);
	gsl_vector_complex_free(W);
#ifdef DEBUG_LST
	fprintf(stdout,"LST(%lf +i%lf) = %lf + i%lf\n",GSL_REAL(s),GSL_IMAG(s),GSL_REAL(ret_val),GSL_IMAG(ret_val));
#endif
	return ret_val;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double LST(double s){
	double ret_val = 0;
	gsl_vector *W = gsl_vector_calloc(m);

	if(s == 0){
		gsl_vector_memcpy(W, pie);
	}
	else{
		// H(s) for exponential whose parameter is mu is H(s) = mu / (mu +s)
		double one_minus_H = 1 - (mu / (mu + s));
#ifdef DEBUG_LST
		char title[64];
		sprintf(title,"mu = %lf s = %lf SCALED DOWN BY %lf",mu,s,one_minus_H);
#endif

		gsl_matrix *L_times_one_minus_H = gsl_matrix_calloc(m,m); 
		gsl_matrix_memcpy(L_times_one_minus_H,LAMBDA);
#ifdef DEBUG_LST
		print_matrix(stdout,L_times_one_minus_H,"COPY of LAMBDA");
#endif
		gsl_matrix_scale(L_times_one_minus_H, one_minus_H);
#ifdef DEBUG_LST
		print_matrix(stdout,L_times_one_minus_H,title);
#endif

		gsl_matrix *Q_minus_L_times_one_minus_H = gsl_matrix_calloc(m,m);
		gsl_matrix_memcpy(Q_minus_L_times_one_minus_H, Q);
#ifdef DEBUG_LST
		print_matrix(stdout,Q_minus_L_times_one_minus_H,"COPY of Q");
#endif
		gsl_matrix_sub(Q_minus_L_times_one_minus_H, L_times_one_minus_H);
#ifdef DEBUG_LST
		print_matrix(stdout,Q_minus_L_times_one_minus_H,"Q - LAMBDA(1-H(s))");
#endif

		gsl_matrix *SQUARE_BRCK = gsl_matrix_calloc(m,m);
		gsl_matrix_set_identity(SQUARE_BRCK);
		gsl_matrix_scale(SQUARE_BRCK, s);
#ifdef DEBUG_LST
		print_matrix(stdout,SQUARE_BRCK,"sI");
#endif
		gsl_matrix_add(SQUARE_BRCK, Q_minus_L_times_one_minus_H);
#ifdef DEBUG_LST
		print_matrix(stdout,SQUARE_BRCK,"sI + Q - LAMBDA(1-H(s))");
#endif

		gsl_matrix *SQUARE_BRCK_inverse = invert_a_matrix(SQUARE_BRCK);
#ifdef DEBUG_LST
		print_matrix(stdout,SQUARE_BRCK_inverse,"[sI + Q - LAMBDA(1-H(s))]^-1");
		gsl_matrix *resultverify = gsl_matrix_calloc(m,m);

		gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, SQUARE_BRCK, SQUARE_BRCK_inverse, 0.0, resultverify);
		print_matrix(stdout,resultverify,"A A^-1");

		gsl_vector_complex *eval = gsl_vector_complex_alloc (m);
		gsl_matrix_complex *evec = gsl_matrix_complex_alloc (m, m);
		gsl_eigen_nonsymmv_workspace * w = gsl_eigen_nonsymmv_alloc (m);
		gsl_eigen_nonsymmv_params(1, w);
		gsl_eigen_nonsymmv (SQUARE_BRCK, eval, evec, w); 
		gsl_eigen_nonsymmv_free (w);
		gsl_eigen_nonsymmv_sort (eval, evec, GSL_EIGEN_SORT_ABS_DESC);

		for (int i = 0; i < m; i++){
			gsl_complex eval_i = gsl_vector_complex_get (eval, i);
		        gsl_vector_complex_view evec_i = gsl_matrix_complex_column (evec, i);
			printf ("eigenvalue = %g + %gi\n", GSL_REAL(eval_i), GSL_IMAG(eval_i));
			printf ("eigenvector = \n");
		}
		gsl_vector_complex_free(eval);
		gsl_matrix_complex_free(evec);
		gsl_matrix_free(resultverify);
#endif
		gsl_vector * result = row_matrix_prod(g, SQUARE_BRCK_inverse);
		gsl_vector_scale(result, s * (1 - rho));
//		gsl_vector *result = gsl_vector_calloc(m);
//		for(int column = 0; column < m; column++){
//			double sum = 0;
//			for(int row = 0; row < m; row++)
//				sum += gsl_vector_get(g, row) * gsl_matrix_get(SQUARE_BRCK_inverse, row, column);
//			gsl_vector_set(result, column, s * (1 - rho) * sum);
//		}

//		fprintf(stdout,"HERE IS VECTOR result\n----------------\n");
//		gsl_vector_fprintf(stdout, result, "%g");

		gsl_vector_memcpy(W, result);

		gsl_matrix_free(L_times_one_minus_H);
		gsl_matrix_free(Q_minus_L_times_one_minus_H);
		gsl_matrix_free(SQUARE_BRCK);
		gsl_matrix_free(SQUARE_BRCK_inverse);
		gsl_vector_free(result);
	}
	for(int i = 0; i < m; i++)
		ret_val += gsl_vector_get(W, i);
	gsl_vector_free(W);
	return ret_val;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_complex InverseLaplaceTransform(double T){
	gsl_complex hnT = gsl_complex_rect(0,0);
	gsl_complex T_z = gsl_complex_rect(T,0);
	
	for (int k = 0; k < 75; k++){
		gsl_complex etak = gsl_complex_rect(eta_re[k], eta_im[k]);
		gsl_complex betak = gsl_complex_rect(beta_re[k], beta_im[k]);

		gsl_complex funarg = gsl_complex_div(betak, T_z);
		hnT = gsl_complex_add(hnT,gsl_complex_mul(etak, complex_LST(funarg)));
#ifdef DEBUG_INVERSE
		fprintf(stdout,"eta %d = %lf +i%lf : beta %d = %lf +i%lf : hnT = %lf + i%lf\n",k,GSL_REAL(etak),GSL_IMAG(etak),k,GSL_REAL(betak),GSL_IMAG(betak),GSL_REAL(hnT),GSL_IMAG(hnT));
#endif
	}
	hnT = gsl_complex_div(hnT, T_z);
	return hnT;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector *my_solve_DTMC(gsl_matrix *P, char name[]){

	gsl_vector * current_pie = gsl_vector_calloc(m);
	gsl_vector * previous_pie = gsl_vector_calloc(m);
	gsl_vector_set(previous_pie,0,1);
	gsl_vector * pie_difference = gsl_vector_calloc(m);

	for(; ;){
		row_matrix_prod_in_place(previous_pie,P,current_pie);
#ifdef DEBUG_DTMC
		for (int j = 0; j < m; ++j)
			fprintf(stdout,"preiovus(%d) = %lf\n",j,gsl_vector_get(previous_pie,j));
		for (int j = 0; j < m; ++j)
			fprintf(stdout,"current(%d) = %lf\n",j,gsl_vector_get(current_pie,j));
#endif
		gsl_vector_memcpy(pie_difference,previous_pie);
		gsl_vector_sub(pie_difference, current_pie);
#ifdef DEBUG_DTMC
		for (int j = 0; j < m; ++j)
			fprintf(stdout,"difference(%d) = %lf\n",j,gsl_vector_get(pie_difference,j));
#endif
		if(gsl_blas_dnrm2(pie_difference) < epsilon1)
			break;
		gsl_vector_memcpy(previous_pie,current_pie);
#ifdef DEBUG_DTMC
		getchar();
#endif
	}
#ifdef DEBUG_DTMC
	for (int j = 0; j < m; ++j)
		fprintf(stdout,"%s(%d) = %lf\n",name,j,gsl_vector_get(current_pie,j));
#endif
	gsl_vector_free(previous_pie);
	gsl_vector_free(pie_difference);
	return current_pie;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector * solve_DTMC(gsl_matrix *data, char name[]){
int matrix_size = data->size1;

	gsl_vector_complex *eval = gsl_vector_complex_alloc (matrix_size);
	gsl_matrix_complex *evec = gsl_matrix_complex_alloc (matrix_size, matrix_size);
	gsl_eigen_nonsymmv_workspace * w = gsl_eigen_nonsymmv_alloc (matrix_size);
	gsl_eigen_nonsymmv_params(1, w);
	gsl_eigen_nonsymmv (data, eval, evec, w); 
	gsl_eigen_nonsymmv_free (w);
	gsl_eigen_nonsymmv_sort (eval, evec, GSL_EIGEN_SORT_ABS_DESC);


	int n_potential_solutions = 0;
	int good_eigen_vector;
	double sum_of_eigens;
	double good_sum_of_eigens;
	for (int i = 0; i < matrix_size; i++){
		gsl_complex eval_i = gsl_vector_complex_get (eval, i);
	        //gsl_vector_complex_view evec_i = gsl_matrix_complex_column (evec, i);
	        gsl_vector_complex_view evec_i = gsl_matrix_complex_row (evec, i);
#ifdef DEBUG_DTMC
		printf ("eigenvalue = %g + %gi\n", GSL_REAL(eval_i), GSL_IMAG(eval_i));
		printf ("eigenvector = \n");
		for (int j = 0; j < matrix_size; ++j){
			gsl_complex z = gsl_vector_complex_get(&evec_i.vector, j);
			fprintf(stdout,"%lf + i%lf\n",GSL_REAL(z), GSL_IMAG(z));
		}
#endif
		char all_non_negative = TRUE;
		sum_of_eigens = 0;
		for (int j = 0; j < matrix_size; ++j){
			gsl_complex z = gsl_vector_complex_get(&evec_i.vector, j);
			if(GSL_REAL(z) < 0){
				all_non_negative = FALSE;
				break;
			}
			sum_of_eigens += GSL_REAL(z);
		}
		if(all_non_negative){
			n_potential_solutions++;
			good_eigen_vector = i;
			good_sum_of_eigens = sum_of_eigens;
		}
	}
	if(n_potential_solutions == 1){
		gsl_vector * g = gsl_vector_calloc(matrix_size);
	        //gsl_vector_complex_view evec_i = gsl_matrix_complex_column (evec, good_eigen_vector);
	        gsl_vector_complex_view evec_i = gsl_matrix_complex_row (evec, good_eigen_vector);
		for (int j = 0; j < matrix_size; ++j){
			gsl_complex z = gsl_vector_complex_get(&evec_i.vector, j);
			gsl_vector_set(g,j,GSL_REAL(z)/good_sum_of_eigens);
		}
#ifdef DEBUG_DTMC
		for (int j = 0; j < matrix_size; ++j)
			fprintf(stdout,"%s(%d) = %lf\n",name,j,gsl_vector_get(g,j));
#endif
		gsl_vector_complex_free(eval);
		gsl_matrix_complex_free(evec);
		return g;
	}
	else{
		fprintf(stdout,"HOUSTON: solution of MC yields %d potential sets\n",n_potential_solutions);
		exit(EXIT_FAILURE);
	}
}



/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_vector * my_my_solve_DTMC(gsl_matrix *data, char name[]){
int size = data->size1;

// FOR DTMC SOLUTION LOOK HERE: https://nicolewhite.github.io/2014/06/10/steady-state-transition-matrix.html
	gsl_vector *x = gsl_vector_calloc(size);
	// Adding a bottom row [1,1,..1] to matrix
	gsl_matrix *P = gsl_matrix_alloc(size + 1, size);
	for(int row = 0; row < size; row++)
		for(int col = 0; col < size; col++)
			gsl_matrix_set(P,row,col,gsl_matrix_get(data,row,col));
	for(int col = 0; col < size; col++)
		gsl_matrix_set(P,size,col,1);
	gsl_vector *b = gsl_vector_calloc(size+1);
	gsl_vector_set_zero(b);
	gsl_vector_set(b,size,1);

	gsl_vector *tau = gsl_vector_alloc(size);
	gsl_vector *residual = gsl_vector_alloc(size+1);
	gsl_linalg_QR_decomp(P, tau);
	gsl_linalg_QR_lssolve(P, tau, b, x, residual);
// FOR DTMC SOLUTION LOOK HERE: https://nicolewhite.github.io/2014/06/10/steady-state-transition-matrix.html

//#ifdef DEBUG_DTMC
	print_vector(stdout,x,name);
	double sum = 0;
	for(int i = 0; i < size; i++)
		sum += gsl_vector_get(x,i);
	fprintf(stdout,"sum of %s is %lf\n",name,sum);
//#endif

	gsl_matrix_free(P);
	gsl_vector_free(tau);
	gsl_vector_free(residual);
	gsl_vector_free(b);


	return x;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double gsl_my_matrix_norm(gsl_matrix *matrix){
	double matrix_norm = 0;

	for (int j = 0; j < matrix->size1; j++){
		gsl_vector_view column = gsl_matrix_column (matrix, j);
		matrix_norm += gsl_blas_dnrm2 (&column.vector);
	}
	return matrix_norm;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double MIN(double a, double b){
	return(a < b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double psi(int n, double mu, double THETA){
	double psi_ret = (mu * pow(THETA,n)) / pow(mu +  THETA, n + 1);
	if(isnan(psi_ret))
		psi_ret = 0;
	return psi_ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void init_MMPP(int nclients, double Ton, double Toff, double Lon, double Loff){
	m = nclients + 1; // m is a global variable

	LAMBDA = gsl_matrix_calloc(m, m);
	for(int i = 0; i < m; i++)
		gsl_matrix_set(LAMBDA, i, i, i * Lon + (nclients - i) * Loff);

	Q = gsl_matrix_calloc(m, m);
	for(int i = 0; i < m; i++){
		double row_sum = 0;
		if( i > 0 ) {
			gsl_matrix_set(Q, i, i - 1, i/Ton);
			row_sum += gsl_matrix_get(Q, i, i - 1);
		}
		if(i < m - 1) {
			gsl_matrix_set(Q, i, i + 1, (m - i)/Toff);
			row_sum += gsl_matrix_get(Q, i, i + 1);
		}
		gsl_matrix_set(Q, i, i, -row_sum);
	}
	DISCRETE_Q = gsl_matrix_calloc(m, m);
	for(int row = 0; row < m; row++){
		for(int col = 0; col < m; col++){
			if(row != col)
				gsl_matrix_set(DISCRETE_Q, row, col, gsl_matrix_get(Q, row, col) / (-gsl_matrix_get(Q, row, row)));
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double CDF_MMPP(double T, int nclients, double Ton, double Toff, double Lon, double Loff, double mu){

	init_MMPP(nclients, Ton, Toff, Lon, Loff);
	gsl_matrix *P = gsl_matrix_calloc(m, m); // Used later
	gsl_matrix_memcpy(P,DISCRETE_Q);	
	gsl_matrix *I = gsl_matrix_calloc(m, m); // Used later
	gsl_matrix_set_identity(I); 
	gsl_matrix_sub(P,I); 
	gsl_matrix *DISCRETE_QT = gsl_matrix_calloc(m, m);
	gsl_matrix_transpose_memcpy(DISCRETE_QT,P);
	pie = my_my_solve_DTMC(DISCRETE_QT,"PIE");
#ifdef DEBUG
	print_matrix(stdout, LAMBDA,"LAMBDA");
	print_matrix(stdout, Q,"Q");
	print_matrix(stdout, DISCRETE_Q,"DISCRETE Q");
	print_matrix(stdout, DISCRETE_QT,"DISCRETE QT");
	print_vector(stdout,pie,"pie");
#endif
	lambda_T = gsl_vector_calloc(m);
	lambda_tot = 0;
	for(int i = 0; i < m; i++){
		lambda_tot += gsl_vector_get(pie, i) * gsl_matrix_get(LAMBDA, i, i);
		gsl_vector_set(lambda_T,i,gsl_matrix_get(LAMBDA, i, i));
	}
	rho = lambda_tot / mu;
	fprintf(stdout,"lambda = %lf, mu = %lf, rho = %lf\n",lambda_tot,mu,rho);

	gsl_matrix * LAMBDA_minus_Q = gsl_matrix_calloc(m, m);
	gsl_matrix_memcpy(LAMBDA_minus_Q, LAMBDA);
	gsl_matrix_sub(LAMBDA_minus_Q, Q);

	gsl_matrix * Q_minus_LAMBDA = gsl_matrix_calloc(m, m);
	gsl_matrix_memcpy(Q_minus_LAMBDA, Q);
	gsl_matrix_sub(Q_minus_LAMBDA, LAMBDA);

	double THETA = -DBL_MAX;
	for(int i = 0; i < m; i++){
		if(gsl_matrix_get(LAMBDA_minus_Q,i,i) > THETA){
			THETA = gsl_matrix_get(LAMBDA_minus_Q,i,i);
		}
#ifdef DEBUG
		fprintf(stdout,"L-Q[%d,%d] = %lf\n",i,i,gsl_matrix_get(LAMBDA_minus_Q,i,i));
#endif
	}
#ifdef DEBUG
	print_matrix(stdout, LAMBDA, "LAMBDA");
	print_matrix(stdout, Q, "Q");
	print_matrix(stdout, LAMBDA_minus_Q,"LAMBDA - Q");
	fprintf(stdout,"THETA = %lf\n",THETA);
#endif
	double sum_of_psin = 0;
	int n = 0; int nstar; 
	do {
		double psin = psi(n, mu, THETA);
		sum_of_psin += psin;
#ifdef DEBUG
		fprintf(stdout,"n = %d : psin(n,mu,THETA) = %lf : sum of psi = %lf\n",n,psin,sum_of_psin);
#endif
		n++;
	} while((sum_of_psin <= 1 - epsilon1) && n <= MAX_ITER);
	nstar = n - 1;
#ifdef DEBUG
	fprintf(stdout,"nstar = %d\n",nstar);
#endif
	// MATRIX ALLOCATION
	gsl_matrix ** GTEMP = (gsl_matrix **)calloc(2,sizeof(gsl_matrix *));
	GTEMP[0] = gsl_matrix_calloc(m, m);
	GTEMP[1] = gsl_matrix_calloc(m, m);
	gsl_matrix ** H = (gsl_matrix **)calloc(nstar + 1,sizeof(gsl_matrix *));
	for(int i = 0; i <= nstar; i++)
		H[i] = gsl_matrix_calloc(m, m);
	gsl_matrix *LGPROD = gsl_matrix_calloc(m, m);
	gsl_matrix *THREE_TERMS = gsl_matrix_calloc(m, m);
	gsl_matrix *SQUAREBRCK = gsl_matrix_calloc(m, m);
	gsl_matrix *GDIFF = gsl_matrix_calloc(m, m);
	gsl_matrix *G = gsl_matrix_calloc(m, m);
	
	// MATRIX INIT
	int kp1 = 1; int k = 0;
	gsl_matrix_set_zero(GTEMP[0]);
	int iter = 1;
	for(int kk = 0; ; kk++){
		char matrix_name[64];
		gsl_matrix_set_identity(H[0]);
#ifdef DEBUG
		sprintf(matrix_name,"H[0]");
		print_matrix(stdout, H[0],matrix_name);
#endif
		for(int i = 0; i < nstar; i++){
			gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, LAMBDA, GTEMP[k], 0.0, LGPROD);
#ifdef DEBUG
			sprintf(matrix_name,"LAMBDA * G(%d)",k);
			print_matrix(stdout, LGPROD, matrix_name);
#endif
			gsl_matrix_memcpy(THREE_TERMS, Q_minus_LAMBDA);
			gsl_matrix_add(THREE_TERMS, LGPROD);
			gsl_matrix_scale(THREE_TERMS, 1/THETA);
			gsl_matrix_set_identity(SQUAREBRCK);
			gsl_matrix_add(SQUAREBRCK, THREE_TERMS);
			gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, SQUAREBRCK, H[i], 0.0, H[i+1]);
#ifdef DEBUG
			sprintf(matrix_name,"H[%d]",i + 1);
			print_matrix(stdout, H[i + 1],matrix_name);
#endif
		}
		gsl_matrix_set_zero(GTEMP[kp1]);
		for(int i = 0; i <= nstar; i++){
			gsl_matrix_scale(H[i], psi(i,mu,THETA));
			gsl_matrix_add(GTEMP[kp1], H[i]);
#ifdef DEBUG
			char name[64];
			sprintf(name,"nstar %d - G(k+1) - after adding H(%d) - psi(%d) = %lf\n",nstar,i,i,psi(i,mu,THETA));
			print_matrix(stdout, GTEMP[kp1],name);
#endif
		}

#ifdef DEBUG
		print_matrix(stdout, GTEMP[k],"G(k)");
		print_matrix(stdout, GTEMP[kp1],"G(k+1)");
		getchar();
#endif
		gsl_matrix_memcpy(GDIFF, GTEMP[k]);
		gsl_matrix_sub(GDIFF, GTEMP[kp1]);
		double mnorm = gsl_my_matrix_norm(GDIFF);
#ifdef DEBUG
		fprintf(stdout,"norm = %lf\n",mnorm);
		print_matrix(stdout, GDIFF,"G(k-1) - G(k)");
#endif
		if(mnorm < epsilon2 || iter > MAX_ITER){
#ifdef DEBUG
			fprintf(stdout,"Ended at step %d with\n",kk);
#endif
			gsl_matrix_memcpy(G, GTEMP[kp1]);

			gsl_matrix_memcpy(P,G);
			gsl_matrix_sub(P,I);
			gsl_matrix *GT = gsl_matrix_calloc(m, m);
			gsl_matrix_transpose_memcpy(GT,P);
#ifdef DEBUG
			print_matrix(stdout, G,"G");
			print_matrix(stdout, GT,"GT");
#endif
			g = my_my_solve_DTMC(GT,"g");
#ifdef DEBUG
//			gsl_complex s = gsl_complex_rect(0,0);
//			for(; gsl_complex_abs(s) <= 100; s = gsl_complex_add(s,gsl_complex_rect(1,1))){
//				gsl_complex result = complex_LST(s);
//				fprintf(stdout,"s = %lf +i%lf: LST = %lf +i%lf\n",GSL_REAL(s), GSL_IMAG(s), GSL_REAL(result), GSL_IMAG(result));
//				getchar();
//			}
//			getchar();
#endif
			// computing h*pie*LAMBDA
			gsl_vector * pie_LAMBDA = row_matrix_prod(pie, LAMBDA);
			gsl_vector_scale(pie_LAMBDA, 1/mu); // 1/mu = h
			// computing h*pie*LAMBDA
			
			// computing (1 - rho)*g
			gsl_vector *bracket = gsl_vector_calloc(m);
			gsl_vector_memcpy(bracket,g);
			gsl_vector_scale(bracket,1 - rho);
			// computing (1 - rho)*g
			
			// computing [(1 - rho)*g + h*pie*LAMBDA]
			gsl_vector_add(bracket, pie_LAMBDA);
			// computing [(1 - rho)*g + h*pie*LAMBDA]
			
			// computing (Q+e*pie)
			gsl_matrix *e_pie = gsl_matrix_calloc(m,m);
			for(int row = 0; row < m; row++)
				gsl_matrix_set_row(e_pie, row, pie);
			gsl_matrix *Q_plus_epie = gsl_matrix_calloc(m,m);
			gsl_matrix_memcpy(Q_plus_epie,Q);
			gsl_matrix_add(Q_plus_epie,e_pie);
			// computing (Q+e*pie)
			
			// computing (Q+e*pie)^-1
			gsl_matrix *inv_Q_plus_epie = invert_a_matrix(Q_plus_epie);
			// computing (Q+e*pie)^-1

			// computing [(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1
			gsl_vector * three_prod = row_matrix_prod(bracket, inv_Q_plus_epie);
			// computing [(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1

			// computing 2h*[(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1
			gsl_vector_scale(three_prod,2/mu);
			// computing 2h*[(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1

			// computing {2h*[(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1}*lambdaT
			double wmed = row_column_prod(three_prod, lambda_T);
			// computing {2h*[(1 - rho)*g + h*pie*LAMBDA]*[Q+e*pie)^-1}*lambdaT
			fprintf(stdout,"right value Wv is %lf\n",wmed);
			fprintf(stdout,"left value Wv is %lf\n",2*rho+lambda_tot*(2/(mu*mu)));

			wmed = 2 * rho + lambda_tot * (2 / (mu * mu)) - wmed; // h(2) for exponential is 2 / mu^2
			fprintf(stdout,"numerator value Wv is %lf\n",wmed);
			wmed = wmed / (2 *(1 - rho));
			fprintf(stdout,"Virtual waiting time from cookbook average after dividing by 2(1-r) %lf\n",wmed);
			
			// Up to here wmed is the average waiting time....
			// the average service time must be added
#ifdef DEBUG_WMED
			fprintf(stdout,"Virtual waiting time from cookbook average is %lf\n",wmed);
#endif

			wmed = wmed + 1/mu;

			fprintf(stdout,"Wv average is %lf\n",wmed);

			gsl_complex result = InverseLaplaceTransform(T);
			fprintf(stdout,"T = %lf : P[W < T] = %lf\n",T,GSL_REAL(result));



			gsl_matrix_free(LAMBDA);
			gsl_matrix_free(Q);
			gsl_matrix_free(DISCRETE_Q);
			gsl_vector_free(three_prod);			
			gsl_vector_free(bracket);			
			gsl_vector_free(pie_LAMBDA);			
			gsl_matrix_free(e_pie);
			gsl_matrix_free(Q_plus_epie);
			gsl_matrix_free(inv_Q_plus_epie);

			gsl_matrix_free(GT);
			gsl_vector_free(g);
			gsl_vector_free(lambda_T);
			gsl_matrix_free(LAMBDA_minus_Q);
			gsl_matrix_free(Q_minus_LAMBDA);
			gsl_matrix_free(GTEMP[0]);
			gsl_matrix_free(GTEMP[1]);
			free(GTEMP);
			gsl_matrix_free(LGPROD);
			gsl_matrix_free(THREE_TERMS);
			gsl_matrix_free(SQUAREBRCK);
			gsl_matrix_free(GDIFF);
			for(int i = 0; i <= nstar; i++)
				gsl_matrix_free(H[i]);
			free(H);
			free(G);
			gsl_matrix_free(I);
			gsl_matrix_free(P);
			gsl_vector_free(pie);
			break;
		}
		k = (k + 1)%2;
		kp1 = (kp1 + 1)%2;
		iter++;
	}
}
int main(int argc, char *argv[]){
	if(argc != 8){
		fprintf(stdout,"usage: %s T nclients Ton Toff Lambdaon Lambdaoff service-rate\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	double T = atof(argv[1]);
	int nclients = atoi(argv[2]);
	double Ton = atof(argv[3]);
	double Toff = atof(argv[4]);
	double Lon = atof(argv[5]);
	double Loff = atof(argv[6]);
	mu = atof(argv[7]);

	CDF_MMPP(T, nclients, Ton, Toff, Lon, Loff, mu);
	return EXIT_SUCCESS;
}
