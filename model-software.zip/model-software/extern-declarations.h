extern int extra_brothers;
extern int extra_uncles;
extern int extra_grandpas;

extern int L;
extern int r;
extern int ncode_at_0;
extern int kcode_at_0;
extern int *ncode;
extern int *kcode;
extern int F;
extern int N;
extern int Nactive;
extern int n_replicas;
extern int Fmax;
extern double z;
extern double y;
extern int topF;
extern int ncode_at_0_topF;
extern int kcode_at_0_topF;

extern double MAXF;

extern double *p;
extern char *active_FN;

extern unsigned int *FN_capacity;
extern double *average_occupancy;

extern double *file_popularity;
extern double **file_allocation;
extern int **rp;
