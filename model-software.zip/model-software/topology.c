#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include "defines.h"
#include "extern-declarations.h"

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_father(int FN_id){
	int father_id = UNKNOWN;

	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int seq_no = FN_id - get_leftmost_id(l);
		int grp_no = seq_no/r;
		father_id = get_leftmost_id(l - 1) + grp_no;
	}
	return father_id;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_brother(int FN_id, int distance){
	int brother_id = UNKNOWN;
	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int leftmost = get_leftmost_id(l);
		int rightmost = get_rightmost_id(l);
		brother_id = leftmost + (FN_id - leftmost + distance)%(rightmost - leftmost + 1);
	}
	return brother_id;
}
