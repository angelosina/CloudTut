// BASED ON 
// Yuan, B., Li, H., Bertozzi, A. L., Brantingham, P. J., & Porter, M. A. 
// Multivariate spatiotemporal hawkes processes and network reconstruction 
// SIAM Journal on Mathematics of Data Science, 2019, 1(2), 356-382.
// Algorithm 3.3

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_sf.h>
#include <gsl/gsl_permutation.h>
#include <gsl/gsl_combination.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_sort.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_linalg.h>

//#define DEBUG
#define TRUE 1
#define FALSE 0

#define ORIGIN 79 // ASCII CODE FOR 'O'
#define BACKGROUND 66 // ASCII CODE FOR 'B'
#define TRIGGERED 84 // ASCII CODE FOR 'T'

#define NEGATIVE_TIME -1

#define MODEL 4
#define STATS 3
#define HUMAN_READABLE 2
#define SPATIO_TEMPORAL 1
#define TEMPORAL 0

//#define FROM_FILE

#define UNKNOWN_U UINT_MAX
#define UNKNOWN_ID UINT_MAX
#define UNKNOWN_DISTANCE_ANCESTOR UINT_MAX

#define MAX_DISTANCE_ANCESTOR 128

gsl_ran_discrete_t **f;

unsigned int n_events = 0;
double T = NEGATIVE_TIME;
double R = 0;
unsigned int U = UNKNOWN_U;
int ordered_flag = TRUE;
int length_flag = SPATIO_TEMPORAL;
unsigned long int seed = 0;

double *gamma_ = NULL;
double **K_ = NULL;

double w = 2.0;
double sigma_x = 1;
double sigma_y = 1;
double sigma2;
double rho = 0;


typedef struct node { 
	unsigned int u; // It is fog node id
	double x;
	double y; // It is physical coordinates of fog node
	double t; // It is client request time
	double t_father;
	unsigned int u_father;
	unsigned int id_father;
	char type;
	unsigned int id;
	double t_ancestor;
	unsigned int u_ancestor;
	unsigned int id_ancestor;
	unsigned int distance_ancestor;
	struct node* next; 

} Node; 

Node* STACK = NULL;
Node* SET = NULL;

Node *free_h = NULL;
unsigned int n_free = 0;

unsigned int ***n_triggered = NULL;
unsigned int *n_background = NULL;
unsigned int max_distance_ancestor = 0;
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/

Node* newNode(unsigned int u, double x, double y, double t, char type, unsigned int u_father, unsigned int id, double t_father, unsigned int id_father, unsigned int u_ancestor, double t_ancestor, unsigned int id_ancestor, unsigned int distance_ancestor){ 
	Node* temp;

	if(free_h == NULL){
		temp = (Node*)malloc(sizeof(Node)); 
	}
	else{
		temp = free_h;
		free_h = free_h->next;
		n_free--;
	}
	temp->u = u; 
	temp->x = x; 
	temp->y = y; 
	temp->t = t; 
	temp->type = type; 
	temp->u_father = u_father; 
	temp->id = id; 
	temp->t_father = t_father; 
	temp->id_father = id_father; 

	temp->u_ancestor = u_ancestor; 
	temp->t_ancestor = t_ancestor; 
	temp->id_ancestor = id_ancestor; 
	temp->distance_ancestor = distance_ancestor; 
	temp->next = NULL; 
	return temp; 
} 

unsigned int peek_u(Node** head) { return (*head)->u; } 
double peek_x(Node** head) { return (*head)->x; } 
double peek_y(Node** head) { return (*head)->y; } 
double peek_t(Node** head) { return (*head)->t; } 
char peek_type(Node** head) { return (*head)->type; } 
unsigned int peek_u_father(Node** head) { return (*head)->u_father; } 
double peek_t_father(Node** head) { return (*head)->t_father; } 
unsigned int peek_id(Node** head) { return (*head)->id; } 
unsigned int peek_id_father(Node** head) { return (*head)->id_father; } 

unsigned int peek_u_ancestor(Node** head) { return (*head)->u_ancestor; } 
double peek_t_ancestor(Node** head) { return (*head)->t_ancestor; } 
unsigned int peek_id_ancestor(Node** head) { return (*head)->id_ancestor; } 
unsigned int peek_distance_ancestor(Node** head) { return (*head)->distance_ancestor; } 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/

void print_event(Node** event, unsigned int event_id){
	unsigned int u_i = peek_u(event);
	double x_i = peek_x(event);
	double y_i = peek_y(event);
	double t_i = peek_t(event);
	char type_i = peek_type(event);
	unsigned int u_father_i = peek_u_father(event);
	double t_father_i = peek_t_father(event);
	unsigned int id_i = peek_id(event);
	unsigned int id_father_i = peek_id_father(event);

	unsigned int u_ancestor_i = peek_u_ancestor(event);
	double t_ancestor_i = peek_t_ancestor(event);
	unsigned int id_ancestor_i = peek_id_ancestor(event);
	unsigned int distance_ancestor_i = peek_distance_ancestor(event);

	switch(length_flag){
		case HUMAN_READABLE:
			fprintf(stdout,":: EVENT %u :: type %c : id %u : u %u : x %lf : y %lf : t %lf :: FATHER :: t_fath %lf : u_fath %u : id_fath %u :: ANCESTOR :: t_anc %lf : u_anc %u : id_anc %u : dist_anc %u\n",event_id,type_i,id_i, u_i, x_i, y_i, t_i, t_father_i, u_father_i, id_father_i, t_ancestor_i, u_ancestor_i, id_ancestor_i, distance_ancestor_i); 
			break;
		case SPATIO_TEMPORAL:
			if(u_i != UNKNOWN_U)
				fprintf(stdout,"%d %lf %lf %lf\n", u_i + 1, t_i, x_i, y_i);
			break;
		case TEMPORAL:
			if(u_i != UNKNOWN_U)
				fprintf(stdout,"%d %lf\n", u_i + 1, t_i);
			break;
		default:
			break;
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_stack(){
	unsigned int n = 0;

	if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"STACK IS\n---------------\n");
	if(STACK != NULL){
		for(Node* event = STACK; event != NULL ; n++, event = event->next)
			print_event(&event,n);
	}
	else if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"EMPTY STACK\n");
	if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"length = %u\n",n);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_set(){
	unsigned int n = 0;

	if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"SET IS\n---------------\n");
	if(SET != NULL){
		for(Node* event = SET; event != NULL ; n++, event = event->next)
			print_event(&event,n);
	}
	else if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"EMPTY SET\n");
	if(length_flag == HUMAN_READABLE)
		fprintf(stdout,"length = %u\n",n);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_free(){
	unsigned int n = 0;
	fprintf(stdout,"FREE LIST IS\n---------------\n");
	if(free_h != NULL){
		for(Node* event = free_h; event != NULL ; n++, event = event->next)
			print_event(&event,n);
	}
	else
		fprintf(stdout,"EMPTY FREE LIST\n");
	fprintf(stdout,"length = %u\n",n);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void pop(Node** head) { 
	Node* temp = *head; 
	(*head) = (*head)->next; 

	if(free_h == NULL){
		free_h = temp;
		free_h->next = NULL;
	}
	else{
		temp->next = free_h;
		free_h = temp;
	}
	n_free++;
} 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void push(Node** head, unsigned int u, double x, double y, double t, char type, unsigned int u_father, unsigned int id, double t_father, unsigned int id_father, unsigned int u_ancestor, double t_ancestor, unsigned int id_ancestor, unsigned int distance_ancestor) { 
	Node*  temp = newNode(u, x, y, t, type, u_father, id, t_father, id_father, u_ancestor, t_ancestor, id_ancestor, distance_ancestor); 
	if(*head != NULL){
		temp->next = *head; 
	}
	(*head) = temp; 
} 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void insert(Node** head, unsigned int u, double x, double y, double t, char type, unsigned int u_father, unsigned int id, double t_father, unsigned int id_father, unsigned int u_ancestor, double t_ancestor, unsigned int id_ancestor, unsigned int distance_ancestor) { 
	Node* start = (*head); 
	Node* temp = newNode(u, x, y, t, type, u_father, id, t_father, id_father, u_ancestor, t_ancestor, id_ancestor, distance_ancestor); 

	if ((*head)->t > t) { 
		temp->next = *head; 
		(*head) = temp; 
	} 
	else { 
		while (start->next != NULL && start->next->t < t) { 
			start = start->next; 
		} 
		temp->next = start->next; 
		start->next = temp; 
	} 
} 
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int isEmpty(Node** head) { return (*head) == NULL; } 

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void allocate_structures(){
	gamma_ = (double *)calloc(U, sizeof(double));
	K_ = (double **)calloc(U, sizeof(double *));
	for(unsigned int u = 0; u < U; u++)
		K_[u] = (double *)calloc(U, sizeof(double));

	if(length_flag != MODEL){
		n_triggered = (unsigned int ***)calloc(U, sizeof(unsigned int **));
		for(unsigned int u = 0; u < U; u++)
			n_triggered[u] = (unsigned int **)calloc(U, sizeof(unsigned int *));
		for(unsigned int u = 0; u < U; u++)
			for(unsigned int uu = 0; uu < U; uu++)
				n_triggered[u][uu] = (unsigned int *)calloc(MAX_DISTANCE_ANCESTOR, sizeof(unsigned int));

		for(unsigned int u = 0; u < U; u++)
			for(unsigned int uu = 0; uu < U; uu++)
				for(unsigned int distance = 0; distance < MAX_DISTANCE_ANCESTOR; distance++)
					n_triggered[u][uu][distance] = 0;

		n_background = (unsigned int *)calloc(U, sizeof(unsigned int));
		for(unsigned int u = 0; u < U; u++)
			n_background[u] = 0;
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void gsl_matrix_fprintf_formatted(gsl_matrix *m){
	unsigned int i, j;

	for (i = 0; i < U; i++){
		for (j = 0; j < U; j++)
			fprintf(stdout,"%lf\t", gsl_matrix_get(m, i, j));
		fprintf(stdout,"\n");
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double  gsl_matrix_spectral_norm(gsl_matrix *m){
	gsl_matrix *temp = gsl_matrix_alloc (U, U);


	gsl_blas_dgemm(CblasConjTrans, CblasNoTrans, 1.0, m, m, 0.0, temp);
	
	gsl_vector_complex *eval = gsl_vector_complex_alloc (U);
	gsl_matrix_complex *evec = gsl_matrix_complex_alloc (U, U);

	gsl_eigen_nonsymmv_workspace * w = gsl_eigen_nonsymmv_alloc (U);
	gsl_eigen_nonsymmv (temp, eval, evec, w);
	gsl_eigen_nonsymmv_free (w);
	gsl_eigen_nonsymmv_sort (eval, evec, GSL_EIGEN_SORT_VAL_DESC);

        double spectral_norm = sqrt(GSL_REAL(gsl_vector_complex_get (eval, 0)));

	gsl_vector_complex_free (eval);
	gsl_matrix_complex_free (evec);

	gsl_matrix_free (temp);

	return spectral_norm;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
gsl_matrix * invert_a_matrix(gsl_matrix *matrix){
	size_t size = matrix->size1;

	gsl_permutation *p = gsl_permutation_alloc(size);
	int s;

	// Compute the LU decomposition of this matrix
	gsl_linalg_LU_decomp(matrix, p, &s);

	// Compute the  inverse of the LU decomposition
	gsl_matrix *inv = gsl_matrix_alloc(size, size);
	gsl_linalg_LU_invert(matrix, p, inv);
	gsl_permutation_free(p);

	return inv;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_stats(){
	double model_average_number_of_requests[U];
	double actual_average_number_of_requests[U];

	gsl_matrix *Ksum = gsl_matrix_alloc(U, U);

	max_distance_ancestor = (max_distance_ancestor > 0)?max_distance_ancestor:MAX_DISTANCE_ANCESTOR;
	gsl_matrix **K_power = (gsl_matrix **)calloc(max_distance_ancestor + 1, sizeof(gsl_matrix *));
	for(unsigned int distance = 1; distance <= max_distance_ancestor; distance++)
		K_power[distance] = gsl_matrix_alloc(U, U);
	for (unsigned int i = 0; i < U; i++)
		for (unsigned int j = 0; j < U; j++){
			gsl_matrix_set (Ksum, i, j, K_[i][j]);
			gsl_matrix_set (K_power[1], i, j, K_[i][j]);
		}
	fprintf(stdout,"========== K, spectral norm = %lf =============\n",gsl_matrix_spectral_norm(K_power[1]));

	for(unsigned int distance = 2; distance <= max_distance_ancestor; distance++){// LOOP FOR POWERS OF K
		gsl_blas_dgemm(CblasNoTrans, CblasNoTrans, 1.0, K_power[1], K_power[distance - 1], 0.0, K_power[distance]);
		gsl_matrix_add(Ksum, K_power[distance]);
		fprintf(stdout,"========== K^%u, spectral norm = %lf =============\n",distance,gsl_matrix_spectral_norm(K_power[distance]));
	}// LOOP FOR POWERS OF K

	if(length_flag == STATS){
		for(unsigned int distance = 1; distance <= max_distance_ancestor; distance++){// LOOP FOR POWERS OF K
			for(unsigned int u = 0; u < U; u++){
				for(unsigned int uu = 0; uu < U; uu++){
					fprintf(stdout,"%.3lf (%.3lf)\t",(double)n_triggered[u][uu][distance]/n_background[u],gsl_matrix_get(K_power[distance], u, uu));
				}
				fprintf(stdout,"\n");
			}
		}// LOOP FOR POWERS OF K


		for(unsigned int u = 0; u < U; u++){
			model_average_number_of_requests[u] = 0;
			actual_average_number_of_requests[u] = n_background[u];
			for(unsigned int uu = 0; uu < U; uu++){
				double triggered_by_uu = 0;
				for(unsigned int distance = 1; distance <= max_distance_ancestor; distance++){// LOOP FOR POWERS OF K
					triggered_by_uu += gsl_matrix_get(K_power[distance], uu, u);
					actual_average_number_of_requests[u] += n_triggered[uu][u][distance];
				}
				model_average_number_of_requests[u] += triggered_by_uu * (T * gamma_[uu]);
			}
			model_average_number_of_requests[u] += T * gamma_[u];
			fprintf(stdout,"#requests for data %u = %.3lf (%.3lf) model background = %.3lf actual background = %.3lf\n",u,model_average_number_of_requests[u],actual_average_number_of_requests[u],T * gamma_[u], (double)n_background[u]);
		}

		double global_rate = 0;
		for(unsigned int u = 0; u < U; u++){
			model_average_number_of_requests[u] = 0;
			for(unsigned int uu = 0; uu < U; uu++){
				double triggered_by_uu = 0;
				for(unsigned int distance = 1; distance <= max_distance_ancestor; distance++){// LOOP FOR POWERS OF K
					triggered_by_uu += gsl_matrix_get(K_power[distance], uu, u);
				}
				model_average_number_of_requests[u] += triggered_by_uu;
			}
			model_average_number_of_requests[u] += gamma_[u];
			global_rate += model_average_number_of_requests[u];
			fprintf(stdout,"#overall rate for data %u = %.3lf\n",u,model_average_number_of_requests[u]);
		}
		fprintf(stdout,"#global rate = %.3lf\n",global_rate);
	}
	else if(length_flag == MODEL){
		gsl_matrix *K_limit = gsl_matrix_alloc(U, U);
		gsl_matrix *IminusK = gsl_matrix_alloc(U, U);
		gsl_matrix *I = gsl_matrix_alloc(U, U);

		gsl_matrix_set_identity(IminusK);
		gsl_matrix_set_identity(I);

		gsl_matrix_sub(IminusK, K_power[1]);

		K_limit = invert_a_matrix(IminusK);
		gsl_matrix_sub(K_limit, I);
		fprintf(stdout,"Theoretical limit [I - K]^(-1) - I\n"); /* https://www.quora.com/How-do-I-calculate-the-power-series-for-a-matrix */
		gsl_matrix_fprintf_formatted(K_limit);
		fprintf(stdout,"Numerically computed\n");
		gsl_matrix_fprintf_formatted(Ksum);

		double global_rate = 0;
		for(unsigned int u = 0; u < U; u++){
			model_average_number_of_requests[u] = 0;
			for(unsigned int uu = 0; uu < U; uu++)
				model_average_number_of_requests[u] += gsl_matrix_get(K_limit, uu, u);
			model_average_number_of_requests[u] += gamma_[u];
			global_rate += model_average_number_of_requests[u];
			fprintf(stdout,"#overall rate for data %u = %.3lf\n",u,model_average_number_of_requests[u]);
		}
		fprintf(stdout,"#global rate = %.3lf\n",global_rate);

		gsl_matrix_free(K_limit);
		gsl_matrix_free(IminusK);
		gsl_matrix_free(I);
	}
	for(unsigned int distance = 1; distance <= max_distance_ancestor; distance++)
		gsl_matrix_free(K_power[distance]);
	free(K_power);
	gsl_matrix_free(Ksum);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void deallocate_structures(){
	free(gamma_);
	for(unsigned int u = 0; u < U; u++)
		free(K_[u]);
	free(K_);
	if(length_flag != MODEL){
		for(unsigned int u = 0; u < U; u++)
			gsl_ran_discrete_free(f[u]);
		free(f);

		Node* temp;
		while (SET != NULL){
			temp = SET;
			SET = SET->next;
			free(temp);
		}
		while (STACK != NULL){
			temp = STACK;
			STACK = STACK->next;
			free(temp);
		}
		while (free_h != NULL){
			temp = free_h;
			free_h = free_h->next;
			free(temp);
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void init_structures(){
	sigma2 = sigma_x * sigma_x;

#ifdef FROM_FILE
	FILE *fp = fopen("MultiSTHP-master/mu1.txt","r");
	for(unsigned int u = 0; u < U; u++)
		fscanf(fp,"%lf",&gamma_[u]);
	fclose(fp);

	fp = fopen("MultiSTHP-master/A1.txt","r");
	for(unsigned int u = 0; u < U; u++){
		for(int unsigned v = 0; v < U; v++){
			fscanf(fp,"%lf",&K_[u][v]);
//			fprintf(stdout,"%lf ",K_[u][v]);
		}
//		fprintf(stdout,"\n");
	}
	fclose(fp);
#else
	for(unsigned int u = 0; u < U; u++)
		gamma_[u] = u + 1;
	for(unsigned int u = 0; u < U; u++){
		for(unsigned int v = 0; v < U; v++){
			if(u == v)
				K_[u][v] = 1.0 / U;
			else
				K_[u][v] = 1.0 / (2 * U);
		}
	}
#endif


	f = (gsl_ran_discrete_t **)calloc(U, sizeof(gsl_ran_discrete_t *));
	for(unsigned int u = 0; u < U; u++)
		f[u] = gsl_ran_discrete_preproc(U,K_[u]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double g1(double t){ return w * exp(-w * t); }
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double g2(double x, double y){ return exp(-((x *x + y * y) / (2 * sigma2))) / (2 * M_PI * sigma2); }
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double g(double t, double x, double y){ return g1(t) * g2(x,y); }

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generate_background_events(gsl_rng *r){
	unsigned int Nb[U];

	for(unsigned int u = 0; u < U; u++){
		Nb[u] = gsl_ran_poisson(r, gamma_[u] * T);
	}
	for(unsigned int u = 0; u < U; u++){
		for(unsigned int i = 0; i < Nb[u]; i++){
			double t = gsl_ran_flat(r, 0, T);
			double x = gsl_ran_flat(r, -R, R);
			double y = gsl_ran_flat(r, -R, R);
			n_events++;
			push(&STACK, u, x, y, t, BACKGROUND, UNKNOWN_U, n_events, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_U, NEGATIVE_TIME, UNKNOWN_ID, 0); 
			if(ordered_flag)
				insert(&SET, u, x, y, t, BACKGROUND, UNKNOWN_U, n_events, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_U, NEGATIVE_TIME, UNKNOWN_ID, 0); 
			else
				push(&SET, u, x, y, t, BACKGROUND, UNKNOWN_U, n_events, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_U, NEGATIVE_TIME, UNKNOWN_ID, 0); 

		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void generate_triggered_events(gsl_rng *r, Node** event){
	double t_i = peek_t(&STACK);
	if(t_i >= 0){
		unsigned int u_i = peek_u(&STACK);
		double x_i = peek_x(&STACK);
		double y_i = peek_y(&STACK);
		unsigned int id_i = peek_id(&STACK);
		unsigned int distance_ancestor = peek_distance_ancestor(&STACK) + 1;

		if(distance_ancestor > max_distance_ancestor)
			max_distance_ancestor = distance_ancestor;

		unsigned int u_ancestor; double t_ancestor; unsigned int id_ancestor; 
		
		if(peek_type(&STACK) == BACKGROUND){
			u_ancestor = u_i;
			t_ancestor = t_i;
			id_ancestor = id_i;
			n_background[u_ancestor]++;
		}
		else{
			u_ancestor = peek_u_ancestor(&STACK);
			t_ancestor = peek_t_ancestor(&STACK);
			id_ancestor = peek_id_ancestor(&STACK);
		}

		double lambda_i = 0;
		for(int uprime = 0; uprime < U; uprime++)
			lambda_i += K_[u_i][uprime];
		unsigned int n_i = gsl_ran_poisson(r, lambda_i);

		pop(&STACK); 
		for(unsigned int k = 0; k < n_i; k++){
			unsigned int u_k = gsl_ran_discrete(r,f[u_i]);
			double t_k = t_i + gsl_ran_exponential(r, 1.0/w);
			double dx,dy; gsl_ran_bivariate_gaussian(r, sigma_x, sigma_y, rho, &dx, &dy);
			double x_k = x_i + dx;
			double y_k = y_i + dy;
			n_triggered[u_ancestor][u_k][distance_ancestor]++;
			if(t_k <= T){
				n_events++;
				push(&STACK, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i, u_ancestor, t_ancestor, id_ancestor, distance_ancestor); 
				if(ordered_flag)
					insert(&SET, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i, u_ancestor, t_ancestor, id_ancestor, distance_ancestor); 
				else
					push(&SET, u_k, x_k, y_k, t_k, TRIGGERED, u_i, n_events, t_i, id_i, u_ancestor, t_ancestor, id_ancestor, distance_ancestor); 
			}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main (int argc, char *argv[]){ 
	char c;

	while ((c = getopt (argc, argv, "T:R:U:o:w:x:y:s:l:h")) != -1)
	switch (c) {
                case 'T':
                        T = atof(optarg);
                        break;
                case 'R':
                        R = atof(optarg);
                        break;
                case 'U':
                        U = atoi(optarg);
                        break;
                case 's':
                        seed = (unsigned)atol(optarg);
                        break;
                case 'l':
                        length_flag = atoi(optarg);
			if(length_flag != TEMPORAL && length_flag != SPATIO_TEMPORAL && length_flag != HUMAN_READABLE && length_flag != STATS && length_flag != MODEL){
                        	fprintf(stderr,"Abort: output length option (-l) is invalid\n");
				exit(EXIT_FAILURE);
			}	
                        break;
                case 'o':
                        ordered_flag = atoi(optarg);
                        break;
                case 'w':
                        w = atof(optarg);
                        break;
                case 'x':
                        sigma_x = atof(optarg);
                        break;
                case 'y':
                        sigma_y = atof(optarg);
                        break;
                case 'h':
                        fprintf(stderr,"usage: %s -T (T) -R (R) -U (U) -w (w) -o (any time-ordered | 0 not time-ordered) -l (0 temporal, 1 spatiotemporal, 2 human readable, 3 stats) -x (sigma_x) -y (sigma_y) -s (seed) -h (help)\n",argv[0]);
                        exit(EXIT_SUCCESS);
                default:
                        fprintf(stderr,"Abort: something is wrong in command line options\n");
                        exit(EXIT_FAILURE);
        }
	const gsl_rng_type *TT;
	gsl_rng *r;

	gsl_rng_env_setup();
	TT = gsl_rng_default;
	r = gsl_rng_alloc (TT);
	gsl_rng_set(r,seed);

	allocate_structures();
	init_structures();

	if(length_flag != MODEL){
		STACK = newNode(UNKNOWN_U, -R-1, -R-1, NEGATIVE_TIME, ORIGIN, UNKNOWN_U, UNKNOWN_ID, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_U, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_DISTANCE_ANCESTOR); 
		SET = newNode(UNKNOWN_U, -R-1, -R-1, NEGATIVE_TIME, ORIGIN, UNKNOWN_U, UNKNOWN_ID, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_U, NEGATIVE_TIME, UNKNOWN_ID, UNKNOWN_DISTANCE_ANCESTOR); 

		generate_background_events(r);
		while (!isEmpty(&STACK) && peek_t(&STACK) >= 0) { 
			generate_triggered_events(r,&STACK);
		} 
		print_set();
	}
	if(length_flag == STATS || length_flag == MODEL)
		print_stats();

	deallocate_structures();
	gsl_rng_free (r);

	return 0; 
} 


