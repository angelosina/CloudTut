#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

#define VALIDATION
//#define OUT 
#define UNBOUNDED -1
#define TRUE 1
#define FALSE 0
#define ROOT_FN 1
#define EPSILON 1e-4
#define UNFEASIBILITY_THRESHOLD 0.000001
#define UNKNOWN -1

#define POISSON 0
#define MULTINOMIAL 1

#define MM1 0
#define MMPPD1 1
//#define DEBUG_ALL

#ifndef DEBUG_ALL
//#define DEBUG_LOAD
//#define DEBUG_FILE_ALLOC
//#define DEBUG_RP
//#define DEBUG_LATENCY
#endif

#define PART_OF_DAY(t) (t%24)/6
int extra_brothers = 0;
int extra_uncles = 0;
int extra_grandpas = 0;
int extra_nclients = 0;
int overloaded1 = UNKNOWN;
int overloaded2 = UNKNOWN;

int L = 0;
int r = 0;
int ncode_at_0 = 0;
int kcode_at_0 = 0;
int *ncode = NULL;
int *kcode = NULL;
int F = 0;
int nclients = 0;
int N = 0;
int max_time = 0;
double lambda = 0;
double Ton = 0;
double Toff = 0;
int Nactive = 0;
int n_replicas = 0;
int Cmax = 0;
int Fmax = 0;
double lambdamax = 0;
double deadline = 0;
char server_type;
int nthreads;
double z = 0.00;
double y = 50.10;
int topF = 0;

int overall_nclients = 0;


double *p = NULL;
char *active_FN = NULL;

unsigned int *FN_capacity = NULL;
double *FN_service_rate = NULL;
double *FN_service_time = NULL;
int *FN_overall_nclients = NULL;
int *FN_nclients = NULL;
double *load_to_FN = NULL;
double *average_occupancy = NULL;

double *file_popularity = NULL;
double **file_allocation = NULL;
int **rp = NULL;

extern double Pcumulative_sum_of_binomials(int , int , int , double *);
extern void row_matrix_product(double *, double *, double **, int, int );
extern double compute_average_of_max_mmppd1(int, int *, int *, double *, double, double, double, double);
extern double compute_deadline_probability_mmppd1(double, int, int *, int *, double *, double, double, double, double);
extern double compute_deadline_probability_mm1(double, double *, double *, int);
extern double compute_average_of_max_mm1(int , double *, double *);
extern void build_and_solve_all_mmpp_queues(int, int *, double *, double, double, double, double, double *);
extern void free_all_mmpp_queues(int);

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double MIN(double a, double b){
	return(a < b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_FN_overall_nclients(){

	for(int FN_id = 1; FN_id <= N; FN_id++){
		FN_overall_nclients[FN_id] = 0;
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
				FN_overall_nclients[rp[FN_id][rp_id]] += FN_nclients[FN_id];
			}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_average_number_of_clients_for_each_FN(int t_, double *average_number_of_clients){
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(server_type == MMPPD1)
				average_number_of_clients[FN_id] = FN_nclients[FN_id] * (Ton / (Ton + Toff));
			else
				average_number_of_clients[FN_id] = FN_nclients[FN_id];
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_unfeasibility_for_each_FN(double *p_unfeasible_poisson){
	double p_feasible = 1;
	p_unfeasible_poisson[ROOT_FN] = 0;
	for(int FN_id = 2; FN_id <= N; FN_id++){
		double sum_of_lambda = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_lambda += ncode[file_id] * (file_allocation[file_id][FN_id]/file_allocation[file_id][0]);
		average_occupancy[FN_id] = sum_of_lambda;
		if(sum_of_lambda > 0)
			p_unfeasible_poisson[FN_id]  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);
		else
			p_unfeasible_poisson[FN_id]  = 0;
		p_feasible *= (1 - p_unfeasible_poisson[FN_id]);
	}
	return 1 - p_feasible;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_fog_nodes_state(int t_, double *average_number_of_clients, double *p_unfeasible_poisson, double *hn_mult, double *hn_pois, double *FN_delay_as_max, double *FN_meet_deadline_as_max){
//	fprintf(stdout,"\nTime %d : fog nodes status :\n---------------\n",t_);
	for(int FN_id = 1; FN_id <= N ; FN_id++)
		if(active_FN[FN_id])
			fprintf(stdout,"F %d FN %3d\tACT %c\tLVL %2d\tcap %3u\tocc %lf\tavg nclnts %lf\t overall nclnts %d\tload %lf\tservice %lf\toverload %s\tunfeas %.6lf\tmult phit %.6lf\tpoiss phit %.6lf\tdelaymax %lf\tmeet %lf\n",F,FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],average_number_of_clients[FN_id],FN_overall_nclients[FN_id],load_to_FN[FN_id],FN_service_rate[FN_id],(load_to_FN[FN_id] < FN_service_rate[FN_id])?"NO":"YES",p_unfeasible_poisson[FN_id],hn_mult[FN_id],hn_pois[FN_id],FN_delay_as_max[FN_id],FN_meet_deadline_as_max[FN_id]);
		else
			fprintf(stdout,"F %d FN %3d\tACT %c\tLVL %2d\tcap %3u\tocc %lf\tavg nclnts %lf\t overall nclnts %d\tload %lf\tservice %lf\toverload %s\tunfeas %.6lf\n",F,FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],average_number_of_clients[FN_id],FN_overall_nclients[FN_id],load_to_FN[FN_id],FN_service_rate[FN_id],(load_to_FN[FN_id] < FN_service_rate[FN_id])?"NO":"YES",p_unfeasible_poisson[FN_id]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_file_state(int t_, double *hf_mult, double *hf_pois, double *popularity){
	fprintf(stdout,"\nTime %d : file status :\n---------------\n",t_);
	for(int file_id = 0; file_id < F ; file_id++){
		fprintf(stdout,"Time %d file %d n %d k %d pop %.6lf : hit pois %.6lf hit mult %.6lf\n",t_,file_id,ncode[file_id],kcode[file_id],(popularity != NULL)?popularity[file_id]:-1,(hf_pois != NULL)?hf_pois[file_id]:-1,(hf_mult != NULL)?hf_mult[file_id]:-1);
		for(int FN_id = 2; FN_id <= N; FN_id++)
			fprintf(stdout,"Time %d ALLOC FILE %d : FN %d : WEIGHT %lf FRACTION %lf POPULARITY %lf\n",t_,file_id,FN_id, file_allocation[file_id][FN_id],file_allocation[file_id][FN_id]/file_allocation[file_id][0],file_popularity[file_id]);
		fprintf(stdout,"\n");
	}
}

#define NIGHT 0
#define MORNING 1
#define AFTERNOON 2
#define EVENING 3

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_father(int FN_id){
	int father_id = UNKNOWN;

	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int seq_no = FN_id - get_leftmost_id(l);
		int grp_no = seq_no/r;
		father_id = get_leftmost_id(l - 1) + grp_no;
	}
	return father_id;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_rp(int t_){

#ifndef VALIDATION
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_card = 1; // It shall be a function that will decide the cardinality of rp(i)

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;

			rp[FN_id][1] = FN_id;
			for(int rp_id = 2; rp_id <= rp[FN_id][0]; rp_id++){
				rp[FN_id][rp_id] = get_father(rp[FN_id][rp_id-1]);
			}
		}
	}
#endif
}
#define DELTA_WEIGHT 0.75
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_allocations(int t_, double *p_unfeasible_allocation, double *hn_pois){

#ifndef VALIDATION
	for(int file_id = 0; file_id < F; file_id++){
		int n_decreased = 0;
		int n_offload = 0;

		double weight_removed = 0;
		for(int FN_id = 2; FN_id <= N; FN_id++){
			if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0){
				weight_removed += MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				n_decreased++;
			}
		}
		if(n_decreased > 0){
			for(int FN_id = 2; FN_id <= N; FN_id++){
				if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
					n_offload++;
			}
			if(n_offload > 0){
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0)
						file_allocation[file_id][FN_id] -= MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				}
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
						file_allocation[file_id][FN_id] += weight_removed / n_offload;
				}
			}
		}
//		printf("In set_file_alloc fle %d ndec %d noffl %d remweigh %lf\n",file_id,n_decreased,n_offload,weight_removed);
	}
#ifdef DEBUG_FILE_ALLOC
	printf("Dopo set_file_alloc\n");
	print_file_state(t_, NULL, NULL, NULL);
#endif
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_popularities(int t_){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_fog_nodes_capabilities(int t_){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_mds_parameters(int t_, double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double PIE_n_mult,  double PIE_n_pois, double PIE_f_mult,  double PIE_f_pois, double unfeasibility){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_rp_state(){

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			fprintf(stdout,"rp FN %d :",FN_id);
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
				fprintf(stdout," %d",rp[FN_id][rp_id]);
			fprintf(stdout,"\n");
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_brother(int FN_id, int distance){
	int brother_id = UNKNOWN;
	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int leftmost = get_leftmost_id(l);
		int rightmost = get_rightmost_id(l);
		brother_id = leftmost + (FN_id - leftmost + distance)%(rightmost - leftmost + 1);
	}
	return brother_id;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void init_model_parameters(){

// FILE POPULARITY
	double popularity_sum = 0;
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] = file_id + 1;
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] /= popularity_sum;
//MDS-LIKE PARAMETERS
	for(int file_id = 0; file_id < F; file_id++){
		kcode[file_id] = kcode_at_0;

		// Popularity dependent redundancy
		// ncode[file_id] = ncode_at_0 + 16 * kcode_at_0 * (file_popularity[file_id]/file_popularity[F-1]);
		// Popularity dependent redundancy

//		if(file_id < 0.1 * F )
//			ncode[file_id] = 2* ncode_at_0;
//		else
			ncode[file_id] = ncode_at_0;
	}
// FILE ALLOCATION
	for(int file_id = 0; file_id < F; file_id++){
		double sum_w = 0;
		file_allocation[file_id][0] = 0;
		file_allocation[file_id][ROOT_FN] = kcode[file_id]; /* Not used to compute p_i since counter for file_id is not updated */
		for(int FN_id = 2; FN_id <= N; FN_id++){
			int l = get_FN_level(FN_id);

			// Homogeneous allocation to FN at different levels
			// Homogeneous allocation to FN at different levels

			if(file_id < F - topF)
				file_allocation[file_id][FN_id] = (L - l + 1) -  (1 - pow((double)l  / L,z)); // weights
			else
				file_allocation[file_id][FN_id] = pow( (L - l + 1) -  (1 - pow((double)l  / L,z)) , y); // weights

			// Heterogeneous allocation to FN at different levels: inverse wrt file popularity: NOT GOOD
			// file_allocation[file_id][FN_id] = (L - l + 1) * ((double)file_id / (F - 1)) + l  * (1 -(double)file_id / (F - 1)); 
			// Heterogeneous allocation to FN at different levels: inverse wrt file popularity: NOT GOOD
			

			file_allocation[file_id][0] += file_allocation[file_id][FN_id];
		}
	}
#ifdef DEBUG_FILE_ALLOC
	printf("After init\n");
	print_file_state(0, NULL, NULL, NULL);
#endif
// CLIENT POPULATION FOR FRONTIER (ACTIVE) FN
	overall_nclients = 0;
	for(int FN_id = 1; FN_id <= N;  FN_id++){
		if(active_FN[FN_id]){
			FN_nclients[FN_id] = nclients;
		// ABSLUTELY ARBITRARY!!!!
		// ABSLUTELY ARBITRARY!!!!
			if(FN_id == overloaded1 || FN_id==overloaded2)
				FN_nclients[FN_id] += extra_nclients;
		// ABSLUTELY ARBITRARY!!!!
		// ABSLUTELY ARBITRARY!!!!
		} 
		else
			FN_nclients[FN_id] = 0;
		overall_nclients += FN_nclients[FN_id];
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_depth = MAX(1,get_FN_level(FN_id)); 
			int rp_card = n_replicas * rp_depth;


			int extra_overall = extra_brothers + extra_uncles + extra_grandpas;

			rp_card += extra_overall;

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;

			int previous = FN_id;
			for(int depth = 1; depth <= rp_depth; depth++){
				for(int replica = 0; replica < n_replicas; replica++){
					rp[FN_id][ (depth - 1) * n_replicas + replica + 1] = get_brother(previous,replica);
				}
				previous = get_father(previous);
			}

			int insert_position = rp_card - extra_overall + 1;

			for(int distance = 1; distance <= extra_brothers; distance++)
				rp[FN_id][insert_position++] = get_brother(FN_id,distance);
			for(int distance = 1; distance <= extra_uncles; distance++)
				rp[FN_id][insert_position++] = get_brother(get_father(FN_id),distance);
			for(int distance = 1; distance <= extra_grandpas; distance++)
				rp[FN_id][insert_position++] = get_brother(get_father(get_father(FN_id)),distance);
		}
// It shall be the function we like: it is father relationship by now
	}
#ifdef DEBUG_RP
	print_rp_state();
#endif
	int leaf_capacity = kcode_at_0 * Fmax;
	double load_to_cloud = lambdamax * Nactive * Cmax;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) * leaf_capacity;
		FN_service_rate[FN_id] = load_to_cloud / (get_FN_level(FN_id) + 1); 
		FN_service_time[FN_id] = 1 / FN_service_rate[FN_id]; 
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void allocate_structures(){
// MDS CODING PARAMETERS
	ncode = (int *)calloc(F, sizeof(int));
	kcode = (int *)calloc(F, sizeof(int));
// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	file_popularity = (double *)calloc(F,sizeof(double));
// SET RP(i) RETURNED BY ROUTING/SEARCH ALGORITHM
	rp = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rp[FN_id] = NULL;
// RATE A FOG NODES FULLFILS REQUESTS
	FN_service_rate = (double *)calloc(N+1, sizeof(double));
	FN_service_time = (double *)calloc(N+1, sizeof(double));
	FN_overall_nclients = (int *)calloc(N+1, sizeof(int));
	FN_nclients = (int *)calloc(N+1, sizeof(int));
// FOG NODES CAPACITY
	FN_capacity =(unsigned int *)calloc(N + 1, sizeof(unsigned int));
// FOG NODES AVERAGE OCCUPANCY
	average_occupancy = (double *)calloc(N+1, sizeof(double));
// LOAD OFFERED TO A FOG NODES
	load_to_FN = (double *)calloc(N+1, sizeof(double));
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void free_structures(){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(rp[FN_id]);
	free(rp);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

	free(FN_capacity);
	free(FN_service_rate);
	free(FN_service_time);
	free(FN_overall_nclients);
	free(FN_nclients);
	free(load_to_FN);
	free(average_occupancy);
	free(file_popularity);
	free(active_FN);
	free(kcode);
	free(ncode);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double phit(int FN_id, int file_id, char model_type){
	double ph = 0;

	char root_is_in_rp = FALSE;
	for(int rp_id = 1; rp_id <= rp[FN_id][0] && !root_is_in_rp; rp_id++)
		 root_is_in_rp = (rp[FN_id][rp_id] == ROOT_FN);

	double multinomial_phit;
	double poissonized_phit;
	if(root_is_in_rp){
		ph = 1;
//		fprintf(stdout,"FN %d CONTACTS ROOT: ncode for file %d is %d phit %lf model type %s\n",FN_id,ncode[file_id],file_id,ph,(model_type==POISSON)?"POISSON":"MULTINOMIAL");
	}
	else{
		double psum = 0;
		for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
			psum += file_allocation[file_id][rp[FN_id][rp_id]]/file_allocation[file_id][0];

		if(psum > 0){
			if(model_type == POISSON)
				ph = gsl_cdf_poisson_Q(kcode[file_id] - 1, ncode[file_id] * psum);
			else
				ph = gsl_cdf_binomial_Q(kcode[file_id] - 1, psum, ncode[file_id]);
		}

//		fprintf(stdout,"FN %d psum is %lf ncode for file %d is %d phit %lf model type %s\n",FN_id,psum,ncode[file_id],file_id,ph,(model_type==POISSON)?"POISSON":"MULTINOMIAL");
	}
	return ph;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_averaged_phit( int t_, double *average_number_of_clients, double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double *PIE_n_mult, double *PIE_n_pois, double *PIE_f_mult, double *PIE_f_pois){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			hn_mult[FN_id] = hn_pois[FN_id] = 0;
	for(int file_id = 0; file_id < F; file_id++)
		hf_mult[file_id] = hf_pois[file_id] = 0;
	for(int file_id = 0; file_id < F; file_id++){
		for(int FN_id = 1; FN_id <= N ; FN_id++){
			if(active_FN[FN_id]){
				double multinomial_phit = phit(FN_id, file_id, MULTINOMIAL);
				double poisson_phit = phit(FN_id, file_id, POISSON);

				hn_mult[FN_id] += file_popularity[file_id] * multinomial_phit;
				hn_pois[FN_id] += file_popularity[file_id] * poisson_phit;
				hf_mult[file_id] += multinomial_phit;
				hf_pois[file_id] += poisson_phit;

			}
		}
		hf_mult[file_id] /= Nactive;
		hf_pois[file_id] /= Nactive;
	}
#ifdef DEBUG_ALL
	print_file_state(t_, hf_mult, hf_pois, file_popularity);
#endif
	double average_client_sum = 0;

	*PIE_n_mult = *PIE_n_pois = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			average_client_sum += average_number_of_clients[FN_id];
	if(average_client_sum > 0){
		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				*PIE_n_mult +=  (average_number_of_clients[FN_id]/average_client_sum) * hn_mult[FN_id];
				*PIE_n_pois +=  (average_number_of_clients[FN_id]/average_client_sum) * hn_pois[FN_id];
			}
		}
	}
	*PIE_f_mult = *PIE_f_pois = 0;
	for(int file_id = 0; file_id < F; file_id++){
		*PIE_f_mult += file_popularity[file_id] * hf_mult[file_id];
		*PIE_f_pois += file_popularity[file_id] * hf_pois[file_id];
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int compute_latency(double *average_number_of_clients, double *FN_delay_as_max, double *average_latency_as_max, char *unbounded_delay, double *FN_meet_deadline_as_max, double *average_meet_deadline_as_max){


	if(server_type == MMPPD1)
		build_and_solve_all_mmpp_queues(N+1 , FN_overall_nclients, FN_service_time, Ton, Toff, lambda, 0.0, load_to_FN);
	else{
		for(int FN_id = 1; FN_id <= N; FN_id++)
			load_to_FN[FN_id] = 0;

		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
					load_to_FN[rp[FN_id][rp_id]] += average_number_of_clients[FN_id] * lambda;
			}
        	}

	}

	*unbounded_delay = FALSE;
	for(int FN_id = 1; FN_id <= N ; FN_id++){
		if(active_FN[FN_id]){
			FN_delay_as_max[FN_id] = 0;
#ifdef DEBUG_LATENCY
			printf("FOR FN %d: ",FN_id);
#endif
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
				int FN_in_rp = rp[FN_id][rp_id];
				double FN_rho;
				if(FN_service_rate[FN_in_rp] > 0)
					FN_rho = load_to_FN[FN_in_rp] / FN_service_rate[FN_in_rp];
				else
					FN_rho = -1;
#ifdef DEBUG_LATENCY
				printf(" BEFORE ID %d  load %lf service %lf rho %lf",FN_in_rp,load_to_FN[FN_in_rp],FN_service_rate[FN_in_rp],FN_rho);
#endif
				if(FN_rho >= 1 - EPSILON){
#ifdef DEBUG_LATENCY
					printf(" RHO CLOSE TO 1\n",FN_in_rp,load_to_FN[FN_in_rp],FN_service_rate[FN_in_rp],FN_rho);
#endif
					FN_delay_as_max[FN_id] = UNBOUNDED;
					FN_meet_deadline_as_max[FN_id] = FALSE;
					*unbounded_delay = TRUE;
#ifndef DEBUG_LATENCY
					break;
#endif
				}
#ifdef DEBUG_LATENCY
				printf("\n");
#endif
			}
#ifdef DEBUG_LATENCY
			printf("\n");
#endif
			if (FN_delay_as_max[FN_id] != UNBOUNDED ){
				if(server_type == MMPPD1){
					int n_contacted = 0;
					for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
						n_contacted += FN_service_rate[rp[FN_id][rp_id]] > 0;
					int FN_ids[n_contacted];
					int num_of_clients[n_contacted];
					double h[n_contacted];
					for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
						int FN_in_rp = rp[FN_id][rp_id];
						FN_ids[rp_id - 1] = FN_in_rp;
						h[rp_id - 1] = FN_service_time[FN_in_rp];
						num_of_clients[rp_id - 1] = FN_overall_nclients[FN_in_rp];
					}
					FN_delay_as_max[FN_id] = compute_average_of_max_mmppd1(n_contacted , FN_ids, num_of_clients, h, Ton, Toff, lambda, 0.0);
					FN_meet_deadline_as_max[FN_id] = compute_deadline_probability_mmppd1(deadline, n_contacted , FN_ids, num_of_clients, h, Ton, Toff, lambda, 0.0);
				}
				else{
					int n_contacted = 0;
					double exponential_rate_parameter[N];
					double exponential_shift[N];
					for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
						int FN_in_rp = rp[FN_id][rp_id];
						double FN_rho;
						if(FN_service_rate[FN_in_rp] > 0){
							FN_rho = load_to_FN[FN_in_rp] / FN_service_rate[FN_in_rp];
							exponential_rate_parameter[n_contacted] = FN_service_rate[FN_in_rp] * (1 - FN_rho);
							exponential_shift[n_contacted] = 0;
							n_contacted++;
						}
					}
					FN_meet_deadline_as_max[FN_id] = compute_deadline_probability_mm1(deadline, exponential_rate_parameter, exponential_shift, n_contacted);
					FN_delay_as_max[FN_id] = compute_average_of_max_mm1(n_contacted , exponential_rate_parameter, exponential_shift);
				}
			}
		}
	}

	int ret = 0;
	double average_client_sum = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			if(FN_delay_as_max[FN_id] != UNBOUNDED){
				average_client_sum += average_number_of_clients[FN_id];
				ret++;
			}

	if(average_client_sum > 0){
		*average_latency_as_max = 0;
		*average_meet_deadline_as_max = 0;
		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				if(FN_delay_as_max[FN_id] != UNBOUNDED){
					*average_latency_as_max += (average_number_of_clients[FN_id]/average_client_sum) * FN_delay_as_max[FN_id];
					*average_meet_deadline_as_max += (average_number_of_clients[FN_id]/average_client_sum) * FN_meet_deadline_as_max[FN_id];
				}
			}
		}
	}
	else{
		*average_latency_as_max = UNBOUNDED;
		*average_meet_deadline_as_max = 0;
	}
	if(server_type == MMPPD1)
		free_all_mmpp_queues(N+1);
	return ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc < 18){
		fprintf(stdout,"usage : %s L r n k F nclients lambda Ton Toff maxT Fmax Cmax lambdamax deadline n_replicas service nthreads z_allocation extrab extrau extragp extracl ovld1 ovld2 topF\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode_at_0 = atoi(argv[3]);
	kcode_at_0 = atoi(argv[4]);
	F = atoi(argv[5]);

	nclients = atoi(argv[6]);
	lambda = atof(argv[7]);
	Ton = atof(argv[8]);
	Toff = atof(argv[9]);

	max_time = atoi(argv[10]);
	Fmax = atoi(argv[11]);
	Cmax = atoi(argv[12]);
	lambdamax = atof(argv[13]);
	deadline = atof(argv[14]);
	n_replicas = atoi(argv[15]);

	if(strcmp(argv[16],"m/m/1")==0)
		server_type = MM1;
	else
		server_type = MMPPD1;

	nthreads = atoi(argv[17]);
	if(argc > 18)
		z = atof(argv[18]);

	extra_brothers = atoi(argv[19]);
	extra_uncles = atoi(argv[20]);
	extra_grandpas = atoi(argv[21]);
	extra_nclients = atoi(argv[22]);
	overloaded1 = atoi(argv[23]);
	overloaded2 = atoi(argv[24]);
	topF = atoi(argv[25]);

	if(overloaded1 == overloaded2){
		fprintf(stdout,"Overloaded active FNs must be distinct!\n");
		exit(EXIT_FAILURE);
	}

	N = (pow(r,L+1) - 1)/(r - 1);

// DETERMINE WHICH FN CAN ISSUE REQUESTS
	active_FN = (char *)calloc(N + 1, sizeof(char));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(get_FN_level(FN_id) == L){
		       active_FN[FN_id] = TRUE;
		       Nactive++;
		}
		else	
		       active_FN[FN_id] = FALSE;
	}
// CALL TO THIS FUNCTION MUST *FOLLOW* ABOVE LOOP!!!
	allocate_structures();

	double average_number_of_clients[N + 1];
	double p_unfeasible_poisson[N + 1];

	double hn_mult[N + 1];
	double hn_pois[N + 1];
	double hf_mult[F];
	double hf_pois[F];

	double average_unfeasibility[L+1];
	double average_storage_utilization[L+1];
	double average_load_factor[L+1];

	double average_rho = 0;
	double average_utilization = 0;
	double MAXF;
	char at_least_one_unfeasible[L+1];
	char at_least_one_overloaded[L+1];
	int n_FN_per_level[L+1];

	double FN_delay_as_max[N + 1];

	double FN_meet_deadline_as_max[N + 1];

	double PIE_n_mult = 0;
	double PIE_n_pois = 0;
	double PIE_f_mult = 0;
	double PIE_f_pois = 0;
	double unfeasibility = 0;
	double average_latency_as_max = 0;
	double average_meet_deadline_as_max = 0;
	char unbounded_delay;

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
	init_model_parameters();
	for( int t_ = 1; t_ <= max_time; t_++){/* For each time step */


		// To be computed beforehand: it is necessary for average phit!!
		compute_average_number_of_clients_for_each_FN(t_ - 1, average_number_of_clients);

		// phit computation
		compute_averaged_phit(t_, average_number_of_clients, hn_mult, hn_pois, hf_mult, hf_pois, &PIE_n_mult, &PIE_n_pois, &PIE_f_mult, &PIE_f_pois);

		// Computation of derived quantities to obtain latency
		compute_FN_overall_nclients();

		// latency computation
		int naveraged = compute_latency(average_number_of_clients, FN_delay_as_max, &average_latency_as_max, &unbounded_delay, FN_meet_deadline_as_max, &average_meet_deadline_as_max);

		// feasibility computation
		unfeasibility = compute_unfeasibility_for_each_FN(p_unfeasible_poisson);

		for(int l = 0; l <= L; l++)
			average_unfeasibility[l] = average_storage_utilization[l] = average_load_factor[l] = at_least_one_unfeasible[l] = at_least_one_overloaded[l] = n_FN_per_level[l] = 0;
		for(int FN_id = 1; FN_id <= N ; FN_id++){
			int FN_level = get_FN_level(FN_id);

			average_unfeasibility[FN_level] += p_unfeasible_poisson[FN_id];
			average_storage_utilization[FN_level] += average_occupancy[FN_id] / FN_capacity[FN_id];
			average_load_factor[FN_level] += load_to_FN[FN_id] / FN_service_rate[FN_id];
			at_least_one_unfeasible[FN_level] |= (p_unfeasible_poisson[FN_id] > 0.999);
			at_least_one_overloaded[FN_level] |= (load_to_FN[FN_id] >= FN_service_rate[FN_id]);
			n_FN_per_level[FN_level]++;
			if(FN_id != ROOT_FN){
				average_rho += load_to_FN[FN_id] / FN_service_rate[FN_id];
				average_utilization += average_occupancy[FN_id] / FN_capacity[FN_id];
				MAXF +=  FN_capacity[FN_id];
			}
		}
		for(int l = 0; l <= L; l++){
			average_unfeasibility[l] /= n_FN_per_level[l];
			average_storage_utilization[l] /= n_FN_per_level[l];
			average_load_factor[l] /= n_FN_per_level[l];
		}
		average_rho /= (N - 1);
		average_utilization /= (N - 1);
		MAXF /=  ncode_at_0;

#ifdef DEBUG_ALL
     		print_fog_nodes_state(t_,average_number_of_clients,p_unfeasible_poisson,hn_mult,hn_pois,FN_delay_as_max,FN_meet_deadline_as_max);
#endif
//		for(int l = 0; l <= L; l++){
//			fprintf(stdout,"%c n %d F %d Time %d : PIE_n (mult) %lf PIE_n (pois) %lf PIE_f (mult) %lf PIE_f (pois) %lf unfeasibility %lf latency (max) %lf on %d unbounded %s meet %lf",(unfeasibility > UNFEASIBILITY_THRESHOLD)?'O':'U',ncode_at_0,F,t_,PIE_n_mult,PIE_n_pois,PIE_f_mult,PIE_f_pois,unfeasibility,average_latency_as_max,naveraged,(unbounded_delay)?"YES":"NO",average_meet_deadline_as_max);
//			fprintf(stdout," : l %d av unfeas %lf av util %lf av rho %lf 1 unfeas %s 1 overld %s",l,average_unfeasibility[l],average_storage_utilization[l],average_load_factor[l],(at_least_one_unfeasible[l])?"yes":"no",(at_least_one_overloaded[l])?"yes":"no");
//			fprintf(stdout,"\n");
//		}
		fprintf(stdout,"TOPF %d CL %d O1 %d O2 %d B %d U %d G %d %c n %d F %d FMAX %lf ( %lf ) t %d : avrho %lf : avutil %lf PIE_n (mult) %lf PIE_n (pois) %lf PIE_f (mult) %lf PIE_f (pois) %lf unfeas %lf latency %lf on %d unbounded %s Pmeet %lf\n",topF,overall_nclients,overloaded1,overloaded2,extra_brothers, extra_uncles, extra_grandpas,(unfeasibility > UNFEASIBILITY_THRESHOLD)?'O':'U',ncode_at_0,F,MAXF,F/MAXF,t_,average_rho,average_utilization,PIE_n_mult,PIE_n_pois,PIE_f_mult,PIE_f_pois,unfeasibility,average_latency_as_max,naveraged,(unbounded_delay)?"YES":"NO",average_meet_deadline_as_max);

		return (unfeasibility > UNFEASIBILITY_THRESHOLD)?EXIT_FAILURE:EXIT_SUCCESS;

		////////////////////////////////////
		// Time dependent parameter settings
		////////////////////////////////////
		
		//DOES NOT
		set_mds_parameters(t_, hn_mult, hn_pois, hf_mult, hf_pois, PIE_n_mult, PIE_n_pois, PIE_f_mult, PIE_f_pois, unfeasibility);
		//DOES NOT
		set_rp(t_);
		//DOES 
		set_file_allocations(t_, p_unfeasible_poisson, hn_pois);
		//DOES NOT
		set_file_popularities(t_);
		//DOES NOT
		set_fog_nodes_capabilities(t_);
	}

	free_structures();

	return EXIT_SUCCESS;
}
