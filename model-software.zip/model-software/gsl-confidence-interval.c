#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <gsl/gsl_histogram.h>
#include <gsl/gsl_statistics.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>
#include <gsl/gsl_sort.h>

#define MAX_DATA 1000000001

int main (int argc, char **argv){
//	double a, b;
	double *data = (double *)calloc(MAX_DATA,sizeof(double));
	size_t n_data = 0;
//	size_t n_bins;
	double alfa;


	if (argc != 2){
		//printf("Usage: gsl-ci xmin xmax nbins alfa-ci(0.90, 0.95, 0.99, ....)\n" "Computes a histogram of the data " "on stdin using nbins bins from xmin " "to xmax and compute ci\n");
		printf("Usage: gsl-ci alfa-ci(0.90, 0.95, 0.99, ....)\n" "Computes a histogram of the data " "on stdin using nbins bins from xmin " "to xmax and compute ci\n");
		exit(EXIT_FAILURE);
	}

//	a = atof(argv[1]);
//	b = atof(argv[2]);
//	n_bins = atoi(argv[3]);
	alfa = atof(argv[1]);

	{
	double x;
//	gsl_histogram * h = gsl_histogram_alloc (n_bins);
//	gsl_histogram_set_ranges_uniform (h, a, b);
	while (fscanf (stdin, "%lg", &x) == 1){
//		gsl_histogram_increment (h, x);
		data[n_data++] = x;
		if(n_data == MAX_DATA){
			fprintf(stdout,"Too many samples: increase MAX_DATA in gsl-histogram.c, recompile and rerun\n");
			exit(EXIT_FAILURE);
		}
	}
//	gsl_histogram_fprintf (stdout, h, "%g", "%g");
//	gsl_histogram_free (h);

	double mean, variance, sd, skew, kurtosis, largest, smallest, lower_ci, upper_ci;
	size_t stride = 1;

	mean     = gsl_stats_mean(data, stride, n_data);
	variance = gsl_stats_variance(data, stride, n_data);
	sd       = gsl_stats_sd(data, stride, n_data);
	skew     = gsl_stats_skew(data, stride, n_data);
	kurtosis = gsl_stats_kurtosis(data, stride, n_data);
	largest  = gsl_stats_max(data, stride, n_data);
	smallest = gsl_stats_min(data, stride, n_data);

	double median, upperq, lowerq;

	gsl_sort (data, stride, n_data);

	median = gsl_stats_median_from_sorted_data (data, stride, n_data);
	upperq = gsl_stats_quantile_from_sorted_data (data, stride, n_data, 0.75);
	lowerq = gsl_stats_quantile_from_sorted_data (data, stride, n_data, 0.25);

	double t = gsl_cdf_tdist_Pinv(alfa + (1 - alfa)/2.0, n_data - 1);

	lower_ci = mean - t * sd / sqrt(n_data);
	upper_ci = mean + t * sd / sqrt(n_data);

	fprintf(stdout,"\tmean\t[low-ci,up-ci]\tsd\tskew\tkurtosis\tlargest\tsmallest\tmedian\tupperquartile\tlowerquartile\tres\t#samples\n");
	fprintf(stdout,"\t%lf\t[%lf,%lf]\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\t%lf\tres\t%u\n",mean, lower_ci, upper_ci, sd, skew, kurtosis, largest, smallest, median, upperq, lowerq, n_data);

/*	
	printf ("The sample mean is %g\n", mean);
	printf ("The estimated standard deviation is %g\n", sd);
	printf ("The estimated skew is %g\n", skew);
	printf ("The estimated kurtosis is %g\n", kurtosis);
//	printf ("The estimated variance is %g\n", variance);
	printf ("The largest value is %g\n", largest);
	printf ("The smallest value is %g\n", smallest);
	printf ("The median is %g\n", median);
	printf ("The upper quartile is %g\n", upperq);
	printf ("The lower quartile is %g\n", lowerq);
*/	
	}
	free(data);
	exit(EXIT_SUCCESS);
}
