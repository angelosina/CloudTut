#define VALIDATION
//#define OUT 
#define TRUE 1
#define FALSE 0
#define ROOT_FN 1
//#define EPSILON 1e-4
#define UNFEASIBILITY_THRESHOLD 1e-6
#define UNKNOWN -1

#define POISSON 0
#define MULTINOMIAL 1

//#define DELTA_WEIGHT 0.75

//#define DEBUG_ALL

#ifndef DEBUG_ALL
//#define DEBUG_LOAD
//#define DEBUG_FILE_ALLOC
//#define DEBUG_RP
//#define DEBUG_LATENCY
#endif
