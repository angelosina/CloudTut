#include <stdio.h>
#include <stdlib.h>

//#define DEBUG

void row_matrix_product(double *result, double *row_vector, double **square_matrix, int size, int FN_id){
	for(int column = 0; column < size; column++){
		double sum = 0;
		for(int row = 0; row < size; row++)
			sum += row_vector[row] * square_matrix[row][column];
		result[column] = sum;
	}
#ifdef DEBUG
	if(FN_id == 5000){
	 	fprintf(stdout,"Multiply: [ %.6lf",row_vector[0]);
 		for(int column = 1; column < size; column++)
 			fprintf(stdout," , %.6lf",row_vector[column]);
 		fprintf(stdout,"] by \n");
 		for(int row = 0; row < size; row++){
 			for(int column = 0; column < size; column++)
 				fprintf(stdout," %.6lf ",square_matrix[row][column]);
 			fprintf(stdout,"\n");
 		}
 		fprintf(stdout,"Results: [ %.6lf",result[0]);
 		for(int column = 1; column < size; column++)
 			fprintf(stdout," , %.6lf",result[column]);
 		fprintf(stdout,"]\n\n");
	}
#endif
}
