#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <float.h>
#include <gsl/gsl_randist.h>
#include <gsl/gsl_cdf.h>

#define VALIDATION
//#define OUT 
#define UNBOUNDED -1
#define TRUE 1
#define FALSE 0
#define ROOT_FN 1
#define EPSILON 1e-4
#define UNFEASIBILITY_THRESHOLD 0.0001
#define UNKNOWN -1

#define POISSON 0
#define MULTINOMIAL 1

//#define DEBUG_ALL

#ifndef DEBUG_ALL
//#define DEBUG_LOAD
//#define DEBUG_FILE_ALLOC
#define DEBUG_RP
//#define DEBUG_LATENCY
#endif

#define PART_OF_DAY(t) (t%24)/6

int L = 0;
int r = 0;
int ncode_at_0 = 0;
int kcode_at_0 = 0;
int *ncode = NULL;
int *kcode = NULL;
int F = 0;
int nclients = 0;
int N = 0;
int max_time = 0;
double lambda = 0;
int Nactive = 0;
int n_replicas = 0;
int Cmax = 0;
int Fmax = 0;
double lambdamax = 0;
double deadline = 0;



double *p = NULL;
char *active_FN = NULL;

unsigned int *FN_capacity = NULL;
double *FN_service_rate = NULL;
double *load_to_FN = NULL;
double *average_occupancy = NULL;

double *client_request_rate = NULL;
double *file_popularity = NULL;
double **file_allocation = NULL;
int **rp = NULL;
double ***mobility_pie = NULL;
double ***mobility_transition_probabilities = NULL;

extern double Pcumulative_sum_of_binomials(int , int , int , double *);
extern void row_matrix_product(double *, double *, double **, int, int );
extern double compute_average_of_max(int , double *, double *);
extern double compute_deadline_probability(double, double *, double *, int );

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double MIN(double a, double b){
	return(a < b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int MAX(int a, int b){
	return(a > b)?a:b;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_FN_level(int FN_id){
	int base = 0;
	int level = 0;
	for(; level <= L; ){
		int n_level = pow(r,level);
		if(FN_id > base && FN_id <= base + n_level)
			break;
		base += n_level;
		level++;
	}
	return level;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_leftmost_id(int level){
	int leftmost_FN = 1;

	for(int l = 0; l < level ; l++){
		if(l == level - 1){
			leftmost_FN++;
			break;
		}
		leftmost_FN += pow(r,l+1);
	}
	return leftmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_rightmost_id(int level){
	int rightmost_FN = 1;

	for(int l = 0; l < level ; l++){
		rightmost_FN += pow(r,l+1);
	}
	return rightmost_FN;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_overall_load_to_each_FN(double *average_number_of_clients){

	for(int FN_id = 1; FN_id <= N; FN_id++)
		load_to_FN[FN_id] = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
				load_to_FN[rp[FN_id][rp_id]] += average_number_of_clients[FN_id] * client_request_rate[FN_id];
			}
		}
	}
//#ifdef VALIDATION
//	for(int FN_id = 1; FN_id <= N; FN_id++)
//		FN_service_rate[FN_id] = 1.1 * load_to_FN[FN_id];
//#endif
#ifdef DEBUG_LOAD
	for(int FN_id = 1; FN_id <= N; FN_id++){
		fprintf(stdout,"LOAD TO %d: %lf\t SERVICE RATE %lf\t RHO %lf\n",FN_id,load_to_FN[FN_id],FN_service_rate[FN_id],load_to_FN[FN_id]/FN_service_rate[FN_id]);
	}
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_average_number_of_clients_for_each_FN(int t_, double *average_number_of_clients){
	int T = t_ % 2; 
	int Tp1 = (t_ + 1) % 2;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			double sum = 0;
			for(int nc = 0; nc <= nclients; nc++){
				sum += (nc * mobility_pie[FN_id][T][nc]);
//				fprintf(stdout,"mobility_pie(%d) = %lf : ",nc,mobility_pie[FN_id][T][nc]);
			}
//			fprintf(stdout,"\n");
			average_number_of_clients[FN_id] = sum;
//			fprintf(stdout,"average in %d : %lf\n",FN_id,average_number_of_clients[FN_id]);
//		}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double compute_unfeasibility_for_each_FN(double *p_unfeasible_poisson){
	double p_feasible = 1;
	p_unfeasible_poisson[ROOT_FN] = 0;
	for(int FN_id = 2; FN_id <= N; FN_id++){
		double sum_of_lambda = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_lambda += ncode[file_id] * (file_allocation[file_id][FN_id]/file_allocation[file_id][0]);
		average_occupancy[FN_id] = sum_of_lambda;
		if(sum_of_lambda > 0)
			p_unfeasible_poisson[FN_id]  = gsl_cdf_poisson_Q(FN_capacity[FN_id],sum_of_lambda);
		else
			p_unfeasible_poisson[FN_id]  = 0;
		p_feasible *= (1 - p_unfeasible_poisson[FN_id]);
	}
	return 1 - p_feasible;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_fog_nodes_state(int t_, double *average_number_of_clients, double *p_unfeasible_poisson, double *hn_mult, double *hn_pois, double *FN_delay_as_sum, double *FN_delay_as_max, double *FN_meet_deadline_as_max){
	fprintf(stdout,"\nTime %d : fog nodes status :\n---------------\n",t_);
	for(int FN_id = 1; FN_id <= N ; FN_id++)
		if(active_FN[FN_id])
			fprintf(stdout,"FN %3d ACT %c LVL %2d cap %3u occ %5.2lf nclnts %5.2lf\tload %5.2lf\tservice %5.2lf\toverload %s\tunfeas %.6lf\tmult phit %.6lf\tpoiss phit %.6lf delysum %lf delaymax %lf meet %lf\n",FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],average_number_of_clients[FN_id],load_to_FN[FN_id],FN_service_rate[FN_id],(load_to_FN[FN_id] < FN_service_rate[FN_id])?"NO":"YES",p_unfeasible_poisson[FN_id],hn_mult[FN_id],hn_pois[FN_id],FN_delay_as_sum[FN_id],FN_delay_as_max[FN_id],FN_meet_deadline_as_max[FN_id]);
		else
			fprintf(stdout,"FN %3d ACT %c LVL %2d cap %3u occ %5.2lf nclnts %5.2lf\tload %5.2lf\tservice %5.2lf\toverload %s\tunfeas %.6lf\n",FN_id,(active_FN[FN_id]==TRUE)?'Y':'N',get_FN_level(FN_id),FN_capacity[FN_id],average_occupancy[FN_id],average_number_of_clients[FN_id],load_to_FN[FN_id],FN_service_rate[FN_id],(load_to_FN[FN_id] < FN_service_rate[FN_id])?"NO":"YES",p_unfeasible_poisson[FN_id]);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_file_state(int t_, double *hf_mult, double *hf_pois, double *popularity){
	fprintf(stdout,"\nTime %d : file status :\n---------------\n",t_);
	for(int file_id = 0; file_id < F ; file_id++){
		fprintf(stdout,"Time %d file %d n %d k %d pop %.6lf : hit pois %.6lf hit mult %.6lf\n",t_,file_id,ncode[file_id],kcode[file_id],(popularity != NULL)?popularity[file_id]:-1,(hf_pois != NULL)?hf_pois[file_id]:-1,(hf_mult != NULL)?hf_mult[file_id]:-1);
		for(int FN_id = 2; FN_id <= N; FN_id++)
			fprintf(stdout,"Time %d ALLOC FILE %d : FN %d : WEIGHT %lf FRACTION %lf\n",t_,file_id,FN_id, file_allocation[file_id][FN_id],file_allocation[file_id][FN_id]/file_allocation[file_id][0]);
		fprintf(stdout,"\n");
	}
}

#define NIGHT 0
#define MORNING 1
#define AFTERNOON 2
#define EVENING 3

/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_transition_matrix(int t_){

	int T = (t_ - 1) % 2; 
	int Tp1 = t_ % 2;

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int row = 0; row <= nclients; row++){
				double row_sum = 0;
				for(int column = 0; column <= nclients; column++){
#ifdef VALIDATION
					if(column == row + 1 || column == row - 1)
						mobility_transition_probabilities[FN_id][row][column] = 0.5;
					else
						mobility_transition_probabilities[FN_id][row][column] = 0;
#else
					int daytime_range = PART_OF_DAY(t_);
					switch(daytime_range){
						case NIGHT:
								mobility_transition_probabilities[FN_id][row][column] = nclients - column ;
								break;
						case MORNING:
								mobility_transition_probabilities[FN_id][row][column] = column ;
								break;
							case AFTERNOON:
								mobility_transition_probabilities[FN_id][row][column] = row + 1;
								break;
						case EVENING:
								mobility_transition_probabilities[FN_id][row][column] = nclients - column ;
								break;
						default: 
								fprintf(stdout,"Hey this should not happen!\n");
								break;
					}
#endif
					row_sum += mobility_transition_probabilities[FN_id][row][column];
				}
				for(int column = 0; column <= nclients; column++)
					mobility_transition_probabilities[FN_id][row][column] /= row_sum;
			}
		}
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			row_matrix_product(mobility_pie[FN_id][Tp1], mobility_pie[FN_id][T], mobility_transition_probabilities[FN_id], nclients + 1, FN_id );
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_father(int FN_id){
	int father_id = UNKNOWN;

	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int seq_no = FN_id - get_leftmost_id(l);
		int grp_no = seq_no/r;
		father_id = get_leftmost_id(l - 1) + grp_no;
	}
	return father_id;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_rp(int t_){

#ifndef VALIDATION
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_card = 1; // It shall be a function that will decide the cardinality of rp(i)

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;

			rp[FN_id][1] = FN_id;
			for(int rp_id = 2; rp_id <= rp[FN_id][0]; rp_id++){
				rp[FN_id][rp_id] = get_father(rp[FN_id][rp_id-1]);
			}
		}
	}
#endif
}
#define DELTA_WEIGHT 0.75
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_allocations(int t_, double *p_unfeasible_allocation, double *hn_pois){

#ifndef VALIDATION
	for(int file_id = 0; file_id < F; file_id++){
		int n_decreased = 0;
		int n_offload = 0;

		double weight_removed = 0;
		for(int FN_id = 2; FN_id <= N; FN_id++){
			if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0){
				weight_removed += MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				n_decreased++;
			}
		}
		if(n_decreased > 0){
			for(int FN_id = 2; FN_id <= N; FN_id++){
				if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
					n_offload++;
			}
			if(n_offload > 0){
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] >= UNFEASIBILITY_THRESHOLD && file_allocation[file_id][FN_id] > 0)
						file_allocation[file_id][FN_id] -= MIN(DELTA_WEIGHT, file_allocation[file_id][FN_id]);
				}
				for(int FN_id = 2; FN_id <= N; FN_id++){
					if(p_unfeasible_allocation[FN_id] < UNFEASIBILITY_THRESHOLD)
						file_allocation[file_id][FN_id] += weight_removed / n_offload;
				}
			}
		}
//		printf("In set_file_alloc fle %d ndec %d noffl %d remweigh %lf\n",file_id,n_decreased,n_offload,weight_removed);
	}
#ifdef DEBUG_FILE_ALLOC
	printf("Dopo set_file_alloc\n");
	print_file_state(t_, NULL, NULL, NULL);
#endif
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_file_popularities(int t_){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_client_request_rates(int t_){

#ifndef VALIDATION
	int daytime_range = PART_OF_DAY(t_);
	for(int FN_id = 1; FN_id <= N;  FN_id++){
		if(active_FN[FN_id]){
			switch(daytime_range){
				case NIGHT:
					client_request_rate[FN_id] = lambda;
					break;
				case MORNING:
					client_request_rate[FN_id] = lambda*2.5;
					break;
				case AFTERNOON:
					client_request_rate[FN_id] = lambda*1.25;
					break;
				case EVENING:
					client_request_rate[FN_id] = lambda;
					break;
				default: 
					fprintf(stdout,"Hey this should not happen!\n");
					break;
			}
			if(FN_id%2)
				client_request_rate[FN_id] *= 2;
		}
	}
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_fog_nodes_capabilities(int t_){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void set_mds_parameters(int t_, double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double H_mult,  double H_pois, double unfeasibility){

	{/* Time dependency */
	}/* Time dependency */
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void print_rp_state(){

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			fprintf(stdout,"rp FN %d :",FN_id);
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
				fprintf(stdout," %d",rp[FN_id][rp_id]);
			fprintf(stdout,"\n");
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int get_brother(int FN_id, int distance){
	int brother_id = UNKNOWN;
	if(FN_id != ROOT_FN){
		int l = get_FN_level(FN_id);
		int leftmost = get_leftmost_id(l);
		int rightmost = get_rightmost_id(l);
		brother_id = leftmost + (FN_id - leftmost + distance)%(rightmost - leftmost + 1);
	}
	return brother_id;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void init_model_parameters(){

// FILE POPULARITY
#ifdef VALIDATION
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] = (2 * (double)(file_id + 1))/(F*(F+1));
#else
	double popularity_sum = 0;
	for(int file_id = 0; file_id < F; file_id++){
		file_popularity[file_id] = file_id + 1;
		popularity_sum += file_popularity[file_id];
	}
	for(int file_id = 0; file_id < F; file_id++)
		file_popularity[file_id] /= popularity_sum;
#endif
//MDS-LIKE PARAMETERS
#ifdef VALIDATION
	for(int file_id = 0; file_id < F; file_id++){
		kcode[file_id] = kcode_at_0;
		ncode[file_id] = ncode_at_0;
	}
#else
	for(int file_id = 0; file_id < F; file_id++){
		kcode[file_id] = kcode_at_0;
		ncode[file_id] = kcode_at_0;
	}
#endif

// FILE ALLOCATION
#ifdef VALIDATION
	for(int file_id = 0; file_id < F; file_id++){
		double sum_w = 0;
		file_allocation[file_id][0] = 0;
		file_allocation[file_id][ROOT_FN] = kcode[file_id];
		for(int FN_id = 2; FN_id <= N; FN_id++){
			int l = get_FN_level(FN_id);
//			if(l < L)
				file_allocation[file_id][FN_id] = L - l + 1; // weights
//			else
//				file_allocation[file_id][FN_id] = 0.25; // weights
			file_allocation[file_id][0] += file_allocation[file_id][FN_id];
		}
	}
#else
	for(int file_id = 0; file_id < F; file_id++){
		double sum_w = 0;
		file_allocation[file_id][ROOT_FN] = kcode[file_id];
		for(int FN_id = 2; FN_id <= N; FN_id++){
			int l = get_FN_level(FN_id);
			file_allocation[file_id][FN_id] = L - l + 1; // weights
			file_allocation[file_id][0] += file_allocation[file_id][FN_id];
		}
	}
#endif
#ifdef DEBUG_FILE_ALLOC
	printf("After init\n");
	print_file_state(0, NULL, NULL, NULL);
#endif

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= nclients; nc++)
				mobility_pie[FN_id][0][nc] = 0;
//			mobility_pie[FN_id][0][FN_id%(nclients+1)] = 1;
			mobility_pie[FN_id][0][nclients/2] = 1;
		}
	}

	for(int FN_id = 1; FN_id <= N;  FN_id++){
		if(active_FN[FN_id])
			client_request_rate[FN_id] = lambda;
		else
			client_request_rate[FN_id] = 0;
	}

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			if(rp[FN_id] != NULL)
				free(rp[FN_id]);
			int rp_depth = MAX(1,get_FN_level(FN_id)); 
			int rp_card = n_replicas * rp_depth;

			rp[FN_id] = (int *)calloc(rp_card + 1, sizeof(int));
			rp[FN_id][0] = rp_card;


			int previous = FN_id;
			for(int depth = 1; depth <= rp_depth; depth++){
				for(int replica = 0; replica < n_replicas; replica++){
					rp[FN_id][ (depth - 1) * n_replicas + replica + 1] = get_brother(previous,replica);
				}
				previous = get_father(previous);
			}
		}
// It shall be the function we like: it is father relationship by now
	}
#ifdef DEBUG_RP
	print_rp_state();
#endif
#ifdef VALIDATION
/*	int sumweights = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		sumweights += (L - get_FN_level(FN_id) + 1);
	int leaf_capacity = 1.2 * (ncode_at_0 * F / sumweights);
*/
	int leaf_capacity = kcode_at_0 * Fmax;
	double load_to_cloud = lambdamax * Nactive * Cmax;
	for(int FN_id = 1; FN_id <= N; FN_id++){
		FN_capacity[FN_id] = (L - get_FN_level(FN_id) + 1) * leaf_capacity;
		FN_service_rate[FN_id] = load_to_cloud / (get_FN_level(FN_id) + 1); 
	}
#else
	for(int FN_id = 1; FN_id <= N; FN_id++){
		FN_service_rate[FN_id] = (Nactive * Cmax) / (get_FN_level(FN_id) + 1); 
		int sum_of_k = 0;
		for(int file_id = 0; file_id < F; file_id++)
			sum_of_k += kcode[file_id];
		FN_capacity[FN_id] = (Fmax * sum_of_k) / (get_FN_level(FN_id) + 1) ; 
	}
#endif
//// RISING UP INITIAL REDUNDANCY (NOT FOR VALIDATION!!!)
//// RISING UP INITIAL REDUNDANCY (NOT FOR VALIDATION!!!)
//// RISING UP INITIAL REDUNDANCY (NOT FOR VALIDATION!!!)
#ifndef VALIDATION
	double dummy_unfeasible_poisson[N + 1];
	while (compute_unfeasibility_for_each_FN(dummy_unfeasible_poisson) < 100 * UNFEASIBILITY_THRESHOLD){
		for(int file_id = 0; file_id < F; file_id++)
			ncode[file_id]++;
	}
#endif
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void allocate_structures(){
// MDS CODING PARAMETERS
	ncode = (int *)calloc(F, sizeof(int));
	kcode = (int *)calloc(F, sizeof(int));
// FILE ALLOCATIONS, p's VECTORS
	file_allocation = (double **)calloc(F, sizeof(double *));
	for(int file_id = 0; file_id < F; file_id++){
		file_allocation[file_id] = (double *)calloc(N + 1,sizeof(double));
	}
// FILE POPULARITY, USED TO COMPUTE PROBABILITY OF REQUEST
	file_popularity = (double *)calloc(F,sizeof(double));
// SET RP(i) RETURNED BY ROUTING/SEARCH ALGORITHM
	rp = (int **)calloc(N + 1, sizeof(int *));
	for(int FN_id = 1; FN_id <= N; FN_id++)
		rp[FN_id] = NULL;
// RATE A CLIENT INSISTING ON FOG NODE FN_id ISSUES A REQUEST 
	client_request_rate = (double *)calloc(N+1, sizeof(double));
// RATE A FOG NODES FULLFILS REQUESTS
	FN_service_rate = (double *)calloc(N+1, sizeof(double));
// FOG NODES CAPACITY
	FN_capacity =(unsigned int *)calloc(N + 1, sizeof(unsigned int));
// FOG NODES AVERAGE OCCUPANCY
	average_occupancy = (double *)calloc(N+1, sizeof(double));
// LOAD OFFERED TO A FOG NODES
	load_to_FN = (double *)calloc(N+1, sizeof(double));
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_pie = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id])
			mobility_pie[FN_id] = (double **)calloc(2,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			mobility_pie[FN_id][0] = (double *)calloc(nclients + 1,sizeof(double));
			mobility_pie[FN_id][1] = (double *)calloc(nclients + 1,sizeof(double));
		}
	}
// PROBABILITY VECTOR FOR DISTRIBUTION OF CLIENTS INSISTING ON FOG NODES
	mobility_transition_probabilities = (double ***)calloc(N + 1, sizeof(double **));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id])
			mobility_transition_probabilities[FN_id] = (double **)calloc(nclients + 1,sizeof(double *));
	}
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= nclients; nc++)
				mobility_transition_probabilities[FN_id][nc] = (double *)calloc(nclients + 1,sizeof(double));
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void free_structures(){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(rp[FN_id]);
	free(rp);
	for(int file_id = 0; file_id < F; file_id++)
		free(file_allocation[file_id]);
	free(file_allocation);

	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(active_FN[FN_id]){
			free(mobility_pie[FN_id][0]);
			free(mobility_pie[FN_id][1]);
		}
	}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			free(mobility_pie[FN_id]);
	free(mobility_pie);

	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id]){
			for(int nc = 0; nc <= nclients; nc++)
				free(mobility_transition_probabilities[FN_id][nc]);
		}
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id]){
			free(mobility_transition_probabilities[FN_id]);
		}
	free(mobility_transition_probabilities);

	free(FN_capacity);
	free(FN_service_rate);
	free(load_to_FN);
	free(average_occupancy);
	free(client_request_rate);
	free(file_popularity);
	free(active_FN);
	free(kcode);
	free(ncode);
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
double phit(int FN_id, int file_id, char model_type){
	double ph = 0;

	char root_is_in_rp = FALSE;
	for(int rp_id = 1; rp_id <= rp[FN_id][0] && !root_is_in_rp; rp_id++)
		 root_is_in_rp = (rp[FN_id][rp_id] == ROOT_FN);

	double multinomial_phit;
	double poissonized_phit;
	if(root_is_in_rp){
		ph = 1;
//		fprintf(stdout,"FN %d CONTACTS ROOT: ncode for file %d is %d phit %lf model type %s\n",FN_id,ncode[file_id],file_id,ph,(model_type==POISSON)?"POISSON":"MULTINOMIAL");
	}
	else{
		double psum = 0;
		for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++)
			psum += file_allocation[file_id][rp[FN_id][rp_id]]/file_allocation[file_id][0];

		if(psum > 0){
			if(model_type == POISSON)
				ph = gsl_cdf_poisson_Q(kcode[file_id] - 1, ncode[file_id] * psum);
			else
				ph = gsl_cdf_binomial_Q(kcode[file_id] - 1, psum, ncode[file_id]);
		}

//		fprintf(stdout,"FN %d psum is %lf ncode for file %d is %d phit %lf model type %s\n",FN_id,psum,ncode[file_id],file_id,ph,(model_type==POISSON)?"POISSON":"MULTINOMIAL");
	}
	return ph;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
void compute_averaged_phit( int t_, double *average_number_of_clients, double *hn_mult, double *hn_pois, double *hf_mult, double *hf_pois, double *H_mult, double *H_pois){
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			hn_mult[FN_id] = hn_pois[FN_id] = 0;
	for(int file_id = 0; file_id < F; file_id++)
		hf_mult[file_id] = hf_pois[file_id] = 0;
	for(int file_id = 0; file_id < F; file_id++){
		for(int FN_id = 1; FN_id <= N ; FN_id++){
			if(active_FN[FN_id]){
				double multinomial_phit = phit(FN_id, file_id, MULTINOMIAL);
				double poisson_phit = phit(FN_id, file_id, POISSON);

				hn_mult[FN_id] += file_popularity[file_id] * multinomial_phit;
				hn_pois[FN_id] += file_popularity[file_id] * poisson_phit;
				hf_mult[file_id] += multinomial_phit;
				hf_pois[file_id] += poisson_phit;

			}
		}
		hf_mult[file_id] /= Nactive;
		hf_pois[file_id] /= Nactive;
	}
#ifdef DEBUG_ALL
	print_file_state(t_, hf_mult, hf_pois, file_popularity);
#endif
	double average_client_sum = 0;

	*H_mult = *H_pois = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			average_client_sum += average_number_of_clients[FN_id];
	if(average_client_sum > 0){
		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				*H_mult +=  (average_number_of_clients[FN_id]/average_client_sum) * hn_mult[FN_id];
				*H_pois +=  (average_number_of_clients[FN_id]/average_client_sum) * hn_pois[FN_id];
			}
		}
	}
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int compute_latency(double *average_number_of_clients, double *FN_delay_as_sum, double *FN_delay_as_max, double *average_latency_as_sum, double *average_latency_as_max, char *unbounded_delay, double *FN_meet_deadline_as_max, double *average_meet_deadline_as_max){

	int ret = 0;

	*unbounded_delay = FALSE;
	for(int FN_id = 1; FN_id <= N ; FN_id++){
		if(active_FN[FN_id]){
			FN_delay_as_sum[FN_id] = 0;
			FN_delay_as_max[FN_id] = 0;
#ifdef DEBUG_LATENCY
			printf("FOR FN %d: ",FN_id);
#endif
			for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
				int FN_in_rp = rp[FN_id][rp_id];
				double FN_rho;
				if(FN_service_rate[FN_in_rp] > 0)
					FN_rho = load_to_FN[FN_in_rp] / FN_service_rate[FN_in_rp];
				else
					FN_rho = -1;
#ifdef DEBUG_LATENCY
				printf(" BEFORE ID %d  load %lf service %lf rho %lf",FN_in_rp,load_to_FN[FN_in_rp],FN_service_rate[FN_in_rp],FN_rho);
#endif
				if(FN_rho >= 1 - EPSILON){
#ifdef DEBUG_LATENCY
					printf(" RHO CLOSE TO 1\n",FN_in_rp,load_to_FN[FN_in_rp],FN_service_rate[FN_in_rp],FN_rho);
#endif
					FN_delay_as_sum[FN_id] = UNBOUNDED;
					FN_delay_as_max[FN_id] = UNBOUNDED;
					FN_meet_deadline_as_max[FN_id] = FALSE;
					*unbounded_delay = TRUE;
#ifndef DEBUG_LATENCY
					break;
#endif
				}
#ifdef DEBUG_LATENCY
				printf("\n");
#endif
			}
#ifdef DEBUG_LATENCY
			printf("\n");
#endif
			if (FN_delay_as_sum[FN_id] != UNBOUNDED  && FN_delay_as_max[FN_id] != UNBOUNDED ){
				double exponential_rate_parameter[N];
				double exponential_shift[N];
				int n_contacted = 0;
#ifdef DEBUG_LATENCY
				printf("FOR FN %d: ",FN_id);
#endif
				for(int rp_id = 1; rp_id <= rp[FN_id][0]; rp_id++){
					int FN_in_rp = rp[FN_id][rp_id];
					double FN_rho;
					if(FN_service_rate[FN_in_rp] > 0){
						FN_rho = load_to_FN[FN_in_rp] / FN_service_rate[FN_in_rp];
						FN_delay_as_sum[FN_id] += (1 / FN_service_rate[FN_in_rp]) / (1 - FN_rho);
						exponential_rate_parameter[n_contacted] = FN_service_rate[FN_in_rp] * (1 - FN_rho);
						exponential_shift[n_contacted] = 0;
						n_contacted++;
					}
#ifdef DEBUG_LATENCY
					printf(" ID %d exponential_rate_parameter %lf exponential_shift %lf rho %lf",FN_in_rp,exponential_rate_parameter[n_contacted-1],exponential_shift[n_contacted-1],FN_rho);
#endif
				}
#ifdef DEBUG_LATENCY
				printf("\n");
#endif
				FN_delay_as_max[FN_id] = compute_average_of_max(n_contacted , exponential_rate_parameter, exponential_shift);
				FN_meet_deadline_as_max[FN_id] = compute_deadline_probability(deadline, exponential_rate_parameter, exponential_shift, n_contacted);
			}
		}
	}

	double average_client_sum = 0;
	for(int FN_id = 1; FN_id <= N; FN_id++)
		if(active_FN[FN_id])
			if(FN_delay_as_sum[FN_id] != UNBOUNDED && FN_delay_as_max[FN_id] != UNBOUNDED){
				average_client_sum += average_number_of_clients[FN_id];
				ret++;
			}

	if(average_client_sum > 0){
		*average_latency_as_sum = 0;
		*average_latency_as_max = 0;
		*average_meet_deadline_as_max = 0;
		for(int FN_id = 1; FN_id <= N; FN_id++){
			if(active_FN[FN_id]){
				if(FN_delay_as_sum[FN_id] != UNBOUNDED && FN_delay_as_max[FN_id] != UNBOUNDED){
					*average_latency_as_sum += (average_number_of_clients[FN_id]/average_client_sum) * FN_delay_as_sum[FN_id];
					*average_latency_as_max += (average_number_of_clients[FN_id]/average_client_sum) * FN_delay_as_max[FN_id];
					*average_meet_deadline_as_max += (average_number_of_clients[FN_id]/average_client_sum) * FN_meet_deadline_as_max[FN_id];
				}
			}
		}
	}
	else{
		*average_latency_as_sum = UNBOUNDED;
		*average_latency_as_max = UNBOUNDED;
		*average_meet_deadline_as_max = 0;
	}
	return ret;
}
/**************************************************************/
/* NAME : */
/* DESCRIPTION : */
/* PARAMETERS : */
/* RETURN VALUE : */
/**************************************************************/
int main(int argc, char *argv[]){
	if(argc != 14){
		fprintf(stdout,"usage : %s L r n k F c lambda maxT Fmax Cmax lambdamax deadline n_replicas\n",argv[0]);
		exit(EXIT_FAILURE);
	}
	L = atoi(argv[1]);
	r = atoi(argv[2]);
	ncode_at_0 = atoi(argv[3]);
	kcode_at_0 = atoi(argv[4]);
	F = atoi(argv[5]);
	nclients = atoi(argv[6]);
	lambda = atof(argv[7]);
	max_time = atoi(argv[8]);
	Fmax = atoi(argv[9]);
	Cmax = atoi(argv[10]);
	lambdamax = atof(argv[11]);
	deadline = atof(argv[12]);
	n_replicas = atoi(argv[13]);

	N = (pow(r,L+1) - 1)/(r - 1);

// DETERMINE WHICH FN CAN ISSUE REQUESTS
	active_FN = (char *)calloc(N + 1, sizeof(char));
	for(int FN_id = 1; FN_id <= N; FN_id++){
		if(get_FN_level(FN_id) == L){
		       active_FN[FN_id] = TRUE;
		       Nactive++;
		}
		else	
		       active_FN[FN_id] = FALSE;
	}
// CALL TO THIS FUNCTION MUST *FOLLOW* ABOVE LOOP!!!
	allocate_structures();

	double average_number_of_clients[N + 1];
	double p_unfeasible_poisson[N + 1];

	double hn_mult[N + 1];
	double hn_pois[N + 1];
	double hf_mult[F];
	double hf_pois[F];

	double FN_delay_as_sum[N + 1];
	double FN_delay_as_max[N + 1];

	double FN_meet_deadline_as_max[N + 1];

	double H_mult = 0;
	double H_pois = 0;
	double unfeasibility = 0;
	double average_latency_as_sum = 0;
	double average_latency_as_max = 0;
	double average_meet_deadline_as_max = 0;
	char unbounded_delay;

//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////
	init_model_parameters();
	for( int t_ = 1; t_ <= max_time; t_++){/* For each time step */


		// To be computed beforehand: it is necessary for average phit!!
		compute_average_number_of_clients_for_each_FN(t_ - 1, average_number_of_clients);

		// phit computation
		compute_averaged_phit(t_, average_number_of_clients, hn_mult, hn_pois, hf_mult, hf_pois, &H_mult, &H_pois);

		// Computation of derived quantities to obtain latency
		compute_overall_load_to_each_FN(average_number_of_clients);

		// latency computation
		int naveraged = compute_latency(average_number_of_clients, FN_delay_as_sum, FN_delay_as_max, &average_latency_as_sum, &average_latency_as_max, &unbounded_delay, FN_meet_deadline_as_max, &average_meet_deadline_as_max);

		// feasibility computation
		unfeasibility = compute_unfeasibility_for_each_FN(p_unfeasible_poisson);

#ifdef DEBUG_ALL
     		print_fog_nodes_state(t_,average_number_of_clients,p_unfeasible_poisson,hn_mult,hn_pois,FN_delay_as_sum,FN_delay_as_max,FN_meet_deadline_as_max);
#endif
		fprintf(stdout,"============\nTime %d : phit (mult) = %lf phit (pois) %lf unfeasibility %lf latency (sum) %lf latency (max) %lf on %d unbounded %s meet %lf\n===========\n",t_,H_mult,H_pois,unfeasibility,average_latency_as_sum,average_latency_as_max,naveraged,(unbounded_delay)?"YES":"NO",average_meet_deadline_as_max);

		////////////////////////////////////
		// Time dependent parameter settings
		////////////////////////////////////
		
		//DOES NOT
		set_mds_parameters(t_, hn_mult, hn_pois, hf_mult, hf_pois, H_mult, H_pois, unfeasibility);
		//DOES NOT
		set_rp(t_);
		//DOES 
		set_file_allocations(t_, p_unfeasible_poisson, hn_pois);
		//DOES NOT
		set_file_popularities(t_);
		//DOES 
		set_client_request_rates(t_);
		//DOES NOT
		set_fog_nodes_capabilities(t_);
		//DOES 
		set_transition_matrix(t_);


	}

	free_structures();

	return EXIT_SUCCESS;
}
