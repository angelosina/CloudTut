#include <stdio.h>
#include <stdlib.h>

main(){
	srand(100);
	for(int i = 1; i <= 10; i++){
		int random_value = rand();
		fprintf(stdout,"%d : ",random_value);
		int bit_set = 0;
		for(int bitpos = 0; bitpos < 8 * sizeof(int); bitpos++){
			fprintf(stdout,"%c ",(random_value>>bitpos)&1?'1':'0');
			bit_set += (random_value>>bitpos)&1;
		}
		fprintf(stdout," : %d\n",bit_set);
	}

}
